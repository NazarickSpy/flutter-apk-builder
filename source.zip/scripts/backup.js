// Pakai: npm run backup            -> buat cadangan terenkripsi di ./backups
//        npm run backup -- --read FILE  -> baca isi cadangan (JSON) untuk pemulihan manual
const path = require('path'); require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const b = require('../lib/backup'), i = process.argv.indexOf('--read');
(async () => {
  if (i > 0) { const d = b.decode(process.argv[i + 1]); console.log(JSON.stringify(d, null, 1)); return process.exit(0); }
  const r = await b.run(); console.log('Cadangan dibuat:', r.file, JSON.stringify(r.rows)); process.exit(0);
})().catch((e) => { console.error('Gagal:', e.message); process.exit(1); });
