import 'package:flutter_test/flutter_test.dart';
import 'package:snowystore_app/util.dart';

void main() {
  test('rupiah memakai titik ribuan', () {
    expect(rupiah(0), 'Rp 0');
    expect(rupiah(100), 'Rp 100');
    expect(rupiah(1500), 'Rp 1.500');
    expect(rupiah(1500000), 'Rp 1.500.000');
    expect(rupiah(12345678), 'Rp 12.345.678');
    expect(rupiah(-2500), '-Rp 2.500');
  });

  test('normalizeBaseUrl menambah https dan membuang slash akhir', () {
    expect(normalizeBaseUrl('domain.com'), 'https://domain.com');
    expect(normalizeBaseUrl('  https://domain.com/  '), 'https://domain.com');
    expect(normalizeBaseUrl('http://10.0.2.2:3000'), 'http://10.0.2.2:3000');
    expect(normalizeBaseUrl(''), isNull);
    expect(normalizeBaseUrl('https://'), isNull);
  });

  test('compareVersions', () {
    expect(compareVersions('1.0.0', '1.0.0'), 0);
    expect(compareVersions('1.0.0', '1.2.0') < 0, isTrue);
    expect(compareVersions('2.0', '1.9.9') > 0, isTrue);
    expect(compareVersions('1.0.1', '1.0') > 0, isTrue);
  });

  test('mmss & sizeLabel', () {
    expect(mmss(75), '01:15');
    expect(mmss(-3), '00:00');
    expect(sizeLabel(2048), '2 GB');
    expect(sizeLabel(1536), '1.5 GB');
    expect(sizeLabel(512), '512 MB');
  });
}
