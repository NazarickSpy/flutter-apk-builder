import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'api.dart';
import 'config.dart';

/// Bertambah tiap ada perubahan pesanan (mis. setelah order baru) supaya tab Pesanan & Panel memuat ulang.
final ValueNotifier<int> ordersRev = ValueNotifier<int>(0);

class AppState extends ChangeNotifier {
  final Api api = Api();
  final FlutterSecureStorage _sec = const FlutterSecureStorage();
  SharedPreferences? _prefs;

  bool ready = false;
  Map<String, dynamic>? user;
  Map<String, dynamic> config = {};
  String? bootError;

  bool get loggedIn => api.token != null;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    api.baseUrl = _prefs!.getString('base') ?? kDefaultBase;
    try {
      api.token = await _sec.read(key: 'token');
    } catch (_) {
      api.token = null; // keystore rusak/dipulihkan: minta login ulang
    }
    api.onUnauthorized = _expire;
    api.onTokenRefreshed = (t) => _saveToken(t);
    await refresh();
    ready = true;
    notifyListeners();
  }

  Future<void> _saveToken(String? t) async {
    api.token = t;
    try {
      if (t == null) {
        await _sec.delete(key: 'token');
      } else {
        await _sec.write(key: 'token', value: t);
      }
    } catch (_) {}
  }

  void _expire() {
    user = null;
    _saveToken(null);
    notifyListeners();
  }

  /// Muat konfigurasi publik + profil (bila sudah login).
  Future<void> refresh() async {
    bootError = null;
    try {
      config = Map<String, dynamic>.from(await api.get('/config', auth: false) as Map);
    } on ApiException catch (e) {
      bootError = e.message;
    }
    if (api.token != null) {
      try {
        user = Map<String, dynamic>.from(await api.get('/me') as Map);
        bootError = null;
      } on ApiException catch (e) {
        if (e.status != 401) bootError = e.message; // 401 sudah ditangani _expire()
      }
    }
    notifyListeners();
  }

  Future<void> setBase(String base) async {
    api.baseUrl = base;
    await _prefs?.setString('base', base);
    await _saveToken(null); // token milik server lama tidak berlaku di server baru
    user = null;
    config = {};
    bootError = null;
    await refresh();
  }

  /// Mengembalikan ticket bila akun memakai 2FA, atau null bila login langsung berhasil.
  Future<String?> login(String username, String password) async {
    final j = await api.request('POST', '/login', body: {'username': username.trim(), 'password': password}, auth: false) as Map;
    if (j['need_2fa'] == true) return j['ticket'] as String?;
    await _finishLogin(j);
    return null;
  }

  Future<void> login2fa(String ticket, String code) async {
    final j = await api.request('POST', '/login/2fa', body: {'ticket': ticket, 'code': code.trim()}, auth: false) as Map;
    await _finishLogin(j);
  }

  Future<void> _finishLogin(Map j) async {
    final t = j['token'];
    if (t is! String || t.isEmpty) throw ApiException('Server tidak mengirim token. Pastikan server sudah diperbarui (mendukung aplikasi).', 0);
    await _saveToken(t);
    ordersRev.value++;
    await refresh();
  }

  Future<void> register({required String username, required String email, required String whatsapp, required String password}) async {
    await api.request('POST', '/register', auth: false, body: {'username': username.trim().toLowerCase(), 'email': email.trim(), 'whatsapp': whatsapp.trim(), 'password': password});
  }

  Future<void> changePassword(String oldPw, String newPw) async {
    final j = await api.post('/password', {'old': oldPw, 'next': newPw}) as Map;
    if (j['token'] is String) await _saveToken(j['token'] as String); // semua sesi lama dicabut; token baru untuk perangkat ini
  }

  Future<void> logout({bool everywhere = false}) async {
    try {
      await api.post(everywhere ? '/logout-all' : '/logout');
    } catch (_) {}
    user = null;
    await _saveToken(null);
    notifyListeners();
  }

  /// Layanan dimatikan admin? Mengembalikan pesan untuk pelanggan, atau null bila aktif.
  String? serviceOff(String name) {
    final s = config['services'];
    if (s is Map && s[name] is Map && (s[name] as Map)['on'] == false) {
      final m = (s[name] as Map)['msg'];
      return (m is String && m.isNotEmpty) ? m : 'Layanan ini sedang dinonaktifkan sementara.';
    }
    return null;
  }

  bool get maintenance => config['maintenance'] == true;
  String? get maintenanceMsg => config['maintenance_msg'] as String?;
  String? get announcement => config['announcement'] as String?;
  String? get contactWa => (config['contact'] is Map) ? (config['contact'] as Map)['wa'] as String? : null;
  Map<String, dynamic> get appInfo => (config['app'] is Map) ? Map<String, dynamic>.from(config['app'] as Map) : {};
}

final AppState appState = AppState();
