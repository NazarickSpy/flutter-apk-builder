import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import 'config.dart';

class ApiException implements Exception {
  ApiException(this.message, this.status, {this.captcha = false});
  final String message;
  final int status; // 0 = gagal koneksi / timeout
  final bool captcha;
  @override
  String toString() => message;
}

const _friendly = {
  400: 'Data yang dimasukkan belum sesuai. Periksa kembali isian Anda.',
  401: 'Sesi Anda berakhir. Silakan masuk lagi.',
  403: 'Anda tidak memiliki akses untuk tindakan ini.',
  404: 'Data tidak ditemukan.',
  409: 'Permintaan ini bentrok dengan proses yang sedang berjalan. Coba lagi sebentar.',
  429: 'Terlalu banyak percobaan. Coba lagi nanti.',
  503: 'Layanan sedang sibuk atau dalam pemeliharaan. Coba lagi nanti.',
};

/// Klien HTTP untuk server SnowyStore (Express). Autentikasi memakai token Bearer;
/// header X-Requested-With + X-Client wajib agar lolos pemeriksaan CSRF & perisai server.
class Api {
  Api({String? baseUrl}) : baseUrl = baseUrl ?? kDefaultBase;

  String baseUrl;
  String? token;
  void Function()? onUnauthorized;
  void Function(String token)? onTokenRefreshed;
  final http.Client _c = http.Client();
  static final _rnd = Random.secure();

  /// Kunci idempotensi 32 karakter: pakai ulang untuk retry request yang SAMA agar tidak ada pesanan ganda.
  static String newIdemKey() {
    const a = 'abcdefghijklmnopqrstuvwxyz0123456789';
    return List.generate(32, (_) => a[_rnd.nextInt(a.length)]).join();
  }

  Map<String, String> _headers({bool json = true, String? idem}) => {
        if (json) 'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Requested-With': 'snowy',
        'X-Client': 'snowy-app',
        'User-Agent': kUserAgent,
        if (kAppKey.isNotEmpty) 'X-App-Key': kAppKey,
        if (token != null) 'Authorization': 'Bearer $token',
        if (idem != null) 'Idempotency-Key': idem,
      };

  Future<T> _guard<T>(Future<T> Function() f) async {
    try {
      return await f();
    } on ApiException {
      rethrow;
    } on TimeoutException {
      throw ApiException('Server lambat merespons. Coba lagi.', 0);
    } on HandshakeException {
      throw ApiException('Koneksi aman (HTTPS) ke server gagal. Periksa alamat server atau sertifikatnya.', 0);
    } on SocketException {
      throw ApiException('Tidak bisa terhubung ke server. Periksa internet dan alamat server.', 0);
    } on http.ClientException {
      throw ApiException('Tidak bisa terhubung ke server. Periksa internet dan alamat server.', 0);
    } on FormatException {
      throw ApiException('Alamat server tidak valid.', 0);
    }
  }

  Future<dynamic> request(String method, String path,
      {Object? body, String? idem, bool auth = true, Duration timeout = const Duration(seconds: 20)}) {
    return _guard(() async {
      final uri = Uri.parse('$baseUrl/api$path');
      final h = _headers(idem: idem);
      final enc = body == null ? null : jsonEncode(body);
      final http.Response r = switch (method) {
        'GET' => await _c.get(uri, headers: h).timeout(timeout),
        'DELETE' => await _c.delete(uri, headers: h).timeout(timeout),
        _ => await _c.post(uri, headers: h, body: enc ?? '{}').timeout(timeout),
      };
      final text = utf8.decode(r.bodyBytes, allowMalformed: true);
      dynamic j;
      try {
        j = text.isEmpty ? null : jsonDecode(text);
      } catch (_) {
        j = null;
      }
      final fresh = r.headers['x-session-token'];
      if (fresh != null && fresh.isNotEmpty) {
        token = fresh;
        onTokenRefreshed?.call(fresh);
      }
      if (r.statusCode >= 200 && r.statusCode < 300) return j ?? <String, dynamic>{};
      if (r.statusCode == 401 && auth && token != null) onUnauthorized?.call();
      var msg = (j is Map && j['error'] is String) ? j['error'] as String : '';
      if (msg.isEmpty && j == null && text.isNotEmpty && text.length < 80 && !text.trimLeft().startsWith('<')) msg = text; // mis. "Akses diblokir sementara."
      if (msg.isEmpty) msg = _friendly[r.statusCode] ?? 'Terjadi kesalahan (${r.statusCode}). Coba lagi.';
      final ref = (j is Map && j['ref'] != null && r.statusCode >= 500) ? ' (Ref: ${j['ref']})' : '';
      throw ApiException('$msg$ref', r.statusCode, captcha: j is Map && j['captcha'] == true);
    });
  }

  Future<dynamic> get(String p, {bool auth = true}) => request('GET', p, auth: auth);
  Future<dynamic> post(String p, [Object? body, String? idem]) => request('POST', p, body: body ?? {}, idem: idem);

  /// Gambar (QR pembayaran) dengan autentikasi.
  Future<Uint8List> bytes(String path) {
    return _guard(() async {
      final r = await _c.get(Uri.parse('$baseUrl/api$path'), headers: _headers(json: false)).timeout(const Duration(seconds: 20));
      if (r.statusCode != 200) throw ApiException(_friendly[r.statusCode] ?? 'Gagal memuat gambar (${r.statusCode}).', r.statusCode);
      return r.bodyBytes;
    });
  }

  /// Tes koneksi ke server (GET /healthz). Mengembalikan pesan hasil.
  Future<String> ping() {
    return _guard(() async {
      final sw = Stopwatch()..start();
      final r = await _c.get(Uri.parse('$baseUrl/healthz'), headers: {'User-Agent': kUserAgent, 'Accept': 'application/json'}).timeout(const Duration(seconds: 10));
      sw.stop();
      if (r.statusCode == 200) return 'Terhubung (${sw.elapsedMilliseconds} ms)';
      if (r.statusCode == 503) throw ApiException('Server menyala tetapi database bermasalah (503).', 503);
      if (r.statusCode == 403) throw ApiException('IP Anda diblokir sementara oleh perisai server (403).', 403);
      throw ApiException('Server membalas ${r.statusCode}. Pastikan alamat server benar.', r.statusCode);
    });
  }
}
