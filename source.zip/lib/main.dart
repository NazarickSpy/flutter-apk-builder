import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'config.dart';
import 'screens/home.dart';
import 'screens/login.dart';
import 'screens/server_settings.dart';
import 'state.dart';
import 'util.dart';

const kBrand = Color(0xFF19808F); // teal SnowyStore

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SnowyApp());
}

class SnowyApp extends StatefulWidget {
  const SnowyApp({super.key});
  @override
  State<SnowyApp> createState() => _SnowyAppState();
}

class _SnowyAppState extends State<SnowyApp> {
  @override
  void initState() {
    super.initState();
    appState.init();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SnowyStore',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: kBrand),
        scaffoldBackgroundColor: const Color(0xFFF6F8FA),
        inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, surfaceTintColor: Colors.white, elevation: 0),
      ),
      home: const Gate(),
    );
  }
}

/// Memilih layar: memuat -> login -> beranda. Juga memeriksa versi minimum app dari server.
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  bool _updateShown = false;

  void _checkVersion() {
    if (_updateShown || !appState.ready) return;
    final min = appState.appInfo['min_version'];
    if (min is String && compareVersions(kAppVersion, min) < 0) {
      _updateShown = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        final url = appState.appInfo['download_url'];
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (c) => PopScope(
            canPop: false,
            child: AlertDialog(
              title: const Text('Perbarui aplikasi'),
              content: Text('Versi $kAppVersion sudah terlalu lama. Minimal versi $min diperlukan untuk terhubung ke server.'),
              actions: [
                if (url is String && url.isNotEmpty)
                  FilledButton(onPressed: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication), child: const Text('Unduh pembaruan')),
              ],
            ),
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Gate sendiri yang mendengarkan appState (widget const tidak ikut dibangun ulang dari luar)
    return ListenableBuilder(
      listenable: appState,
      builder: (context, _) {
        if (!appState.ready) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        _checkVersion();
        if (!appState.loggedIn) return const LoginScreen();
        if (appState.user == null) return const _ConnectError();
        return const HomeScreen();
      },
    );
  }
}

class _ConnectError extends StatefulWidget {
  const _ConnectError();
  @override
  State<_ConnectError> createState() => _ConnectErrorState();
}

class _ConnectErrorState extends State<_ConnectError> {
  bool _busy = false;

  Future<void> _retry() async {
    setState(() => _busy = true);
    await appState.refresh();
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.cloud_off, size: 56, color: Colors.grey),
              const SizedBox(height: 14),
              const Text('Tidak bisa terhubung ke server', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(appState.bootError ?? 'Coba lagi sebentar.', textAlign: TextAlign.center),
              const SizedBox(height: 4),
              Text(appState.api.baseUrl, style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 20),
              FilledButton.icon(onPressed: _busy ? null : _retry, icon: const Icon(Icons.refresh), label: Text(_busy ? 'Menghubungkan…' : 'Coba lagi')),
              TextButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ServerSettingsScreen())), child: const Text('Ubah alamat server')),
              TextButton(onPressed: () => appState.logout(), child: const Text('Keluar')),
            ]),
          ),
        ),
      ),
    );
  }
}
