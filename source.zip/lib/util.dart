import 'package:flutter/material.dart';

String rupiah(num n) {
  final neg = n < 0;
  final s = n.abs().round().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    final rem = s.length - i;
    b.write(s[i]);
    if (rem > 1 && rem % 3 == 1) b.write('.');
  }
  return '${neg ? '-' : ''}Rp $b';
}

/// Merapikan alamat server yang diketik pengguna. null = tidak valid.
String? normalizeBaseUrl(String raw) {
  var s = raw.trim();
  if (s.isEmpty) return null;
  if (!RegExp(r'^https?://', caseSensitive: false).hasMatch(s)) s = 'https://$s';
  final u = Uri.tryParse(s);
  if (u == null || u.host.isEmpty) return null;
  return s.replaceAll(RegExp(r'/+$'), '');
}

/// <0 bila a lebih lama dari b, 0 sama, >0 bila a lebih baru.
int compareVersions(String a, String b) {
  List<int> p(String v) => v.split('.').map((e) => int.tryParse(e.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0).toList();
  final x = p(a), y = p(b);
  for (var i = 0; i < 3; i++) {
    final d = (i < x.length ? x[i] : 0) - (i < y.length ? y[i] : 0);
    if (d != 0) return d;
  }
  return 0;
}

String mmss(int seconds) {
  final s = seconds < 0 ? 0 : seconds;
  return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
}

String sizeLabel(num mb) => mb >= 1024 ? '${(mb / 1024).toStringAsFixed(mb % 1024 == 0 ? 0 : 1)} GB' : '${mb.round()} MB';

DateTime? parseDate(dynamic v) => v == null ? null : DateTime.tryParse(v.toString())?.toLocal();

String fdate(dynamic v) {
  final d = parseDate(v);
  if (d == null) return '-';
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(d.day)} ${m[d.month - 1]} ${d.year} ${two(d.hour)}:${two(d.minute)}';
}

const stateLabel = {
  'unpaid': 'Menunggu bayar',
  'processing': 'Diproses',
  'active': 'Aktif',
  'failed': 'Gagal',
  'expired': 'Kedaluwarsa',
  'cancelled': 'Dibatalkan',
};

Color stateColor(String s) => switch (s) {
      'active' => const Color(0xFF1B8A4B),
      'unpaid' => const Color(0xFFB7791F),
      'processing' => const Color(0xFF2B6CB0),
      'failed' => const Color(0xFFC53030),
      _ => const Color(0xFF718096),
    };

void toast(BuildContext c, String msg) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
}

/// Kartu putih berbingkai (tidak memakai CardTheme agar kompatibel di semua versi Flutter).
class Box extends StatelessWidget {
  const Box({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.onTap, this.margin = const EdgeInsets.only(bottom: 10)});
  final Widget child;
  final EdgeInsets padding, margin;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(borderRadius: BorderRadius.circular(14), onTap: onTap, child: Padding(padding: padding, child: child)),
      ),
    );
  }
}

class StateChip extends StatelessWidget {
  const StateChip(this.state, {super.key});
  final String state;
  @override
  Widget build(BuildContext context) {
    final c = stateColor(state);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(color: c.withAlpha(30), borderRadius: BorderRadius.circular(20)),
      child: Text(stateLabel[state] ?? state, style: TextStyle(color: c, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}
