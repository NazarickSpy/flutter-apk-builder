// Konfigurasi build. Semua bisa diganti saat build tanpa mengubah kode:
//   flutter build apk --release --dart-define=API_BASE=https://domainmu.com --dart-define=APP_KEY=isi_APP_API_KEY
const String kAppVersion = '1.0.0'; // samakan dengan `version:` di pubspec.yaml
const String kDefaultBase = String.fromEnvironment('API_BASE', defaultValue: 'https://snowystore.my.id');
// Opsional: sama dengan APP_API_KEY di .env server. Dipakai agar login/daftar dari app tidak diminta Turnstile.
// Catatan: nilai ini tertanam di APK dan bisa diekstrak, jadi bukan rahasia kuat.
const String kAppKey = String.fromEnvironment('APP_KEY', defaultValue: '');
const String kUserAgent = 'SnowyStoreApp/$kAppVersion (Flutter)';
