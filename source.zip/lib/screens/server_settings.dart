import 'package:flutter/material.dart';

import '../api.dart';
import '../config.dart';
import '../state.dart';
import '../util.dart';

/// Atur alamat server + tes koneksi (GET /healthz).
class ServerSettingsScreen extends StatefulWidget {
  const ServerSettingsScreen({super.key});
  @override
  State<ServerSettingsScreen> createState() => _ServerSettingsScreenState();
}

class _ServerSettingsScreenState extends State<ServerSettingsScreen> {
  late final TextEditingController _url = TextEditingController(text: appState.api.baseUrl);
  String? _result;
  bool _ok = false, _busy = false;

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _test() async {
    final base = normalizeBaseUrl(_url.text);
    if (base == null) return setState(() { _ok = false; _result = 'Alamat server tidak valid.'; });
    setState(() { _busy = true; _result = null; });
    final probe = Api(baseUrl: base);
    try {
      final r = await probe.ping();
      if (mounted) setState(() { _ok = true; _result = r; });
    } on ApiException catch (e) {
      if (mounted) setState(() { _ok = false; _result = e.message; });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _save() async {
    final base = normalizeBaseUrl(_url.text);
    if (base == null) return toast(context, 'Alamat server tidak valid.');
    if (base == appState.api.baseUrl) return Navigator.of(context).pop();
    setState(() => _busy = true);
    await appState.setBase(base);
    if (!mounted) return;
    toast(context, 'Server diganti. Silakan masuk lagi.');
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Server')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Alamat server SnowyStore', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        TextField(
          controller: _url,
          keyboardType: TextInputType.url,
          autocorrect: false,
          decoration: const InputDecoration(hintText: 'https://domainmu.com', prefixIcon: Icon(Icons.dns_outlined)),
        ),
        const SizedBox(height: 6),
        Text('Bawaan build: $kDefaultBase', style: const TextStyle(color: Colors.grey, fontSize: 12)),
        const SizedBox(height: 14),
        if (_result != null)
          Box(child: Row(children: [
            Icon(_ok ? Icons.check_circle : Icons.error, color: _ok ? Colors.green : Colors.red),
            const SizedBox(width: 10),
            Expanded(child: Text(_result!)),
          ])),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: _busy ? null : _test, icon: const Icon(Icons.network_check), label: const Text('Tes koneksi'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton(onPressed: _busy ? null : _save, child: const Text('Simpan'))),
        ]),
        const SizedBox(height: 18),
        const Text('Gunakan https:// untuk server publik. Mengganti server akan mengeluarkan akun dari server lama.', style: TextStyle(color: Colors.grey, fontSize: 12)),
      ]),
    );
  }
}
