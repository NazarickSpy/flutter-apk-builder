import 'package:flutter/material.dart';

import '../api.dart';
import '../state.dart';
import '../util.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final _user = TextEditingController(), _email = TextEditingController(), _wa = TextEditingController(), _pass = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _user.dispose();
    _email.dispose();
    _wa.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate() || _busy) return;
    setState(() { _busy = true; _error = null; });
    try {
      await appState.register(username: _user.text, email: _email.text, whatsapp: _wa.text, password: _pass.text);
      if (!mounted) return;
      toast(context, 'Pendaftaran berhasil. Silakan masuk.');
      Navigator.of(context).pop();
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.captcha ? 'Server mewajibkan Turnstile. Isi APP_API_KEY di server dan APP_KEY saat build app.' : e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daftar')),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(20), children: [
          TextFormField(
            controller: _user,
            autocorrect: false,
            decoration: const InputDecoration(labelText: 'Username', helperText: '4-20 huruf kecil/angka'),
            validator: (v) => RegExp(r'^[a-z0-9]{4,20}$').hasMatch((v ?? '').trim().toLowerCase()) ? null : 'Username 4-20 huruf kecil/angka',
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            autocorrect: false,
            decoration: const InputDecoration(labelText: 'Email'),
            validator: (v) => RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch((v ?? '').trim()) ? null : 'Email tidak valid',
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _wa,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Nomor WhatsApp', helperText: 'Diawali 0, contoh 08123456789'),
            validator: (v) => RegExp(r'^0\d{9,14}$').hasMatch((v ?? '').trim()) ? null : 'Nomor WhatsApp tidak valid',
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _pass,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'Password', helperText: 'Minimal 8 karakter, jangan memuat username'),
            validator: (v) => (v ?? '').length >= 8 && (v ?? '').length <= 72 ? null : 'Password 8-72 karakter',
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 18),
          FilledButton(
            onPressed: _busy ? null : _submit,
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
            child: _busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Daftar'),
          ),
        ]),
      ),
    );
  }
}
