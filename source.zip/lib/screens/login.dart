import 'package:flutter/material.dart';

import '../api.dart';
import '../state.dart';
import '../util.dart';
import 'register.dart';
import 'server_settings.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _user = TextEditingController(), _pass = TextEditingController(), _code = TextEditingController();
  String? _ticket, _error;
  bool _busy = false, _hide = true;

  @override
  void dispose() {
    _user.dispose();
    _pass.dispose();
    _code.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() { _busy = true; _error = null; });
    try {
      if (_ticket == null) {
        if (_user.text.trim().isEmpty || _pass.text.isEmpty) throw ApiException('Isi username dan password.', 0);
        final t = await appState.login(_user.text, _pass.text);
        if (t != null && mounted) setState(() { _ticket = t; _code.clear(); });
      } else {
        await appState.login2fa(_ticket!, _code.text);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.captcha
          ? 'Server mewajibkan verifikasi Turnstile. Isi APP_API_KEY di .env server dan build app dengan --dart-define=APP_KEY=...'
          : e.message);
      if (e.status == 401 && _ticket != null && e.message.contains('berakhir')) setState(() => _ticket = null);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final twoFa = _ticket != null;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Align(
                  alignment: Alignment.centerRight,
                  child: IconButton(
                    tooltip: 'Server',
                    icon: const Icon(Icons.dns_outlined),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ServerSettingsScreen())),
                  ),
                ),
                Icon(Icons.ac_unit, size: 54, color: cs.primary),
                const SizedBox(height: 8),
                const Text('SnowyStore', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(twoFa ? 'Verifikasi 2 langkah' : 'Masuk ke akun Anda', textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)),
                const SizedBox(height: 22),
                if (appState.bootError != null && !twoFa)
                  Box(child: Row(children: [
                    const Icon(Icons.cloud_off, color: Colors.orange),
                    const SizedBox(width: 10),
                    Expanded(child: Text('${appState.bootError}\n${appState.api.baseUrl}', style: const TextStyle(fontSize: 12))),
                  ])),
                if (!twoFa) ...[
                  TextField(controller: _user, autocorrect: false, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Username atau email', prefixIcon: Icon(Icons.person_outline))),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _pass,
                    obscureText: _hide,
                    onSubmitted: (_) => _submit(),
                    decoration: InputDecoration(
                      labelText: 'Password',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _hide = !_hide)),
                    ),
                  ),
                ] else
                  TextField(
                    controller: _code,
                    autofocus: true,
                    keyboardType: TextInputType.text,
                    onSubmitted: (_) => _submit(),
                    decoration: const InputDecoration(labelText: 'Kode 6 digit atau kode pemulihan', prefixIcon: Icon(Icons.shield_outlined)),
                  ),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Text(_error!, style: TextStyle(color: cs.error)),
                ],
                const SizedBox(height: 18),
                FilledButton(
                  onPressed: _busy ? null : _submit,
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                  child: _busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text(twoFa ? 'Verifikasi' : 'Masuk'),
                ),
                if (twoFa) TextButton(onPressed: () => setState(() { _ticket = null; _error = null; }), child: const Text('Kembali')),
                if (!twoFa)
                  TextButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RegisterScreen())), child: const Text('Belum punya akun? Daftar')),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
