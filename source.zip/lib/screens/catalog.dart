import 'package:flutter/material.dart';

import '../api.dart';
import '../state.dart';
import '../util.dart';
import 'pay.dart';

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key});
  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  List<Map<String, dynamic>>? _items;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final j = await appState.api.get('/packages');
      final list = (j is List ? j : <dynamic>[]).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      if (mounted) setState(() { _items = list; _error = null; });
    } on ApiException catch (e) {
      if (mounted) setState(() { _error = e.message; _items ??= []; });
    }
    appState.refresh(); // pengumuman / saklar layanan terbaru
  }

  void _order(Map<String, dynamic> p) {
    final off = appState.serviceOff('panel');
    if (off != null) return toast(context, off);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _OrderSheet(pkg: p),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appState,
      builder: (context, _) {
        final items = _items;
        final off = appState.serviceOff('panel');
        return RefreshIndicator(
          onRefresh: _load,
          child: ListView(padding: const EdgeInsets.all(14), children: [
            if (appState.maintenance)
              _Banner(icon: Icons.build_circle_outlined, color: Colors.orange, text: appState.maintenanceMsg ?? 'Sedang pemeliharaan. Order baru dibuka kembali sebentar lagi.'),
            if (off != null) _Banner(icon: Icons.block, color: Colors.red, text: off),
            if ((appState.announcement ?? '').isNotEmpty) _Banner(icon: Icons.campaign_outlined, color: Theme.of(context).colorScheme.primary, text: appState.announcement!),
            if (items == null) const Padding(padding: EdgeInsets.only(top: 80), child: Center(child: CircularProgressIndicator())),
            if (items != null && items.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 60),
                child: Center(child: Text(_error ?? 'Belum ada paket tersedia.', textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey))),
              ),
            for (final p in items ?? const <Map<String, dynamic>>[])
              Box(
                onTap: () => _order(p),
                child: Row(children: [
                  Container(
                    width: 52,
                    height: 52,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(25), borderRadius: BorderRadius.circular(12)),
                    child: Text('${(((p['memory'] ?? 0) as num) / 1024).round()}G', style: TextStyle(fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                      const SizedBox(height: 2),
                      Text('RAM ${sizeLabel((p['memory'] ?? 0) as num)} · Disk ${sizeLabel((p['disk'] ?? 0) as num)} · CPU ${p['cpu'] == 0 ? 'Unlimited' : '${p['cpu']}%'}${p['days'] != null ? ' · ${p['days']} hari' : ''}',
                          style: const TextStyle(color: Colors.grey, fontSize: 12.5)),
                    ]),
                  ),
                  Text(rupiah((p['price'] ?? 0) as num), style: const TextStyle(fontWeight: FontWeight.w800)),
                ]),
              ),
          ]),
        );
      },
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({required this.icon, required this.color, required this.text});
  final IconData icon;
  final Color color;
  final String text;
  @override
  Widget build(BuildContext context) => Box(
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
        ]),
      );
}

class _OrderSheet extends StatefulWidget {
  const _OrderSheet({required this.pkg});
  final Map<String, dynamic> pkg;
  @override
  State<_OrderSheet> createState() => _OrderSheetState();
}

class _OrderSheetState extends State<_OrderSheet> {
  final _name = TextEditingController();
  final String _idem = Api.newIdemKey(); // satu kunci per sheet: tombol ditekan dua kali / retry tidak membuat pesanan ganda
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _go() async {
    final n = _name.text.trim();
    if (!RegExp(r'^[A-Za-z0-9_]{3,14}$').hasMatch(n)) return setState(() => _error = 'Username panel 3-14 karakter: huruf, angka, atau underscore');
    setState(() { _busy = true; _error = null; });
    try {
      final j = await appState.api.post('/orders', {'package': widget.pkg['key'], 'name': n, 'price': widget.pkg['price']}, _idem) as Map;
      ordersRev.value++;
      if (!mounted) return;
      final nav = Navigator.of(context);
      nav.pop();
      nav.push(MaterialPageRoute(builder: (_) => PayScreen(orderId: (j['id'] as num).toInt())));
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.pkg;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('${p['name']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text('RAM ${sizeLabel((p['memory'] ?? 0) as num)} · ${rupiah((p['price'] ?? 0) as num)}', style: const TextStyle(color: Colors.grey)),
        const SizedBox(height: 16),
        TextField(
          controller: _name,
          autocorrect: false,
          maxLength: 14,
          decoration: const InputDecoration(labelText: 'Username panel', helperText: 'Dipakai sebagai nama server/akun panel'),
        ),
        if (_error != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        FilledButton.icon(
          onPressed: _busy ? null : _go,
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
          icon: _busy ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.qr_code_2),
          label: const Text('Bayar dengan QRIS'),
        ),
        const SizedBox(height: 6),
        const Text('Panel Averpay bersifat non-garansi. Pesanan diproses otomatis setelah pembayaran terdeteksi.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 12)),
      ]),
    );
  }
}
