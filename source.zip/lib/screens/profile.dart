import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../api.dart';
import '../config.dart';
import '../state.dart';
import '../util.dart';
import 'server_settings.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Future<void> _confirm(BuildContext context, String title, String text, Future<void> Function() action) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: Text(text),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Ya'))],
      ),
    );
    if (ok == true) await action();
  }

  void _changePassword(BuildContext context) {
    final oldC = TextEditingController(), newC = TextEditingController();
    String? error;
    bool busy = false;
    showDialog(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: const Text('Ubah password'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: oldC, obscureText: true, decoration: const InputDecoration(labelText: 'Password lama')),
            const SizedBox(height: 10),
            TextField(controller: newC, obscureText: true, decoration: const InputDecoration(labelText: 'Password baru (min. 8)')),
            if (error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error!, style: const TextStyle(color: Colors.red, fontSize: 12.5))),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('Batal')),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      set(() { busy = true; error = null; });
                      try {
                        await appState.changePassword(oldC.text, newC.text);
                        if (c.mounted) Navigator.pop(c);
                        if (context.mounted) toast(context, 'Password diubah. Perangkat lain dikeluarkan.');
                      } on ApiException catch (e) {
                        set(() { busy = false; error = e.message; });
                      }
                    },
              child: const Text('Simpan'),
            ),
          ],
        ),
      ),
    ).whenComplete(() { oldC.dispose(); newC.dispose(); });
  }

  Future<void> _wa(BuildContext context) async {
    final wa = appState.contactWa;
    if (wa == null || wa.isEmpty) return toast(context, 'Kontak bantuan belum diatur.');
    try {
      await launchUrl(Uri.parse('https://wa.me/$wa'), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (context.mounted) toast(context, 'Tidak bisa membuka WhatsApp.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appState,
      builder: (context, _) {
        final u = appState.user ?? {};
        final cs = Theme.of(context).colorScheme;
        return ListView(padding: const EdgeInsets.all(14), children: [
          Box(
            child: Row(children: [
              CircleAvatar(radius: 26, backgroundColor: cs.primary, child: Text(((u['username'] ?? '?') as String).substring(0, 1).toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800))),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${u['username'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  Text('${u['email'] ?? ''}', style: const TextStyle(color: Colors.grey, fontSize: 13)),
                  Text('WA ${u['whatsapp'] ?? '-'}  ·  ${u['uid'] ?? ''}', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                ]),
              ),
              if (u['role'] == 'admin') const Chip(label: Text('Admin')),
            ]),
          ),
          Box(
            padding: EdgeInsets.zero,
            child: Column(children: [
              ListTile(leading: const Icon(Icons.lock_reset), title: const Text('Ubah password'), onTap: () => _changePassword(context)),
              ListTile(leading: const Icon(Icons.support_agent), title: const Text('Hubungi bantuan (WhatsApp)'), onTap: () => _wa(context)),
              ListTile(
                leading: const Icon(Icons.dns_outlined),
                title: const Text('Server'),
                subtitle: Text(appState.api.baseUrl),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ServerSettingsScreen())),
              ),
            ]),
          ),
          Box(
            padding: EdgeInsets.zero,
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Keluar'),
                onTap: () => _confirm(context, 'Keluar?', 'Anda harus masuk lagi untuk memakai aplikasi.', () => appState.logout()),
              ),
              ListTile(
                leading: const Icon(Icons.devices_other, color: Colors.red),
                title: const Text('Keluar dari semua perangkat', style: TextStyle(color: Colors.red)),
                onTap: () => _confirm(context, 'Keluar dari semua perangkat?', 'Semua sesi (web dan aplikasi) akan dicabut.', () => appState.logout(everywhere: true)),
              ),
            ]),
          ),
          const SizedBox(height: 10),
          Center(child: Text('SnowyStore App v$kAppVersion', style: const TextStyle(color: Colors.grey, fontSize: 12))),
        ]);
      },
    );
  }
}
