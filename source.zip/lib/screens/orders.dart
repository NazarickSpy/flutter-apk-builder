import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../api.dart';
import '../state.dart';
import '../util.dart';
import 'pay.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  List<Map<String, dynamic>>? _items;
  String? _error;

  @override
  void initState() {
    super.initState();
    ordersRev.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    ordersRev.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final j = await appState.api.get('/orders');
      final list = (j is List ? j : <dynamic>[]).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      if (mounted) setState(() { _items = list; _error = null; });
    } on ApiException catch (e) {
      if (mounted) setState(() { _error = e.message; _items ??= []; });
    }
  }

  void _open(Map<String, dynamic> o) {
    final st = o['state'] as String? ?? '';
    if (st == 'unpaid' || st == 'processing') {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => PayScreen(orderId: (o['id'] as num).toInt())));
      return;
    }
    showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => _Detail(o: o));
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    return RefreshIndicator(
      onRefresh: _load,
      child: items == null
          ? ListView(children: const [Padding(padding: EdgeInsets.only(top: 120), child: Center(child: CircularProgressIndicator()))])
          : items.isEmpty
              ? ListView(children: [Padding(padding: const EdgeInsets.only(top: 120, left: 24, right: 24), child: Center(child: Text(_error ?? 'Belum ada pesanan.', textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey))))])
              : ListView.builder(
                  padding: const EdgeInsets.all(14),
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final o = items[i];
                    final pkg = (o['pkg'] as Map?) ?? {};
                    return Box(
                      onTap: () => _open(o),
                      child: Row(children: [
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('${pkg['name'] ?? o['package_key']} · ${o['server_name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                            const SizedBox(height: 3),
                            Text('${o['trx']}  ·  ${fdate(o['created_at'])}', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                          ]),
                        ),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text(rupiah((o['price'] ?? 0) as num), style: const TextStyle(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          StateChip(o['state'] as String? ?? ''),
                        ]),
                      ]),
                    );
                  },
                ),
    );
  }
}

class _Detail extends StatelessWidget {
  const _Detail({required this.o});
  final Map<String, dynamic> o;

  @override
  Widget build(BuildContext context) {
    final pkg = (o['pkg'] as Map?) ?? {};
    Widget row(String k, String v, {bool copy = false}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            SizedBox(width: 110, child: Text(k, style: const TextStyle(color: Colors.grey))),
            Expanded(child: Text(v, style: const TextStyle(fontWeight: FontWeight.w600))),
            if (copy) InkWell(onTap: () { Clipboard.setData(ClipboardData(text: v)); toast(context, 'Disalin'); }, child: const Padding(padding: EdgeInsets.all(4), child: Icon(Icons.copy, size: 16))),
          ]),
        );
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('${pkg['name'] ?? o['package_key']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            StateChip(o['state'] as String? ?? ''),
          ]),
          const SizedBox(height: 10),
          row('TRX ID', '${o['trx']}', copy: true),
          row('Server', '${o['server_name']}'),
          row('Harga', rupiah((o['price'] ?? 0) as num)),
          if (pkg['ram'] != null) row('RAM / Disk', '${sizeLabel(pkg['ram'] as num)} / ${sizeLabel((pkg['disk'] ?? 0) as num)}'),
          row('Dibuat', fdate(o['created_at'])),
          if (o['panel_expires_at'] != null) row('Aktif sampai', fdate(o['panel_expires_at'])),
        ]),
      ),
    );
  }
}
