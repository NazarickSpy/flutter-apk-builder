import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../api.dart';
import '../state.dart';
import '../util.dart';

/// Pembayaran QRIS + pemantauan status pesanan (polling /orders/:id tiap 4 dtk).
class PayScreen extends StatefulWidget {
  const PayScreen({super.key, required this.orderId});
  final int orderId;
  @override
  State<PayScreen> createState() => _PayScreenState();
}

class _PayScreenState extends State<PayScreen> {
  Map<String, dynamic>? _o;
  Uint8List? _qr;
  String? _error, _qrError;
  Timer? _poll, _tick;
  int _left = 0;
  bool _cancelling = false, _loadingQr = false;

  String get _state => (_o?['state'] ?? 'unpaid') as String;

  @override
  void initState() {
    super.initState();
    _first();
    _poll = Timer.periodic(const Duration(seconds: 4), (_) => _refresh());
    _tick = Timer.periodic(const Duration(seconds: 1), (_) => _countdown());
  }

  @override
  void dispose() {
    _poll?.cancel();
    _tick?.cancel();
    super.dispose();
  }

  void _countdown() {
    final e = parseDate(_o?['expires_at']);
    if (e == null || _state != 'unpaid') return;
    final s = e.difference(DateTime.now()).inSeconds;
    if (mounted) setState(() => _left = s < 0 ? 0 : s);
  }

  Future<void> _first() async {
    try {
      final j = Map<String, dynamic>.from(await appState.api.get('/orders/${widget.orderId}?qr=1') as Map);
      if (!mounted) return;
      setState(() { _o = j; _error = null; });
      _countdown();
      if (j['state'] == 'unpaid') _loadQr();
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    }
  }

  Future<void> _loadQr() async {
    if (_loadingQr) return;
    setState(() { _loadingQr = true; _qrError = null; });
    try {
      final b = await appState.api.bytes('/qr/order/${widget.orderId}');
      if (mounted) setState(() => _qr = b);
    } on ApiException catch (e) {
      if (mounted) setState(() => _qrError = e.message);
    } finally {
      if (mounted) setState(() => _loadingQr = false);
    }
  }

  Future<void> _refresh() async {
    if (_o == null || const ['active', 'failed', 'expired', 'cancelled'].contains(_state)) return;
    try {
      final j = Map<String, dynamic>.from(await appState.api.get('/orders/${widget.orderId}') as Map);
      if (!mounted) return;
      final before = _state;
      setState(() { _o = j; _error = null; });
      if (before != j['state']) {
        ordersRev.value++;
        if (j['state'] == 'active') HapticFeedback.mediumImpact();
      }
    } on ApiException catch (e) {
      if (e.status == 404 && mounted) setState(() => _error = e.message);
      // gangguan jaringan sesaat: abaikan, coba lagi pada polling berikutnya
    }
  }

  Future<void> _cancel() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Batalkan pesanan?'),
        content: const Text('QRIS ini tidak boleh dibayar lagi setelah dibatalkan.'),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Tidak')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Batalkan'))],
      ),
    );
    if (ok != true) return;
    setState(() => _cancelling = true);
    try {
      await appState.api.post('/orders/${widget.orderId}/cancel');
      ordersRev.value++;
      await _refresh();
    } on ApiException catch (e) {
      if (mounted) toast(context, e.message);
      await _refresh();
    } finally {
      if (mounted) setState(() => _cancelling = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final o = _o;
    return Scaffold(
      appBar: AppBar(title: const Text('Pembayaran')),
      body: o == null
          ? Center(child: _error != null ? Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center)) : const CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              Box(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('${(o['pkg'] as Map?)?['name'] ?? o['package_key']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    StateChip(_state),
                  ]),
                  const SizedBox(height: 8),
                  _row('TRX ID', '${o['trx']}', copy: true),
                  _row('Server', '${o['server_name']}'),
                  _row('Harga', rupiah((o['price'] ?? 0) as num)),
                  if (o['total'] != null) _row('Total bayar', rupiah((o['total']) as num)),
                ]),
              ),
              if (_state == 'unpaid') ...[
                Box(
                  child: Column(children: [
                    Text(_left > 0 ? 'Bayar dalam ${mmss(_left)}' : 'Menunggu…', style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 12),
                    if (_qr != null)
                      Container(color: Colors.white, padding: const EdgeInsets.all(8), child: Image.memory(_qr!, width: 260, height: 260, fit: BoxFit.contain))
                    else if (_qrError != null)
                      Column(children: [Text(_qrError!, textAlign: TextAlign.center), TextButton(onPressed: _loadQr, child: const Text('Muat ulang QR'))])
                    else
                      const SizedBox(height: 200, child: Center(child: CircularProgressIndicator())),
                    const SizedBox(height: 10),
                    const Text('Scan dengan aplikasi e-wallet / mobile banking apa pun yang mendukung QRIS. Status diperbarui otomatis.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 12)),
                  ]),
                ),
                OutlinedButton.icon(onPressed: _cancelling ? null : _cancel, icon: const Icon(Icons.block), label: const Text('Batalkan pesanan')),
              ],
              if (_state == 'processing')
                const _Note(icon: Icons.hourglass_top, color: Color(0xFF2B6CB0), title: 'Pembayaran diterima', text: 'Server panel sedang dibuat. Biasanya selesai dalam beberapa menit; halaman ini akan berubah otomatis.'),
              if (_state == 'active')
                const _Note(icon: Icons.check_circle, color: Color(0xFF1B8A4B), title: 'Panel aktif', text: 'Buka tab "Panel" untuk melihat URL, username, dan password panel Anda.'),
              if (_state == 'failed')
                const _Note(icon: Icons.error, color: Color(0xFFC53030), title: 'Pesanan bermasalah', text: 'Pembayaran Anda aman. Hubungi bantuan dengan menyebut TRX ID di atas.'),
              if (_state == 'expired' || _state == 'cancelled')
                _Note(icon: Icons.info, color: Colors.grey, title: stateLabel[_state]!, text: 'Pesanan ini tidak berlaku lagi. Silakan buat pesanan baru.'),
            ]),
    );
  }

  Widget _row(String k, String v, {bool copy = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          SizedBox(width: 96, child: Text(k, style: const TextStyle(color: Colors.grey))),
          Expanded(child: Text(v, style: const TextStyle(fontWeight: FontWeight.w600))),
          if (copy) InkWell(onTap: () { Clipboard.setData(ClipboardData(text: v)); toast(context, 'Disalin'); }, child: const Padding(padding: EdgeInsets.all(4), child: Icon(Icons.copy, size: 16))),
        ]),
      );
}

class _Note extends StatelessWidget {
  const _Note({required this.icon, required this.color, required this.title, required this.text});
  final IconData icon;
  final Color color;
  final String title, text;
  @override
  Widget build(BuildContext context) => Box(
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 2), Text(text, style: const TextStyle(fontSize: 13))])),
        ]),
      );
}
