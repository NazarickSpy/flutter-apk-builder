import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../api.dart';
import '../state.dart';
import '../util.dart';

/// Akun panel Pterodactyl yang sudah aktif (GET /panel).
class PanelScreen extends StatefulWidget {
  const PanelScreen({super.key});
  @override
  State<PanelScreen> createState() => _PanelScreenState();
}

class _PanelScreenState extends State<PanelScreen> {
  List<Map<String, dynamic>>? _accounts;
  Map<String, dynamic>? _legacy;
  String? _error;
  final Set<int> _shown = {};

  @override
  void initState() {
    super.initState();
    ordersRev.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    ordersRev.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final j = Map<String, dynamic>.from(await appState.api.get('/panel') as Map);
      final acc = ((j['accounts'] as List?) ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      if (mounted) setState(() { _accounts = acc; _legacy = j['legacy'] is Map ? Map<String, dynamic>.from(j['legacy'] as Map) : null; _error = null; });
    } on ApiException catch (e) {
      if (mounted) setState(() { _error = e.message; _accounts ??= []; });
    }
  }

  Future<void> _open(String url) async {
    final u = Uri.tryParse(url.startsWith('http') ? url : 'https://$url');
    if (u == null) return;
    try {
      await launchUrl(u, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) toast(context, 'Tidak bisa membuka tautan.');
    }
  }

  Widget _field(String k, String? v, {bool secret = false, int idx = 0}) {
    final hide = secret && !_shown.contains(idx);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        SizedBox(width: 78, child: Text(k, style: const TextStyle(color: Colors.grey))),
        Expanded(child: SelectableText(v == null ? '-' : (hide ? '••••••••••' : v), style: const TextStyle(fontWeight: FontWeight.w600, fontFamily: 'monospace'))),
        if (secret && v != null) InkWell(onTap: () => setState(() => hide ? _shown.add(idx) : _shown.remove(idx)), child: Padding(padding: const EdgeInsets.all(4), child: Icon(hide ? Icons.visibility : Icons.visibility_off, size: 18))),
        if (v != null) InkWell(onTap: () { Clipboard.setData(ClipboardData(text: v)); toast(context, 'Disalin'); }, child: const Padding(padding: EdgeInsets.all(4), child: Icon(Icons.copy, size: 16))),
      ]),
    );
  }

  Widget _card(String title, Map<String, dynamic> a, int idx) {
    final pw = a['password'] as String?;
    return Box(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 6),
        _field('URL', a['url'] as String?),
        _field('Username', a['username'] as String?),
        if (a['email'] != null) _field('Email', a['email'] as String?),
        a['unreadable'] == true ? const Text('Password tidak dapat dibaca. Hubungi bantuan.', style: TextStyle(color: Colors.red)) : _field('Password', pw, secret: true, idx: idx),
        if (a['expires_at'] != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text('Aktif sampai ${fdate(a['expires_at'])}', style: const TextStyle(color: Colors.grey, fontSize: 12))),
        if (a['url'] is String && (a['url'] as String).isNotEmpty)
          Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () => _open(a['url'] as String), icon: const Icon(Icons.open_in_new, size: 16), label: const Text('Buka panel'))),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final acc = _accounts;
    return RefreshIndicator(
      onRefresh: _load,
      child: acc == null
          ? ListView(children: const [Padding(padding: EdgeInsets.only(top: 120), child: Center(child: CircularProgressIndicator()))])
          : (acc.isEmpty && _legacy == null)
              ? ListView(children: [Padding(padding: const EdgeInsets.only(top: 120, left: 24, right: 24), child: Center(child: Text(_error ?? 'Belum ada panel aktif. Beli paket di tab Beli.', textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey))))])
              : ListView(padding: const EdgeInsets.all(14), children: [
                  for (var i = 0; i < acc.length; i++) _card('${acc[i]['name']} · ${acc[i]['trx']}', acc[i], i),
                  if (_legacy != null) _card('Akun panel lama', _legacy!, 9999),
                ]),
    );
  }
}
