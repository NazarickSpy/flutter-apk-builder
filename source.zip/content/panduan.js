// Artikel panduan SnowyStore (konten statis, dirender saat build). Isi diselaraskan dengan halaman Syarat & Ketentuan, Bantuan, dan Cara Order.
// Format body: ['h2', judul] | ['p', teks] | ['ul', [butir...]] | ['ol', [langkah...]]
export const ARTICLES = [
  {
    slug: 'apa-itu-panel-pterodactyl', title: 'Apa Itu Panel Pterodactyl dan Cara Memilih Paket RAM yang Tepat', date: '2026-10-17', read: 5, cat: 'Hosting Panel',
    desc: 'Penjelasan singkat tentang Pterodactyl, untuk apa dipakai, dan cara memilih paket RAM server panel 1 GB sampai 10 GB sesuai kebutuhan bot atau aplikasi Anda.',
    intro: 'Pterodactyl adalah panel pengelola server berbasis web yang banyak dipakai untuk menjalankan bot, aplikasi, dan server game. Artikel ini menjelaskan cara kerjanya dan bagaimana memilih paket RAM yang pas sebelum Anda membeli.',
    body: [
      ['h2', 'Apa itu Pterodactyl?'],
      ['p', 'Pterodactyl adalah panel manajemen server open source. Setiap server dijalankan terpisah dalam container sehingga sumber daya seperti RAM, disk, dan CPU dapat dibatasi per server. Anda mengelolanya lewat browser: menyalakan dan mematikan server, membuka konsol, mengunggah file, mengubah variabel startup, dan mengatur pengguna tambahan.'],
      ['h2', 'Untuk apa server panel dipakai?'],
      ['ul', ['Menjalankan bot WhatsApp, Telegram, atau Discord agar aktif 24 jam.', 'Menjalankan aplikasi Node.js atau Python, termasuk API dan layanan kecil.', 'Menjalankan server game seperti Minecraft.', 'Belajar mengelola server tanpa harus mengatur sistem operasi sendiri.']],
      ['h2', 'Cara memilih paket RAM'],
      ['p', 'Di SnowyStore tersedia paket server panel dengan RAM 1 GB sampai 10 GB. Kebutuhan sebenarnya bergantung pada kode dan jumlah pengguna Anda, jadi angka berikut hanya patokan umum, bukan jaminan.'],
      ['ul', ['Bot atau skrip ringan: biasanya cukup dengan paket kecil, mulai dari 1 GB.', 'Aplikasi yang menjalankan browser headless, banyak sesi sekaligus, atau banyak dependensi: pilih RAM yang lebih besar karena pemakaian memori naik cepat.', 'Server game: kebutuhan naik mengikuti jumlah pemain, plugin, atau mod.']],
      ['p', 'Jika ragu, mulailah dari paket yang sesuai perkiraan Anda, lalu pantau pemakaian RAM di panel. Bila server sering kehabisan memori, pesan paket yang lebih besar.'],
      ['h2', 'Hal yang perlu diketahui sebelum membeli'],
      ['ul', ['Setiap paket punya masa aktif. Server dan akun panel dihapus otomatis saat masa aktif berakhir, jadi simpan cadangan data Anda sendiri.', 'Server panel baru berstatus non-garansi. Pesanan yang sudah dibayar tetapi gagal dibuat ditangani dan dananya dikembalikan.', 'Server tidak boleh dipakai untuk aktivitas ilegal, serangan terhadap jaringan atau pihak lain, penipuan, phishing, atau penyebaran malware. Pelanggaran berat dapat membuat server ditangguhkan atau dihapus tanpa pengembalian dana.']],
      ['p', 'Setelah memilih paket, bayar dengan QRIS. Server dibuat otomatis begitu pembayaran terverifikasi, dan data login panel tampil di dashboard Anda.']
    ],
    related: ['cara-bayar-qris', 'garansi-dan-pengembalian-dana']
  },
  {
    slug: 'cara-beli-nomor-virtual-otp', title: 'Cara Membeli Nomor Virtual untuk Menerima OTP dengan Aman', date: '2026-10-17', read: 5, cat: 'Nomor Virtual',
    desc: 'Langkah membeli nomor virtual (Nokos) di SnowyStore, apa yang terjadi bila OTP tidak masuk, serta aturan pemakaian yang perlu Anda ketahui sebelum membayar.',
    intro: 'Nomor virtual berguna untuk menerima kode OTP verifikasi tanpa memakai nomor pribadi. Berikut cara membelinya di SnowyStore, termasuk aturan dan perlindungan dana yang berlaku.',
    body: [
      ['h2', 'Apa itu nomor virtual (Nokos)?'],
      ['p', 'Nomor virtual adalah nomor telepon sementara yang dipakai hanya untuk menerima kode OTP dari aplikasi atau layanan tujuan. Nomor ini tidak untuk dipakai jangka panjang dan tidak untuk menelepon.'],
      ['h2', 'Langkah membeli'],
      ['ol', ['Masuk ke akun Anda lalu buka menu Nomor Virtual (OTP).', 'Pilih server yang tersedia. Pada server Premium Anda juga dapat memilih operator.', 'Pilih aplikasi tujuan, misalnya aplikasi yang meminta verifikasi.', 'Pilih negara nomor, lalu pilih harga yang tersedia.', 'Bayar dengan QRIS sesuai nominal tagihan.', 'Setelah pembayaran terverifikasi, nomor tampil otomatis. Masukkan nomor itu di aplikasi tujuan dan minta kode.', 'Kode OTP muncul di halaman pesanan dan diperbarui otomatis.', 'Bila aplikasi tujuan mengirim kode kedua, tekan Minta OTP kedua di halaman pesanan. Fitur ini gratis dan hanya bisa dipakai sekali, setelah OTP pertama masuk.']],
      ['h2', 'Tips agar OTP berhasil masuk'],
      ['ul', ['Siapkan aplikasi tujuan terlebih dahulu supaya Anda bisa langsung meminta kode setelah nomor muncul, karena ada batas waktu.', 'Pastikan aplikasi dan negara yang dipilih sudah benar sebelum membayar.', 'Tunggu kode tampil di halaman pesanan sebelum meminta kode berulang kali.']],
      ['h2', 'Jika OTP tidak masuk'],
      ['p', 'Bila nomor tidak menerima OTP sampai waktu habis, pesanan berubah menjadi Menunggu pengembalian dana dan admin mengembalikan dana penuh. Hubungi bantuan dengan kode pesanan (diawali NOK) untuk mempercepat prosesnya.'],
      ['h2', 'Aturan yang perlu diperhatikan'],
      ['ul', ['Pesanan yang sudah dibayar tidak dapat dibatalkan.', 'Keberhasilan OTP bergantung pada aplikasi tujuan. Nomor yang sudah menerima kode tidak dapat ditukar atau dikembalikan.', 'Dilarang memakai nomor untuk penipuan, spam, atau aktivitas ilegal. Pelanggaran dapat membuat akun diblokir.']]
    ],
    related: ['cara-bayar-qris', 'garansi-dan-pengembalian-dana']
  },
  {
    slug: 'cara-bayar-qris', title: 'Cara Bayar QRIS di SnowyStore agar Pesanan Terverifikasi Otomatis', date: '2026-10-17', read: 4, cat: 'Pembayaran',
    desc: 'Panduan membayar pesanan dengan QRIS lewat e-wallet atau m-banking, mengapa nominal harus persis, dan apa yang dilakukan bila QRIS tidak muncul atau pesanan belum selesai.',
    intro: 'Semua pesanan di SnowyStore dibayar dengan QRIS dan diproses otomatis setelah pembayaran terverifikasi. Berikut langkah dan hal kecil yang sering membuat pembayaran gagal.',
    body: [
      ['h2', 'Langkah pembayaran'],
      ['ol', ['Buat pesanan: pilih server panel, aplikasi premium, atau nomor virtual.', 'Jendela pembayaran menampilkan kode QRIS dan hitung mundur batas waktu.', 'Buka e-wallet atau aplikasi m-banking apa pun yang mendukung QRIS, lalu pindai kode tersebut.', 'Bayar sesuai nominal yang tertera. Nominal sudah termasuk biaya layanan.', 'Tunggu beberapa saat. Pembayaran terdeteksi otomatis dan pesanan mulai diproses.']],
      ['h2', 'Mengapa nominal harus persis?'],
      ['p', 'QRIS yang dibuat adalah QRIS dinamis untuk satu pesanan. Sistem mencocokkan pembayaran dengan nominal pesanan, sehingga membayar kurang atau lebih dapat membuat pesanan tidak terverifikasi otomatis. Status pembayaran juga diperiksa langsung ke penyedia pembayaran sebelum pesanan diproses.'],
      ['h2', 'Batas waktu dan QRIS kedaluwarsa'],
      ['p', 'Setiap QRIS punya batas waktu dan otomatis hangus setelah kedaluwarsa. Jangan membayar QRIS yang sudah kedaluwarsa atau berasal dari pesanan yang sudah dibatalkan. Jika waktunya habis, buat pesanan baru.'],
      ['h2', 'Jika ada kendala'],
      ['ul', ['QRIS tidak muncul atau terus memuat: tekan Coba lagi, atau tutup lalu buka kembali dari Riwayat Pesanan. Jika masih gagal, batalkan pesanan dan buat yang baru.', 'Sudah membayar tetapi server belum aktif: sistem mencoba membuat server beberapa kali. Jika setelah beberapa menit belum aktif, hubungi bantuan dan sebutkan TRX ID.', 'Sudah membayar tetapi akun premium belum muncul: buka Pesanan Premium Saya lalu Detail. Status Diperiksa admin atau Menunggu pengembalian dana berarti pembayaran Anda aman dan admin akan menyelesaikan pesanan atau mengembalikan dana.']],
      ['h2', 'Membatalkan pesanan'],
      ['p', 'Hanya pesanan berstatus Menunggu Bayar yang dapat dibatalkan, lewat Dashboard atau Riwayat Pesanan. Pesanan yang sudah dibayar tidak dapat dibatalkan.']
    ],
    related: ['garansi-dan-pengembalian-dana', 'apa-itu-panel-pterodactyl']
  },
  {
    slug: 'garansi-dan-pengembalian-dana', title: 'Garansi dan Pengembalian Dana: Apa yang Berlaku di SnowyStore', date: '2026-10-17', read: 5, cat: 'Garansi',
    desc: 'Ringkasan garansi dan pengembalian dana untuk server panel, aplikasi premium, dan nomor virtual, serta cara memakai Portal Garansi dengan TRX ID dan nomor WhatsApp.',
    intro: 'Aturan garansi berbeda untuk tiap layanan. Artikel ini merangkum yang berlaku saat ini supaya Anda tahu hak dan batasannya sebelum membeli. Ketentuan lengkap ada di halaman Syarat dan Ketentuan.',
    body: [
      ['h2', 'Server panel'],
      ['ul', ['Server panel baru berstatus non-garansi dan memiliki masa aktif sesuai paket. Server dihapus otomatis saat masa aktif berakhir.', 'Pesanan yang sudah dibayar tetapi gagal dibuat ditangani dan dananya dikembalikan.', 'Pesanan panel lama (sebelum pembelian melalui Averpay) memakai garansi operasional 30 hari, satu kali klaim per pesanan, melalui Portal Garansi.', 'Garansi tidak berlaku untuk pelanggaran aturan atau server yang dihapus sendiri oleh pengguna.']],
      ['h2', 'Aplikasi premium'],
      ['p', 'Garansi aplikasi premium mengikuti deskripsi masing-masing produk, termasuk masa aktif dan batas perangkat. Baca deskripsi sebelum membeli. Pesanan yang pasti gagal diproses dikembalikan dananya secara penuh oleh admin, sedangkan pesanan yang hasilnya belum pasti diperiksa admin terlebih dahulu. Data akun yang sudah dikirim tidak dapat ditukar, kecuali dijamin oleh deskripsi produk.'],
      ['h2', 'Nomor virtual'],
      ['p', 'Jika OTP tidak masuk sampai waktu habis, dana dikembalikan penuh oleh admin. Nomor yang sudah menerima kode tidak dapat ditukar atau dikembalikan.'],
      ['h2', 'Cara memakai Portal Garansi'],
      ['ol', ['Buka halaman Portal Garansi.', 'Masukkan TRX ID pesanan dan nomor WhatsApp yang terdaftar di akun Anda. Keduanya harus cocok untuk verifikasi kepemilikan.', 'Periksa status pesanan dan masa garansinya.', 'Jika memenuhi syarat, ajukan klaim dan jelaskan kendalanya dengan singkat dan jelas.']],
      ['h2', 'Mempercepat penanganan'],
      ['p', 'Saat menghubungi bantuan, sertakan kode pesanan: TRX ID untuk server panel, PRM untuk aplikasi premium, atau NOK untuk nomor virtual. Dengan kode itu admin dapat langsung menemukan pesanan Anda.']
    ],
    related: ['cara-bayar-qris', 'tips-keamanan-akun']
  },
  {
    slug: 'tips-keamanan-akun', title: 'Tips Mengamankan Akun SnowyStore, Server Panel, dan Akun Premium Anda', date: '2026-10-17', read: 4, cat: 'Keamanan',
    desc: 'Kebiasaan sederhana untuk menjaga akun toko, login server panel, dan data akun premium dari pembajakan, phishing, dan kehilangan data.',
    intro: 'Sebagian besar masalah keamanan akun berasal dari kebiasaan, bukan celah teknis. Berikut langkah praktis yang bisa Anda lakukan hari ini.',
    body: [
      ['h2', 'Jaga kata sandi'],
      ['ul', ['Gunakan kata sandi yang panjang dan unik, jangan sama dengan akun lain.', 'Jangan membagikan kata sandi kepada siapa pun, termasuk orang yang mengaku sebagai admin.', 'Kerugian akibat kelalaian menjaga kredensial menjadi tanggung jawab pengguna sesuai Syarat dan Ketentuan.']],
      ['h2', 'Aktifkan perlindungan tambahan'],
      ['p', 'Buka halaman Profil, tab Keamanan, untuk melihat pengaturan keamanan akun dan mengaktifkan verifikasi dua langkah bila tersedia. Verifikasi dua langkah membuat akun tetap aman walau kata sandi bocor.'],
      ['h2', 'Server panel'],
      ['ul', ['Password panel tampil di Dashboard, Akun Panel. Anda dapat menggantinya langsung di panel setelah login.', 'Simpan cadangan file dan database Anda sendiri secara berkala, karena server dihapus otomatis saat masa aktif berakhir.', 'Perbarui dependensi aplikasi Anda dan jangan menaruh token atau kunci rahasia di tempat yang bisa diakses umum.']],
      ['h2', 'Akun aplikasi premium'],
      ['ul', ['Baca deskripsi produk: masa aktif, garansi, dan batas perangkat berlaku sesuai deskripsi.', 'Ikuti petunjuk produk saat masuk, dan hindari mengubah data akun bila deskripsi melarangnya.', 'Simpan data akun yang tampil di halaman pesanan di tempat yang aman.']],
      ['h2', 'Waspada phishing'],
      ['p', 'Selalu periksa alamat situs sebelum login. Jangan klik tautan pembayaran dari pihak yang tidak dikenal, dan jangan membayar QRIS dari pesanan yang sudah dibatalkan atau kedaluwarsa. Aktivitas mencurigakan pada akun dapat membuat akun diblokir demi keamanan.'],
      ['h2', 'Jika curiga akun disusupi'],
      ['p', 'Segera ganti kata sandi, periksa Riwayat Pesanan untuk transaksi yang tidak Anda kenali, lalu hubungi bantuan dengan detail yang Anda ketahui.']
    ],
    related: ['garansi-dan-pengembalian-dana', 'apa-itu-panel-pterodactyl']
  }
];
export const bySlug = (s) => ARTICLES.find((a) => a.slug === s);
export const fmtDate = (iso) => new Date(iso + 'T00:00:00+07:00').toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' });
export const wordCount = (a) => [a.intro, ...a.body.map(([t, v]) => (Array.isArray(v) ? v.join(' ') : v))].join(' ').split(/\s+/).length;
