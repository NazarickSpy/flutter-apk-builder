// Menyiapkan folder android/ hasil `flutter create` agar app bisa terhubung ke server:
//   - izin INTERNET (tanpa ini APK release tidak bisa konek sama sekali)
//   - nama app "SnowyStore"
//   - <queries> agar url_launcher bisa membuka link/WhatsApp (Android 11+)
//   - minSdk 23 (dibutuhkan flutter_secure_storage)
//   - opsional --cleartext: izinkan http:// (hanya untuk server uji coba tanpa HTTPS)
// Jalankan:  dart run tool/patch_android.dart [--cleartext]
import 'dart:io';

void main(List<String> args) {
  final cleartext = args.contains('--cleartext');
  final manifest = File('android/app/src/main/AndroidManifest.xml');
  if (!manifest.existsSync()) {
    stderr.writeln('android/ belum ada. Jalankan dulu: flutter create --platforms=android --org id.snowystore .');
    exit(1);
  }
  var m = manifest.readAsStringSync();

  if (!m.contains('android.permission.INTERNET')) {
    m = m.replaceFirstMapped(RegExp(r'<manifest[^>]*>'), (x) => '${x[0]}\n    <uses-permission android:name="android.permission.INTERNET"/>');
    stdout.writeln('+ izin INTERNET');
  }
  m = m.replaceFirst(RegExp(r'android:label="[^"]*"'), 'android:label="SnowyStore"');
  if (!m.contains('<queries>')) {
    m = m.replaceFirst(
      '</manifest>',
      '    <queries>\n'
      '        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>\n'
      '        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="http"/></intent>\n'
      '    </queries>\n</manifest>',
    );
    stdout.writeln('+ queries url_launcher');
  }
  if (cleartext && !m.contains('usesCleartextTraffic')) {
    m = m.replaceFirst('<application', '<application\n        android:usesCleartextTraffic="true"');
    stdout.writeln('+ cleartext (http) diizinkan');
  }
  manifest.writeAsStringSync(m);

  for (final name in ['android/app/build.gradle.kts', 'android/app/build.gradle']) {
    final f = File(name);
    if (!f.existsSync()) continue;
    var g = f.readAsStringSync();
    final before = g;
    g = g.replaceAll(RegExp(r'minSdk(Version)?\s*=\s*flutter\.minSdkVersion'), 'minSdk = 23');
    g = g.replaceAll(RegExp(r'minSdkVersion\s+flutter\.minSdkVersion'), 'minSdkVersion 23');
    if (g != before) {
      f.writeAsStringSync(g);
      stdout.writeln('+ minSdk 23 ($name)');
    }
  }
  stdout.writeln('Android siap.');
}
