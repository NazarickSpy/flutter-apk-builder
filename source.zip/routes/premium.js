// Route Aplikasi Premium (pembayaran QRIS langsung per pesanan). Dipasang dari api.js dengan helper yang sama (auth, wrap, limiter, validasi).
const { z } = require('zod');
const premium = require('../lib/premium'), settings = require('../lib/settings'), safefetch = require('../lib/safefetch');
// Cache gambar produk di memori (penyedia hanya diakses sekali per produk per jam): maks 80 gambar / 20MB
const IMG = new Map(), IMG_BAD = new Map(); let imgBytes = 0; const IMG_TTL = 3600e3;
function imgPut(id, v) { IMG.set(id, v); imgBytes += v.body.length; while ((IMG.size > 80 || imgBytes > 20 * 1048576) && IMG.size) { const k = IMG.keys().next().value; imgBytes -= IMG.get(k).body.length; IMG.delete(k); } }
module.exports = ({ auth, adm, wrap, parse, limiter, notMaint, svcOn, intId, audit }) => {
  const router = require('express').Router();
  const fail = (res, e) => { if (e && e.http) return res.status(e.http).json({ error: e.message, ...(e.price ? { price: e.price } : {}) }); throw e; };
  const out = (o) => (o.status === 'awaiting_payment' ? { ...o, qr_image: `/api/qr/premium/${o.id}` } : o); // URL QR milik gateway tidak pernah dikirim ke browser

  // ----- katalog: hanya produk yang boleh dijual; modal tidak pernah dikirim; gambar lewat proxy server -----
  router.get('/premium/products', auth, wrap(async (_q, res) => {
    let cat; try { cat = await premium.catalog(); } catch (e) { console.error('[premium] katalog:', e.message); return res.status(503).json({ error: 'Katalog sedang tidak bisa dimuat. Coba lagi sebentar lagi.' }); }
    const c = await premium.cfg();
    res.json({ stale: cat.stale, max_qty: premium.maxQty(), items: cat.items.filter((p) => premium.sellable(p, c)).map((p) => ({ id: p.id, name: p.name, price: premium.priceFor(p.cost, c), stock: p.stock, desc: p.desc, category: p.category, needs_input: p.needs_input, image: p.image ? `/api/premium/img/${encodeURIComponent(p.id)}` : null })) });
  }));
  // Gambar produk: hanya untuk ID produk yang ada di katalog (bukan proxy URL bebas) + perlindungan SSRF + cache
  router.get('/premium/img/:id', auth, limiter(300, 5), async (req, res) => {
    try {
      const id = String(req.params.id).slice(0, 40), hit = IMG.get(id);
      res.set('Cache-Control', 'private, max-age=86400');
      if (hit && Date.now() - hit.t < IMG_TTL) return res.type(hit.type).send(hit.body);
      if ((IMG_BAD.get(id) || 0) > Date.now()) return res.set('Cache-Control', 'public, max-age=300').status(404).end(); // gambar bermasalah: jangan unduh ulang tiap request
      const url = await premium.imageUrl(id); if (!url) return res.status(404).end();
      const img = await safefetch.fetchImage(url, { max: 5 * 1024 * 1024 }); imgPut(id, { ...img, t: Date.now() });
      res.type(img.type).send(img.body);
    } catch (e) { if (e && e.blocked) console.error('[premium] gambar ditolak:', e.message, '(produk', id + ')'); IMG_BAD.set(id, Date.now() + 10 * 60e3); if (IMG_BAD.size > 500) IMG_BAD.delete(IMG_BAD.keys().next().value); res.set('Cache-Control', 'no-store').status(502).end(); }
  });

  // ----- pesanan -----
  router.post('/premium/orders', auth, require('../lib/idem')('premium'), notMaint, svcOn('premium'), limiter(10, 10), wrap(async (req, res) => {
    const d = parse(z.object({ product_id: z.string().min(1).max(40), qty: z.number().int().min(1).max(50).default(1), price: z.number().int().positive().optional(), email: z.string().trim().max(160).optional() }), req.body, res); if (!d) return;
    try { res.json(out(await premium.create(req.user, d))); } catch (e) { return fail(res, e); }
  }));
  router.get('/premium/orders', auth, wrap(async (req, res) => res.json((await premium.listOwn(req.user.id)).map(out))));
  router.get('/premium/orders/:id', auth, wrap(async (req, res) => { const o = await premium.view(req.user.id, intId(req.params.id)); if (!o) return res.status(404).json({ error: 'Pesanan tidak ditemukan' }); res.json(out(o)); }));
  router.post('/premium/orders/:id/cancel', auth, limiter(30), wrap(async (req, res) => {
    const r = await premium.cancel(req.user.id, intId(req.params.id));
    if (r.code === 404) return res.status(404).json({ error: 'Pesanan tidak ditemukan' });
    if (r.code === 409) return res.status(409).json({ error: ['processing', 'pending_provider', 'done'].includes(r.state) ? 'Pembayaran sudah diterima, pesanan tidak bisa dibatalkan' : 'Pesanan sudah tidak menunggu pembayaran', state: r.state });
    res.json({ ok: true });
  }));
  router.post('/premium/orders/clear', auth, limiter(20), wrap(async (req, res) => res.json({ ok: true, removed: await premium.hideAll(req.user.id) }))); // harus sebelum rute /:id
  router.delete('/premium/orders/:id', auth, limiter(60), wrap(async (req, res) => {
    if (!(await premium.hide(req.user.id, intId(req.params.id)))) return res.status(409).json({ error: 'Pesanan ini belum bisa dihapus dari riwayat (masih berjalan atau perlu penanganan)' });
    res.json({ ok: true }); // hanya disembunyikan dari akun Anda; data tetap tersimpan
  }));

  // ----- admin -----
  router.get('/admin/premium/probe', ...adm, wrap(async (_q, res) => res.json(await premium.probe())));
  router.get('/admin/premium/catalog', ...adm, wrap(async (_q, res) => { try { res.json(await premium.adminCatalog()); } catch (e) { res.status(503).json({ error: 'Katalog penyedia tidak bisa dimuat' }); } }));
  router.get('/admin/premium/orders', ...adm, wrap(async (_q, res) => res.json(await premium.listAll())));
  router.post('/admin/premium/orders/:id/resolve', ...adm, limiter(60), wrap(async (req, res) => {
    const id = intId(req.params.id), d = parse(z.object({ action: z.enum(['refunded', 'done', 'retry']), note: z.string().trim().max(150).optional() }), req.body, res); if (!d || !id) return;
    const r = await premium.resolve(id, d.action, d.note);
    if (!r.ok) return res.status(409).json({ error: d.action === 'retry' ? 'Kirim ulang hanya untuk pesanan "Menunggu pengembalian dana"' : 'Pesanan tidak dalam status yang bisa diselesaikan' });
    await audit(req.user.id, 'prm-' + d.action, id, d.note); res.json({ ok: true, status: r.status });
  }));
  router.get('/admin/premium/settings', ...adm, wrap(async (_q, res) => { const c = await premium.cfg(); res.json({ pct: c.pct, min: c.min, hidden: [...c.hidden].join(','), allow: [...c.allow].join(',') }); }));
  router.post('/admin/premium/settings', ...adm, wrap(async (req, res) => {
    const d = parse(z.object({ pct: z.number().min(0).max(500), min: z.number().int().min(0).max(1000000), hidden: z.string().trim().max(300).optional(), allow: z.string().trim().max(300).optional() }), req.body, res); if (!d) return;
    await settings.set('premium_margin_pct', String(d.pct)); await settings.set('premium_margin_min', String(d.min)); await settings.set('premium_hidden', d.hidden || ''); await settings.set('premium_allow', d.allow || '');
    await audit(req.user.id, 'prm-settings', null, `margin ${d.pct}% min ${d.min}`); res.json({ ok: true });
  }));
  return router;
};
