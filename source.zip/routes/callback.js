const router = require('express').Router(), { z } = require('zod'), rateLimit = require('express-rate-limit');
const { pool } = require('../lib/db'), order = require('../lib/order'), premium = require('../lib/premium'), nokos = require('../lib/nokos');
// Webhook Averpay: POST /webhook/averpay  body { event, data:{ invoice_id,... }, timestamp }  (timeout 5 dtk, tanpa retry)
// Payload TIDAK dipercaya: hanya pemicu, status SELALU diverifikasi ulang lewat GET /api/invoice/status. Aman dipanggil berkali-kali (idempotent).
// Balas 200 DULU baru proses: membuat server bisa >5 dtk dan gateway tidak mengulang.
const body = z.object({ event: z.string().max(40).optional(), data: z.object({ invoice_id: z.string().max(80).optional() }).passthrough().optional() }).passthrough();
const busy = new Set(); // satu invoice hanya diproses satu kali pada satu waktu (webhook ganda/berurutan cepat)
async function handle(tx) {
  if (busy.has(tx)) return; busy.add(tx);
  try { await handle1(tx); } finally { setTimeout(() => busy.delete(tx), 1500); }
}
async function handle1(tx) {
  const [[o]] = await pool.execute(`SELECT ${order.LIGHT} FROM orders WHERE transaction_id=?`, [tx]);
  if (o) { const n = await order.refresh(o); await order.late(n); return; }
  const [[p]] = await pool.execute('SELECT * FROM premium_orders WHERE invoice_id=?', [tx]); // pembayaran aplikasi premium
  if (p) { const n = await premium.refresh(p); await premium.late(n); return; }
  const [[k]] = await pool.execute('SELECT * FROM nokos_orders WHERE invoice_id=?', [tx]); // pembayaran nomor virtual (Nokos)
  if (k) { const n = await nokos.refresh(k); await nokos.late(n); }
}
// Opsional (disarankan): isi WEBHOOK_TOKEN di .env lalu daftarkan URL webhook di Averpay dengan ?token=ISI_TOKEN. Tanpa token yang benar, request diabaikan.
const tokenOk = (req) => { const want = process.env.WEBHOOK_TOKEN; if (!want) return true; const got = String(req.query.token || req.get('x-webhook-token') || ''); const a = Buffer.from(got), b = Buffer.from(want); return a.length === b.length && require('crypto').timingSafeEqual(a, b); };
router.post(['/webhook/averpay', '/api/webhook/averpay'], rateLimit({ windowMs: 60e3, max: 120 }), (req, res) => {
  if (!tokenOk(req)) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true });
  const p = body.safeParse(req.body), tx = p.success && p.data.data && p.data.data.invoice_id;
  if (!tx || (p.data.event && p.data.event !== 'deposit.paid')) return; // event withdraw.* dll. tidak relevan
  handle(String(tx)).catch((e) => console.error('webhook:', e.message));
});
module.exports = router;
