// Route Nokos (nomor virtual untuk OTP). Pembayaran QRIS langsung per pesanan; nomor dipesan dari Averpay SETELAH pembayaran terverifikasi.
// Dipasang dari api.js dengan helper yang sama (auth, wrap, limiter, validasi).
const { z } = require('zod');
const nokos = require('../lib/nokos'), settings = require('../lib/settings');
module.exports = ({ auth, adm, wrap, parse, limiter, notMaint, svcOn, intId, audit }) => {
  const router = require('express').Router();
  const fail = (res, e) => { if (e && e.http) return res.status(e.http).json({ error: e.message, ...(e.price ? { price: e.price } : {}) }); throw e; };
  const out = (o) => (o.status === 'awaiting_payment' ? { ...o, qr_image: `/api/qr/nokos/${o.id}` } : o); // URL QR milik gateway tidak pernah dikirim ke browser
  const unavailable = (res, what) => res.status(503).json({ error: `Daftar ${what} sedang tidak bisa dimuat. Coba lagi sebentar lagi.` });

  // ----- katalog bertahap (aturan Averpay: server -> aplikasi -> negara -> harga). Modal & quote_id tidak pernah dikirim ke browser. -----
  const SRV = z.string().trim().toLowerCase().regex(/^[a-z0-9_]{2,20}$/), SVC = z.string().trim().regex(/^[A-Za-z0-9][A-Za-z0-9_.-]{0,59}$/), CTY = z.string().trim().toLowerCase().regex(/^[a-z0-9_-]{1,10}$/), PID = z.string().trim().regex(/^[A-Za-z0-9_.:-]{1,120}$/);
  router.get('/nokos/servers', auth, limiter(120, 5), wrap(async (_q, res) => { try { const r = await nokos.servers(); res.json({ stale: r.stale, items: r.items, operators: nokos.OPERATORS }); } catch (e) { console.error('[nokos] server:', e.message); unavailable(res, 'server'); } }));
  router.get('/nokos/services', auth, limiter(120, 5), wrap(async (req, res) => { const d = parse(z.object({ server: SRV }), req.query, res); if (!d) return; try { const r = await nokos.services(d.server); res.json({ stale: r.stale, items: r.items }); } catch (e) { console.error('[nokos] aplikasi:', e.message); unavailable(res, 'aplikasi'); } }));
  router.get('/nokos/countries', auth, limiter(120, 5), wrap(async (_q, res) => { try { const r = await nokos.countries(); res.json({ stale: r.stale, items: r.items }); } catch (e) { console.error('[nokos] negara:', e.message); unavailable(res, 'negara'); } }));
  router.get('/nokos/products', auth, limiter(120, 5), wrap(async (req, res) => {
    const d = parse(z.object({ server: SRV, service: SVC, country: CTY }), req.query, res); if (!d) return;
    try {
      const [r, c] = [await nokos.products(d.server, d.service, d.country), await nokos.cfg()], label = nokos.SERVERS[d.server] || d.server;
      res.json({ stale: r.stale, items: r.items.filter((p) => p.stock !== 0 && p.quote).map((p, i) => ({ id: p.id, name: p.name || `Nomor ${label} #${i + 1}`, price: nokos.priceFor(p.cost, c), stock: p.stock })) });
    } catch (e) { console.error('[nokos] harga:', e.message); unavailable(res, 'harga'); }
  }));

  // ----- pesanan -----
  router.post('/nokos/orders', auth, require('../lib/idem')('nokos'), notMaint, svcOn('nokos'), limiter(10, 10), wrap(async (req, res) => {
    const d = parse(z.object({ server: SRV, service: SVC, country: CTY, product_id: PID, operator: z.enum(['any', 'telkomsel', 'indosat', 'axis', 'three', 'smartfren', 'byu']).optional(), price: z.number().int().positive().optional() }), req.body, res); if (!d) return;
    try { res.json(out(await nokos.create(req.user, d))); } catch (e) { return fail(res, e); }
  }));
  router.get('/nokos/orders', auth, wrap(async (req, res) => res.json((await nokos.listOwn(req.user.id)).map(out))));
  router.get('/nokos/orders/:id', auth, limiter(240, 5), wrap(async (req, res) => { const o = await nokos.view(req.user.id, intId(req.params.id)); if (!o) return res.status(404).json({ error: 'Pesanan tidak ditemukan' }); res.set('Cache-Control', 'no-store'); res.json(out(o)); }));
  router.post('/nokos/orders/:id/cancel', auth, limiter(30), wrap(async (req, res) => {
    const r = await nokos.cancel(req.user.id, intId(req.params.id));
    if (r.code === 404) return res.status(404).json({ error: 'Pesanan tidak ditemukan' });
    if (r.code === 409) return res.status(409).json({ error: ['processing', 'waiting_otp', 'done'].includes(r.state) ? 'Pembayaran sudah diterima, pesanan tidak bisa dibatalkan' : 'Pesanan sudah tidak menunggu pembayaran', state: r.state });
    res.json({ ok: true });
  }));
  router.post('/nokos/orders/:id/resend', auth, limiter(10, 10), wrap(async (req, res) => { // OTP kedua: maksimal sekali, gratis
    const x = await nokos.resend(req.user.id, intId(req.params.id));
    if (x.code === 404) return res.status(404).json({ error: 'Pesanan tidak ditemukan' });
    if (x.code !== 200) return res.status(x.code).json({ error: x.error });
    res.json({ ok: true });
  }));
  router.post('/nokos/orders/clear', auth, limiter(20), wrap(async (req, res) => res.json({ ok: true, removed: await nokos.hideAll(req.user.id) }))); // harus sebelum rute /:id
  router.delete('/nokos/orders/:id', auth, limiter(60), wrap(async (req, res) => {
    if (!(await nokos.hide(req.user.id, intId(req.params.id)))) return res.status(409).json({ error: 'Pesanan ini belum bisa dihapus dari riwayat (masih berjalan atau perlu penanganan)' });
    res.json({ ok: true }); // hanya disembunyikan dari akun Anda; data tetap tersimpan
  }));

  // ----- admin -----
  router.get('/admin/nokos/orders', ...adm, wrap(async (_q, res) => res.json(await nokos.listAll())));
  router.post('/admin/nokos/orders/:id/resolve', ...adm, limiter(60), wrap(async (req, res) => {
    const id = intId(req.params.id), d = parse(z.object({ action: z.enum(['refunded', 'done', 'retry', 'cancel_number']), note: z.string().trim().max(150).optional() }), req.body, res); if (!d || !id) return;
    const r = await nokos.resolve(id, d.action, d.note);
    if (!r.ok) return res.status(409).json({ error: r.error || (d.action === 'retry' ? 'Ganti nomor hanya untuk pesanan "Menunggu pengembalian dana"' : 'Pesanan tidak dalam status yang bisa diselesaikan') });
    await audit(req.user.id, 'nok-' + d.action, id, d.note); res.json({ ok: true, status: r.status });
  }));
  router.get('/admin/nokos/settings', ...adm, wrap(async (_q, res) => { const c = await nokos.cfg(); res.json({ pct: c.pct, min: c.min }); }));
  router.post('/admin/nokos/settings', ...adm, wrap(async (req, res) => {
    const d = parse(z.object({ pct: z.number().min(0).max(500), min: z.number().int().min(0).max(1000000) }), req.body, res); if (!d) return;
    await settings.set('nokos_margin_pct', String(d.pct)); await settings.set('nokos_margin_min', String(d.min));
    await audit(req.user.id, 'nok-settings', null, `margin ${d.pct}% min ${d.min}`); res.json({ ok: true });
  }));
  return router;
};
