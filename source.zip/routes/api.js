const router = require('express').Router();
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), rateLimit = require('express-rate-limit'), crypto = require('crypto');
const { z } = require('zod');
const { pool } = require('../lib/db'), panel = require('../lib/panel'), ptero = require('../lib/ptero'), averpay = require('../lib/averpay'), order = require('../lib/order'), warranty = require('../lib/warranty');
const { enc, dec } = require('../lib/crypto'), settings = require('../lib/settings'), worker = require('../lib/worker');

const RESERVED = ['admin', 'root', 'administrator', 'support', 'staff', 'snowy', 'snowystore', 'system'];
const limiter = (max, min = 15) => rateLimit({ windowMs: min * 60e3, max, standardHeaders: true, legacyHeaders: false, message: { error: 'Terlalu banyak percobaan, coba lagi nanti' } });
const prod = process.env.NODE_ENV === 'production';
const session = require('../lib/session'), turnstile = require('../lib/turnstile');
const origins = () => [process.env.APP_URL, ...(process.env.EXTRA_ORIGINS || '').split(',')].map((s) => (s || '').trim().replace(/\/+$/, '').toLowerCase()).filter(Boolean);
// Origin dianggap sah bila host-nya sama dengan host yang diakses browser (same-origin, lewat reverse proxy pun) atau terdaftar di APP_URL/EXTRA_ORIGINS.
// Jadi login/daftar tidak lagi "Forbidden" hanya karena APP_URL di .env belum/salah diisi.
function sameOrigin(req, origin) {
  let host; try { host = new URL(origin).host.toLowerCase(); } catch { return false; }
  const hosts = [req.get('x-forwarded-host'), req.get('host')].filter(Boolean).map((h) => h.split(',')[0].trim().toLowerCase());
  return hosts.includes(host) || origins().includes(origin.replace(/\/+$/, '').toLowerCase());
}
const newRef = () => `SNW${Date.now().toString(36)}${crypto.randomBytes(4).toString('hex')}`.toUpperCase();

// Respons API tidak boleh di-cache (berisi data pribadi/QR)
router.use((_q, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
// CSRF: SameSite=strict + wajib header custom + cek Origin pada request yang mengubah data
router.use((req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (req.get('x-requested-with') !== 'snowy' || (origin && !sameOrigin(req, origin))) return res.status(403).json({ error: 'Forbidden' });
  next();
});

const ADMIN_HOURS = Math.min(168, Math.max(1, +process.env.ADMIN_SESSION_HOURS || 12));
// 401 HANYA untuk sesi tidak valid. Masalah DB/server => 503 supaya UI tidak salah menendang user ke halaman login.
const auth = async (req, res, next) => {
  let p; try { p = session.verify(session.read(req)); } catch { return res.status(401).json({ error: 'Belum login' }); }
  let u;
  try { [[u]] = await pool.execute('SELECT id,username,email,whatsapp,role,ptero_user_id,banned,created_at,pv FROM users WHERE id=?', [p.uid]); }
  catch (e) { console.error('auth:', e.message); return res.status(503).json({ error: 'Server sedang sibuk, coba lagi' }); }
  if (!u || u.banned || (p.pv || 0) !== u.pv) return res.status(401).json({ error: 'Belum login' }); // sesi lama mati setelah password diganti
  if (u.role === 'admin' && Date.now() / 1000 - (p.iat || 0) > ADMIN_HOURS * 3600) return res.status(401).json({ error: 'Sesi admin berakhir. Silakan masuk lagi.' }); // sesi admin pendek & tidak diperpanjang otomatis: jika cookie dicuri, masa pakainya terbatas
  if (session.shouldRenew(p)) session.issue(res, u.id, u.pv); // sesi geser: pengguna aktif tidak perlu login ulang
  req.user = u; next();
};
// Mode pemeliharaan: order baru ditolak dengan pesan jelas (admin tetap bisa). Login, riwayat, garansi, dan pesanan berjalan tidak terganggu.
const notMaint = async (req, res, next) => {
  try { if (req.user.role !== 'admin' && (await settings.maintenance())) return res.status(503).json({ error: (await settings.get('maintenance_msg')) || 'Sedang pemeliharaan. Order baru dibuka kembali sebentar lagi.', maintenance: true }); } catch {}
  next();
};
// Saklar per layanan (panel | premium | nokos | garansi) yang dikendalikan admin; admin sendiri tetap bisa memakai layanan (untuk uji coba)
const SVC_LABEL = { panel: 'Pembelian panel', premium: 'Aplikasi premium', nokos: 'Nomor virtual (Nokos)', garansi: 'Klaim garansi' };
const svcOn = (name) => async (req, res, next) => {
  try { if (!req.user || req.user.role !== 'admin') { const sv = await settings.service(name); if (!sv.on) return res.status(503).json({ error: sv.msg || `${SVC_LABEL[name]} sedang dinonaktifkan sementara. Coba lagi nanti.`, service: name, off: true }); } } catch {}
  next();
};
const admin = (req, res, next) => (req.user.role === 'admin' ? next() : res.status(403).json({ error: 'Forbidden' }));
// Semua handler dibungkus timeout 30 dtk: lebih baik error jelas daripada "Memuat…" selamanya
const wrap = (fn) => (req, res) => {
  const t = setTimeout(() => { if (!res.headersSent) res.status(503).json({ error: 'Server lambat merespons, coba lagi', ref: req.id }); }, 30000);
  Promise.resolve().then(() => fn(req, res)).catch((e) => { console.error(`[${req.id}]`, e.message); if (!res.headersSent) res.status(500).json({ error: 'Terjadi kesalahan server', ref: req.id }); }).finally(() => clearTimeout(t));
};
const parse = (schema, body, res) => { const r = schema.safeParse(body); if (!r.success) { res.status(400).json({ error: r.error.issues[0].message }); return null; } return r.data; };
const intId = (v) => { const n = +v; return Number.isInteger(n) && n > 0 ? n : 0; };
// ----- log aktivitas keamanan akun -----
const clip = (v, n) => String(v || '').slice(0, n);
const evt = (req, userId, type) => pool.execute('INSERT INTO events(user_id,type,ip,ua) VALUES(?,?,?,?)', [userId, type, clip(req.ip, 45), clip(req.get('user-agent'), 160)]).catch((e) => console.error('evt:', e.message));
const notify = require('../lib/notify'), live = require('../lib/live'), { maskIp, parseUa } = notify;
// Kebijakan password seragam (daftar & ganti password): min 8, tidak mengandung username, bukan password yang terlalu umum
const WEAK = ['sayangku', 'rahasia123', 'indonesia', 'indonesia1', 'bismillah', 'bismillah1', 'jakarta123', 'password123', 'passw0rd', 'p@ssw0rd', 'welcome1', 'letmein1', 'snowystore', 'snowystore1', '12345678', '123456789', '1234567890', 'password', 'password1', 'qwertyui', 'qwerty123', '11111111', '00000000', 'abcd1234', 'iloveyou', 'admin123'];
const trivial = (v) => /^(.)\1+$/.test(v) || /^(?:0123456789|1234567890|abcdefghij|qwertyuiop|asdfghjkl|zxcvbnm)/i.test(v) || /^(?:123456|12345678|87654321|987654321)$/.test(v) || new Set(v).size < 4; // 'aaaaaaaa', urutan keyboard/angka, atau <4 karakter unik
const strongPw = (v, username) => !WEAK.includes(String(v).toLowerCase()) && !trivial(String(v)) && !(username && username.length >= 4 && String(v).toLowerCase().includes(String(username).toLowerCase()));


router.get('/packages', wrap(async (_q, res) => { res.set('Cache-Control', 'public, max-age=60'); res.json(await panel.list()); })); // paket & harga dari Averpay Panel Hosting (+margin); modal tidak ikut dikirim

// ===== AKUN =====
const reg = z.object({
  username: z.string().regex(/^[a-z0-9]{4,20}$/, 'Username 4-20 huruf kecil/angka').refine((v) => !RESERVED.includes(v), 'Username tidak tersedia'),
  email: z.string().email().max(120).toLowerCase(),
  whatsapp: z.string().regex(/^0\d{9,14}$/, 'Nomor WhatsApp tidak valid'),
  password: z.string().min(8, 'Password minimal 8 karakter').max(72)
});
const human = async (req, res) => { // Cloudflare Turnstile (jika diaktifkan): diperiksa SEBELUM query DB / bcrypt agar bot ditolak murah
  const v = await turnstile.verify(req.body && req.body.cf, req.ip); if (v.ok) return true;
  res.status(400).json({ error: v.reason === 'unreachable' ? 'Verifikasi keamanan tidak dapat dihubungi. Coba lagi sebentar lagi.' : 'Verifikasi keamanan gagal. Muat ulang halaman lalu coba lagi.', captcha: true }); return false;
};
router.post('/register', limiter(5, 60), wrap(async (req, res) => {
  if (!(await human(req, res))) return;
  const d = parse(reg, req.body, res); if (!d) return;
  if (!strongPw(d.password, d.username)) return res.status(400).json({ error: 'Password terlalu mudah ditebak. Gunakan kombinasi yang lebih unik dan jangan memuat username.' });
  const hash = await bcrypt.hash(d.password, 12);
  try { await pool.execute('INSERT INTO users(username,email,whatsapp,pass_hash) VALUES(?,?,?,?)', [d.username, d.email, d.whatsapp, hash]); }
  catch (e) { if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Username/email sudah terdaftar' }); throw e; }
  res.json({ ok: true });
}));
const DUMMY = bcrypt.hashSync('dummy-timing', 12);
// Percobaan login untuk username yang TIDAK ada dihitung & dikunci persis seperti akun asli: penyerang tak bisa membedakan akun yang ada lewat pesan "terkunci"
const unk = new Map(), unkKey = (s) => String(s).toLowerCase().slice(0, 120), unkLocked = (k) => { const e = unk.get(k); return !!e && e.until > Date.now(); };
const unkFail = (k) => { const e = unk.get(k) || { n: 0, until: 0 }; e.n++; if (e.n >= 5) e.until = Date.now() + 15 * 60e3; unk.set(k, e); if (unk.size > 5000) unk.delete(unk.keys().next().value); };
const LOCKMSG = 'Akun terkunci sementara (terlalu banyak percobaan). Coba 15 menit lagi.';
const DEF_ANN = 'SnowyStore — server panel Pterodactyl dan aplikasi premium. Bayar dengan QRIS, pesanan diproses otomatis.';
router.get('/config', wrap(async (_q, res) => {
  res.set('Cache-Control', 'public, max-age=10'); // tidak personal; pendek agar saklar layanan/pemeliharaan cepat terasa
  const ann = (await settings.get('announcement')).trim() || DEF_ANN, mt = await settings.maintenance();
  res.json({
  turnstile: turnstile.siteKey(),
  contact: { wa: (process.env.CONTACT_WA || '').replace(/\D/g, '') || null, telegram: process.env.CONTACT_TG || null },
  warranty_days: +process.env.WARRANTY_DAYS || 30, announcement: ann, services: await settings.services(), maintenance: mt, maintenance_msg: mt ? (await settings.get('maintenance_msg')) || null : null
  });
}));
const guard = require('../lib/guard'), totp = require('../lib/totp'), QR = require('qrcode');
const ticket = (uid) => jwt.sign({ uid, k: '2fa' }, process.env.JWT_SECRET, { expiresIn: '5m' });
const readTicket = (t) => { try { const p = jwt.verify(String(t || ''), process.env.JWT_SECRET); return p.k === '2fa' ? p : null; } catch { return null; } };
const getIp = (req) => req.ip || req.socket?.remoteAddress || '';
async function finishLogin(req, res, u) {
  await pool.execute('UPDATE users SET fails=0, locked_until=NULL WHERE id=?', [u.id]); await evt(req, u.id, 'login'); guard.ok(getIp(req));
  session.issue(res, u.id, u.pv); res.json({ ok: true, role: u.role });
}
router.post('/login', limiter(10), wrap(async (req, res) => {
  if (guard.blocked(getIp(req))) return res.status(429).json({ error: 'Terlalu banyak percobaan dari jaringan Anda. Coba lagi dalam 30 menit.' });
  if (!(await human(req, res))) return;
  const d = parse(z.object({ username: z.string().max(120), password: z.string().max(72) }), req.body, res); if (!d) return;
  const [[u]] = await pool.execute('SELECT id,pass_hash,role,banned,locked_until,pv,fails,totp_on FROM users WHERE username=? OR email=?', [d.username.toLowerCase(), d.username.toLowerCase()]);
  const uk = unkKey(d.username);
  if ((u?.locked_until && new Date(u.locked_until) > new Date()) || (!u && unkLocked(uk))) return res.status(429).json({ error: LOCKMSG });
  const ok = await bcrypt.compare(d.password, u ? u.pass_hash : DUMMY); // anti timing/user-enumeration
  if (!u || !ok) {
    if (u) { const m = guard.lockMinutes((u.fails || 0) + 1); await pool.execute(m ? 'UPDATE users SET fails=fails+1, locked_until=DATE_ADD(UTC_TIMESTAMP(), INTERVAL ' + m + ' MINUTE) WHERE id=?' : 'UPDATE users SET fails=fails+1 WHERE id=?', [u.id]); await evt(req, u.id, 'login_fail'); } else unkFail(uk);
    guard.fail(getIp(req), d.username); require('../lib/shield').strike(getIp(req), 4, 'gagal login');
    return res.status(401).json({ error: 'Username atau password salah' });
  }
  if (u.banned) return res.status(403).json({ error: 'Akun diblokir. Hubungi admin.' });
  if (u.totp_on) return res.json({ need_2fa: true, ticket: ticket(u.id) });
  await finishLogin(req, res, u);
}));
// Langkah kedua login: kode 6 digit dari aplikasi autentikator atau kode pemulihan (sekali pakai)
router.post('/login/2fa', limiter(10), wrap(async (req, res) => {
  if (guard.blocked(getIp(req))) return res.status(429).json({ error: 'Terlalu banyak percobaan dari jaringan Anda. Coba lagi dalam 30 menit.' });
  const d = parse(z.object({ ticket: z.string().max(600), code: z.string().max(20) }), req.body, res); if (!d) return;
  const t = readTicket(d.ticket); if (!t) return res.status(401).json({ error: 'Sesi verifikasi berakhir, silakan masuk lagi.' });
  const [[u]] = await pool.execute('SELECT id,role,banned,locked_until,pv,fails,totp_on,totp_secret_enc,totp_last,totp_recovery FROM users WHERE id=?', [t.uid]);
  if (!u || u.banned || !u.totp_on) return res.status(401).json({ error: 'Sesi verifikasi tidak valid.' });
  if (u.locked_until && new Date(u.locked_until) > new Date()) return res.status(429).json({ error: LOCKMSG });
  const bad = async () => { const m = guard.lockMinutes((u.fails || 0) + 1); await pool.execute(m ? 'UPDATE users SET fails=fails+1, locked_until=DATE_ADD(UTC_TIMESTAMP(), INTERVAL ' + m + ' MINUTE) WHERE id=?' : 'UPDATE users SET fails=fails+1 WHERE id=?', [u.id]); await evt(req, u.id, 'login_fail'); guard.fail(getIp(req), 'u' + u.id); require('../lib/shield').strike(getIp(req), 4, 'gagal kode 2FA'); return res.status(401).json({ error: 'Kode salah atau kedaluwarsa' }); };
  const step = totp.verify(dec(u.totp_secret_enc), d.code, { last: u.totp_last || 0 });
  if (step) await pool.execute('UPDATE users SET totp_last=? WHERE id=?', [step, u.id]);
  else {
    const left = /\d{6}/.test(d.code.replace(/\s/g, '')) && d.code.replace(/\s/g, '').length === 6 ? null : totp.useRecovery(u.totp_recovery, d.code);
    if (!left) return bad();
    await pool.execute('UPDATE users SET totp_recovery=? WHERE id=?', [JSON.stringify(left), u.id]);
  }
  await finishLogin(req, res, u);
}));
// Pengaturan 2FA (wajib login). Aktivasi: setup -> scan QR -> enable dengan kode pertama. Menonaktifkan wajib password + kode.
router.get('/2fa', auth, wrap(async (req, res) => {
  const [[u]] = await pool.execute('SELECT totp_on,totp_recovery FROM users WHERE id=?', [req.user.id]);
  let n = 0; try { n = JSON.parse(u.totp_recovery || '[]').length; } catch {}
  res.json({ enabled: !!u.totp_on, recovery_left: u.totp_on ? n : 0 });
}));
router.post('/2fa/setup', auth, limiter(10, 60), wrap(async (req, res) => {
  const [[u]] = await pool.execute('SELECT totp_on FROM users WHERE id=?', [req.user.id]);
  if (u.totp_on) return res.status(400).json({ error: '2FA sudah aktif' });
  const secret = totp.newSecret(); await pool.execute('UPDATE users SET totp_secret_enc=? WHERE id=?', [enc(secret), req.user.id]);
  const qr = await QR.toDataURL(totp.uri(secret, req.user.username), { margin: 1, width: 220, color: { dark: '#000000', light: '#ffffff' } });
  res.json({ secret: totp.pretty(secret), qr });
}));
router.post('/2fa/enable', auth, limiter(10, 60), wrap(async (req, res) => {
  const d = parse(z.object({ code: z.string().max(20) }), req.body, res); if (!d) return;
  const [[u]] = await pool.execute('SELECT totp_on,totp_secret_enc FROM users WHERE id=?', [req.user.id]);
  if (u.totp_on || !u.totp_secret_enc) return res.status(400).json({ error: 'Mulai ulang pengaturan 2FA' });
  const step = totp.verify(dec(u.totp_secret_enc), d.code); if (!step) return res.status(400).json({ error: 'Kode salah. Pastikan jam ponsel akurat.' });
  const codes = totp.recoveryCodes();
  await pool.execute('UPDATE users SET totp_on=1, totp_last=?, totp_recovery=? WHERE id=?', [step, JSON.stringify(codes.map(totp.hashCode)), req.user.id]); await evt(req, req.user.id, '2fa_on');
  res.json({ ok: true, recovery: codes });
}));
router.post('/2fa/disable', auth, limiter(5, 60), wrap(async (req, res) => {
  const d = parse(z.object({ password: z.string().max(72), code: z.string().max(20) }), req.body, res); if (!d) return;
  const [[u]] = await pool.execute('SELECT pass_hash,totp_on,totp_secret_enc,totp_last,totp_recovery FROM users WHERE id=?', [req.user.id]);
  if (!u.totp_on) return res.status(400).json({ error: '2FA belum aktif' });
  if (!(await bcrypt.compare(d.password, u.pass_hash))) return res.status(401).json({ error: 'Password salah' });
  const okc = totp.verify(dec(u.totp_secret_enc), d.code, { last: u.totp_last || 0 }) || totp.useRecovery(u.totp_recovery, d.code);
  if (!okc) return res.status(401).json({ error: 'Kode salah' });
  await pool.execute('UPDATE users SET totp_on=0, totp_secret_enc=NULL, totp_recovery=NULL, totp_last=0 WHERE id=?', [req.user.id]); await evt(req, req.user.id, '2fa_off');
  res.json({ ok: true });
}));
router.post('/logout', (_q, res) => { session.clear(res); res.json({ ok: true }); });
router.get('/me', auth, (req, res) => {
  const { ptero_user_id, banned, pv, ...u } = req.user;
  delete u.balance; // tidak ada saldo di website: saldo hanya ada di akun Averpay
  const uid = 'SN_' + crypto.createHmac('sha256', process.env.JWT_SECRET).update(String(u.id)).digest('hex').slice(0, 8).toUpperCase();
  res.json({ ...u, uid });
});
router.post('/profile', auth, wrap(async (req, res) => {
  const d = parse(z.object({ whatsapp: z.string().regex(/^0\d{9,14}$/, 'Nomor WhatsApp tidak valid') }), req.body, res); if (!d) return;
  await pool.execute('UPDATE users SET whatsapp=? WHERE id=?', [d.whatsapp, req.user.id]); res.json({ ok: true });
}));
router.post('/password', auth, limiter(5, 60), wrap(async (req, res) => {
  const d = parse(z.object({ old: z.string().max(72), next: z.string().min(8, 'Password baru minimal 8 karakter').max(72) }), req.body, res); if (!d) return;
  if (!strongPw(d.next, req.user.username)) return res.status(400).json({ error: 'Password baru terlalu mudah ditebak. Gunakan kombinasi yang lebih unik dan jangan memuat username.' });
  const [[u]] = await pool.execute('SELECT pass_hash FROM users WHERE id=?', [req.user.id]);
  if (!(await bcrypt.compare(d.old, u.pass_hash))) return res.status(401).json({ error: 'Password lama salah' });
  await pool.execute('UPDATE users SET pass_hash=?, pv=pv+1 WHERE id=?', [await bcrypt.hash(d.next, 12), req.user.id]); await evt(req, req.user.id, 'password');
  session.issue(res, req.user.id, req.user.pv + 1); res.json({ ok: true });
}));

// Keluar dari SEMUA perangkat: menaikkan versi sesi (pv) sehingga semua cookie lama langsung tidak berlaku
router.post('/logout-all', auth, limiter(5, 60), wrap(async (req, res) => {
  await pool.execute('UPDATE users SET pv=pv+1 WHERE id=?', [req.user.id]); await evt(req, req.user.id, 'logout_all');
  session.clear(res); res.json({ ok: true });
}));
router.get('/events', auth, wrap(async (req, res) => {
  const [r] = await pool.execute('SELECT id,type,ip,ua,created_at FROM events WHERE user_id=? ORDER BY id DESC LIMIT 25', [req.user.id]);
  res.json(notify.loginHistory(r, { ua: clip(req.get('user-agent'), 160), ip: clip(req.ip, 45) }));
}));
// Notifikasi akun (login baru, status pesanan, klaim garansi) dihitung dari data yang ada; "belum dibaca" memakai users.notif_seen_at
router.get('/notifications', auth, wrap(async (req, res) => res.json(await notify.list(req.user.id))));
router.post('/notifications/read', auth, limiter(60, 5), wrap(async (req, res) => { await notify.markRead(req.user.id); res.json({ ok: true }); }));
// Statistik live publik (agregat, tanpa data pribadi): aktivitas 24 jam + kondisi server
router.get('/live', wrap(async (_q, res) => { res.set('Cache-Control', 'public, max-age=5'); res.json(await live.snapshot()); }));

// ===== ORDER PANEL: setiap pelanggan membayar langsung per pesanan lewat QRIS (Averpay). Tidak ada saldo/dompet di website: uang masuk ke saldo Averpay, lalu order panel memotong saldo Averpay secara otomatis. =====
const pub = (o, claim) => ({
  id: o.id, trx: o.order_ref, state: order.state(o), package_key: o.package_key, price: o.price, total: o.total, server_name: o.server_name, pay_method: o.pay_method,
  expires_at: o.expires_at, created_at: o.created_at, server_id: o.ptero_server_id || null, claim: claim || null,
  pkg: { name: o.pkg_name || null, ram: o.pkg_ram || null, disk: o.pkg_disk || null, cpu: o.pkg_cpu || null }, panel_user: o.panel_user || null, panel_expires_at: o.panel_expires_at || null, legacy: !o.provider_id && !!o.ptero_server_id,
  warranty: o.status === 'active' && o.pay_status === 'paid' && !o.provider_id ? warranty.info(o, !!claim && ['pending', 'processing'].includes(claim.status)) : null // panel Averpay: NON GARANSI
});
const inflight = new Set(); // 1 pembuatan QRIS per user pada satu waktu (anti klik ganda / request paralel)
router.post('/orders', auth, require('../lib/idem')('panel'), notMaint, svcOn('panel'), limiter(15, 60), wrap(async (req, res) => {
  const d = parse(z.object({ package: z.string(), name: z.string().regex(/^[A-Za-z0-9_]{3,14}$/, 'Username panel 3-14 karakter: huruf, angka, atau underscore'), price: z.number().int().optional() }), req.body, res); if (!d) return;
  let pkg; try { pkg = await panel.find(d.package); } catch (e) { console.error('[panel] katalog:', e.message); return res.status(503).json({ error: 'Daftar paket belum bisa dimuat, coba lagi sebentar' }); }
  if (!pkg) return res.status(400).json({ error: 'Paket tidak tersedia' });
  if (d.price != null && d.price !== pkg.price) return res.status(409).json({ error: 'Harga paket berubah. Muat ulang halaman lalu coba lagi.' });
  const ref = newRef();
  if (inflight.has(req.user.id)) return res.status(429).json({ error: 'Permintaan sebelumnya masih diproses, tunggu sebentar' });
  inflight.add(req.user.id);
  try {
  await order.sweep(req.user.id);
  // Pesanan identik (paket + nama server) yang masih menunggu bayar & berlaku: pakai yang itu, jangan buat QRIS baru (anti dobel saat klik ganda / refresh)
  const [[dup]] = await pool.execute(`SELECT ${order.LIGHT} FROM orders WHERE user_id=? AND package_key=? AND server_name=? AND pay_method='qris' AND pay_status='pending' AND expires_at>UTC_TIMESTAMP() AND created_at>DATE_SUB(UTC_TIMESTAMP(), INTERVAL 10 MINUTE) ORDER BY id DESC LIMIT 1`, [req.user.id, pkg.key, d.name]);
  if (dup) return res.json({ id: dup.id, reused: true, order: { ...pub(dup), qr_image: `/api/qr/order/${dup.id}` } });
  const [[c]] = await pool.execute("SELECT COUNT(*) n FROM orders WHERE user_id=? AND pay_status='pending' AND expires_at>UTC_TIMESTAMP()", [req.user.id]);
  if (c.n >= 3) return res.status(429).json({ error: 'Selesaikan atau batalkan dulu pesanan yang menunggu pembayaran' });
  let q; try { q = await averpay.create(pkg.price); } catch (e) { console.error(e.message); return res.status(e.circuit ? 503 : e.public ? 400 : 502).json({ error: e.public || 'Gateway pembayaran sedang bermasalah, coba lagi' }); }
  let r; try { [r] = await pool.execute('INSERT INTO orders(user_id,package_key,price,server_name,order_ref,transaction_id,total,qr_image,expires_at,pkg_name,pkg_ram,pkg_disk,pkg_cpu,cost) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [req.user.id, pkg.key, pkg.price, d.name, ref, q.transaction_id, q.total, q.qr_image, q.expires_at, pkg.name, pkg.memory, pkg.disk, pkg.cpu, pkg.cost]); } catch (e) { console.error('[invoice-yatim] invoice', q.transaction_id, 'dibuat tapi gagal disimpan:', e.message); await averpay.orphan('panel', q.transaction_id, req.user.id, q.total, e.message); throw e; } // dicatat agar bisa direkonsiliasi manual bila sempat dibayar
  const row = { id: r.insertId, order_ref: ref, pay_status: 'pending', status: 'pending', pay_method: 'qris', package_key: pkg.key, price: pkg.price, total: q.total, server_name: d.name, expires_at: q.expires_at, created_at: new Date(), ptero_server_id: null, claims_used: 0, pkg_name: pkg.name, pkg_ram: pkg.memory, pkg_disk: pkg.disk, pkg_cpu: pkg.cpu };
  res.json({ id: r.insertId, order: { ...pub(row), qr_image: `/api/qr/order/${r.insertId}` } }); // QR ikut di respons: tanpa request tambahan
  } finally { inflight.delete(req.user.id); }
}));
router.get('/orders', auth, wrap(async (req, res) => {
  await order.sweep(req.user.id);
  const [r] = await pool.execute(`SELECT ${order.LIGHT} FROM orders WHERE user_id=? AND hidden=0 ORDER BY id DESC LIMIT 100`, [req.user.id]);
  const [cl] = await pool.execute('SELECT order_id,status,admin_note,new_server_id FROM claims WHERE user_id=? ORDER BY id DESC LIMIT 200', [req.user.id]);
  const last = new Map(); for (const c of cl) if (!last.has(c.order_id)) last.set(c.order_id, c);
  res.json(r.map((o) => pub(o, last.get(o.id))));
}));
router.post('/orders/clear', auth, limiter(20), wrap(async (req, res) => { // hapus riwayat yang sudah selesai (kedaluwarsa/dibatalkan; scope=all ikut pesanan aktif)
  const d = parse(z.object({ scope: z.enum(['finished', 'all']).default('finished') }), req.body || {}, res); if (!d) return;
  res.json({ ok: true, removed: await order.hideAll(req.user.id, d.scope === 'all') });
}));
router.get('/orders/:id', auth, wrap(async (req, res) => {
  const id = intId(req.params.id);
  const [[o]] = await pool.execute(`SELECT ${order.LIGHT} FROM orders WHERE id=? AND user_id=?`, [id, req.user.id]);
  if (!o) return res.status(404).json({ error: 'Pesanan tidak ditemukan' });
  // Buka pembayaran (qr=1) pada pesanan yang masih berlaku: kirim QR SEKARANG dari DB. Verifikasi ke gateway dilakukan oleh polling berikutnya,
  // supaya QR tidak tertahan menunggu gateway yang lambat.
  const fast = req.query.qr === '1' && o.pay_status === 'pending' && o.pay_method === 'qris' && Date.now() < new Date(o.expires_at).getTime();
  const n = fast ? o : await order.refresh(o), out = pub(n);
  if (req.query.qr === '1' && n.pay_status === 'pending') { const [[q]] = await pool.execute('SELECT qr_image FROM orders WHERE id=?', [id]); if (q.qr_image) out.qr_image = `/api/qr/order/${id}`; } // QR hanya diminta sekali
  res.json(out);
}));
router.post('/orders/:id/cancel', auth, limiter(30), wrap(async (req, res) => {
  const r = await order.cancel(req.user.id, intId(req.params.id));
  if (r.code === 404) return res.status(404).json({ error: 'Pesanan tidak ditemukan' });
  if (r.code === 409) return res.status(409).json({ error: ['processing', 'active', 'failed'].includes(r.state) ? 'Pembayaran sudah diterima, pesanan tidak bisa dibatalkan' : 'Pesanan sudah tidak menunggu pembayaran', state: r.state });
  res.json({ ok: true });
}));
router.delete('/orders/:id', auth, limiter(60), wrap(async (req, res) => {
  if (!(await order.hide(req.user.id, intId(req.params.id)))) return res.status(409).json({ error: 'Pesanan ini belum bisa dihapus (menunggu bayar, diproses, atau perlu bantuan)' });
  res.json({ ok: true });
}));

// ===== PROXY GAMBAR QRIS =====
// Averpay mengirim qris_image berupa URL. Gambar diambil server kita dan disajikan same-origin: CSP tetap ketat, tombol "simpan QR" jalan, URL asli tidak bocor.
const QR_MAX = 2 * 1024 * 1024;
router.get('/qr/:kind/:id', auth, wrap(async (req, res) => {
  const tbl = { order: 'orders', premium: 'premium_orders', nokos: 'nokos_orders' }[req.params.kind]; if (!tbl) return res.status(404).end();
  const cond = tbl === 'orders' ? "pay_status='pending'" : ['premium_orders', 'nokos_orders'].includes(tbl) ? "status='awaiting_payment'" : "status='pending'";
  const [[row]] = await pool.execute(`SELECT qr_image FROM ${tbl} WHERE id=? AND user_id=? AND ${cond}`, [intId(req.params.id), req.user.id]);
  const src = row && row.qr_image; if (!src) return res.status(404).end();
  res.set('Cache-Control', 'private, max-age=600');
  const dm = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(src); // baris lama (gateway sebelumnya) menyimpan data URL
  if (dm) return res.type(dm[1]).send(Buffer.from(dm[2], 'base64'));
  if (!/^https:\/\//i.test(src)) return res.status(404).end();
  let img; try { img = await require('../lib/safefetch').fetchImage(src); } catch (e) { if (e.blocked) console.error('[qr] ditolak:', e.message); return res.status(502).end(); } // anti-SSRF
  res.type(img.type).send(img.body);
}));

// ===== AKUN PANEL =====
router.get('/panel', auth, wrap(async (req, res) => {
  // Tiap pesanan panel Averpay = satu akun panel sendiri (URL, username, password, masa aktif). Akun lama (panel milik sendiri) tetap tampil bila ada.
  const [rows] = await pool.execute("SELECT id,order_ref,pkg_name,pkg_ram,package_key,panel_user,panel_email,panel_domain,panel_expires_at,panel_pass_enc,activated_at FROM orders WHERE user_id=? AND provider_id IS NOT NULL AND status='active' AND pay_status='paid' ORDER BY id DESC LIMIT 50", [req.user.id]);
  const accounts = rows.map((o) => { const pw = o.panel_pass_enc ? dec(o.panel_pass_enc) : null; return { order_id: o.id, trx: o.order_ref, name: o.pkg_name || o.package_key, url: o.panel_domain || null, username: o.panel_user, email: o.panel_email, password: pw, unreadable: !!o.panel_pass_enc && pw == null, expires_at: o.panel_expires_at || null }; });
  const [[u]] = await pool.execute('SELECT username,ptero_user_id,panel_pass_enc FROM users WHERE id=?', [req.user.id]);
  let legacy = null; if (u.ptero_user_id && process.env.PTERO_DOMAIN) { const pw = u.panel_pass_enc ? dec(u.panel_pass_enc) : null; legacy = { url: process.env.PTERO_DOMAIN, username: u.username, password: pw, unreadable: !!u.panel_pass_enc && pw == null }; }
  res.json({ ready: accounts.length > 0 || !!legacy, accounts, legacy });
}));
router.post('/panel/reset', auth, limiter(3, 60), wrap(async (req, res) => { // password panel baru (untuk yang lupa / password lama dari panel yang sudah ada)
  const [[u]] = await pool.execute('SELECT ptero_user_id FROM users WHERE id=?', [req.user.id]);
  if (!u.ptero_user_id) return res.status(400).json({ error: 'Akun panel belum dibuat' });
  let pw; try { pw = await ptero.resetPassword(u.ptero_user_id, req.user); } catch (e) { console.error('reset:', e.message); if (e.status === 403) return res.status(403).json({ error: 'Akun panel ini tidak bisa direset otomatis. Hubungi bantuan.' }); return res.status(502).json({ error: 'Gagal mereset password panel, coba lagi' }); }
  await pool.execute('UPDATE users SET panel_pass_enc=? WHERE id=?', [enc(pw), req.user.id]); await evt(req, req.user.id, 'panel_reset'); res.json({ ok: true });
}));

// ===== PORTAL GARANSI (publik: verifikasi TRX ID + WhatsApp pendaftar, tanpa login) =====
const gz = z.object({ trx: z.string().trim().toUpperCase().regex(/^[A-Z0-9]{8,40}$/, 'TRX ID tidak valid'), wa: z.string().trim().min(8, 'Nomor WhatsApp tidak valid').max(20) });
const NOTFOUND = { error: 'Data tidak ditemukan. Periksa TRX ID dan nomor WhatsApp pendaftar.' };
// Percobaan salah per TRX dihitung lintas IP: setelah 5x salah, TRX itu dikunci 15 menit (penyerang tidak bisa menebak nomor WhatsApp pemilik dari banyak IP)
const gzFail = new Map(), gzKey = (t) => String(t || '').toUpperCase().slice(0, 40);
const gzLocked = (t) => { const e = gzFail.get(gzKey(t)); return !!e && e.until > Date.now(); };
const gzMiss = (t) => { const k = gzKey(t), e = gzFail.get(k) || { n: 0, until: 0 }; if (e.until && e.until <= Date.now()) { e.n = 0; e.until = 0; } e.n++; if (e.n >= 5) e.until = Date.now() + 15 * 60e3; gzFail.set(k, e); if (gzFail.size > 5000) gzFail.delete(gzFail.keys().next().value); };
const LOCKTRX = { error: 'Terlalu banyak percobaan untuk TRX ID ini. Coba lagi 15 menit lagi.' };
router.post('/garansi/check', limiter(20), wrap(async (req, res) => {
  const d = parse(gz, req.body, res); if (!d) return;
  if (gzLocked(d.trx)) return res.status(429).json(LOCKTRX);
  const o = await warranty.find(d.trx, d.wa); if (!o) { gzMiss(d.trx); return res.status(404).json(NOTFOUND); }
  res.json(await warranty.summary(o));
}));
router.post('/garansi/claim', limiter(10), wrap(async (req, res) => {
  const gs = await settings.service('garansi'); if (!gs.on) return res.status(503).json({ error: gs.msg || 'Klaim garansi sedang dinonaktifkan sementara. Coba lagi nanti.', service: 'garansi', off: true });
  const d = parse(gz.extend({ category: z.enum(['server_down', 'panel_error', 'lainnya']), reason: z.string().trim().min(10, 'Jelaskan kendala minimal 10 karakter').max(300) }), req.body, res); if (!d) return;
  if (gzLocked(d.trx)) return res.status(429).json(LOCKTRX);
  const o = await warranty.find(d.trx, d.wa); if (!o) { gzMiss(d.trx); return res.status(404).json(NOTFOUND); }
  const c = await warranty.createClaim(o, d.category, d.reason);
  if (c.error) return res.status(409).json({ error: c.error });
  if (process.env.WARRANTY_AUTO === '1') warranty.execute(c.id).catch((e) => console.error('auto claim:', e.message)); // opsional: server baru langsung dibuat tanpa persetujuan admin
  res.json({ ok: true, ...(await warranty.summary(o)) });
}));

// ===== STATUS SISTEM (publik; membaca hasil pemantau health.js yang diperbarui tiap 20 dtk) =====
router.get('/status', wrap(async (_q, res) => { res.set('Cache-Control', 'public, max-age=5'); res.json(await require('../lib/health').snapshot()); }));

// ===== ADMIN (role dicek di server pada SETIAP request) =====
const adminIp = (req, res, next) => { const list = (process.env.ADMIN_IPS || '').split(',').map((s) => s.trim()).filter(Boolean); if (list.length && !list.includes(req.ip)) { console.warn('[security] admin ditolak dari IP', req.ip); return res.status(403).json({ error: 'Forbidden' }); } next(); }; // opsional: ADMIN_IPS=ip1,ip2 membatasi panel admin hanya dari IP tertentu
const adm = [auth, admin, adminIp, limiter(300, 15)];
const audit = (a, act, t, det) => pool.execute('INSERT INTO audit(admin_id,action,target,detail) VALUES(?,?,?,?)', [a, act, t, String(det || '').slice(0, 120)]);
router.get('/admin/stats', ...adm, wrap(async (req, res) => {
  const [[a]] = await pool.query("SELECT (SELECT COUNT(*) FROM users WHERE role='member') users,(SELECT COUNT(*) FROM orders WHERE status='active') orders,(SELECT COALESCE(SUM(price),0) FROM orders WHERE pay_status='paid' AND pay_method='qris') revenue,(SELECT COUNT(*) FROM orders WHERE pay_status='paid' AND status IN ('failed','processing')) attention,(SELECT COUNT(*) FROM orders WHERE pay_status='pending' AND expires_at>UTC_TIMESTAMP()) pending,(SELECT COUNT(*) FROM claims WHERE status IN ('pending','failed')) claims");
  res.json({ ...a, provider_balance: await require('../lib/premium').providerBalance(true) }); // balance = dompet internal web; provider_balance = saldo asli di akun Averpay (GET /api/balance), selalu dibaca segar
}));
router.get('/admin/users', ...adm, wrap(async (req, res) => {
  const q = `%${String(req.query.q || '').slice(0, 40).replace(/[%_\\]/g, '')}%`;
  const [r] = await pool.execute('SELECT id,username,email,whatsapp,role,banned,created_at FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 50', [q, q]); res.json(r);
}));
router.post('/admin/users/:id/ban', ...adm, wrap(async (req, res) => {
  const id = intId(req.params.id), d = parse(z.object({ banned: z.boolean() }), req.body, res); if (!d) return;
  if (!id || id === req.user.id) return res.status(400).json({ error: 'Invalid' });
  const [r] = await pool.execute("UPDATE users SET banned=? WHERE id=? AND role='member'", [d.banned ? 1 : 0, id]);
  if (!r.affectedRows) return res.status(404).json({ error: 'User tidak ditemukan' });
  await audit(req.user.id, 'ban', id, d.banned); res.json({ ok: true });
}));
router.get('/admin/orders', ...adm, wrap(async (_q, res) => {
  const [r] = await pool.query('SELECT o.id,o.order_ref trx,u.username,u.whatsapp,o.package_key,o.price,o.server_name,o.ptero_server_id server_id,o.provider_id,o.pkg_name,o.panel_user,o.cost,o.attempts,o.panel_expires_at,o.status,o.pay_status,o.pay_method,o.bonus_days,o.expires_at,o.created_at FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 80');
  res.json(r.map((o) => ({ ...o, state: order.state(o) })));
}));
router.post('/admin/orders/:id/retry', ...adm, wrap(async (req, res) => {
  const id = intId(req.params.id); if (!id) return res.status(400).json({ error: 'Invalid' });
  const [[o0]] = await pool.execute('SELECT attempts,provider_id FROM orders WHERE id=?', [id]);
  if (o0 && !o0.provider_id && o0.attempts >= 99 && (req.body || {}).confirm !== true) return res.status(409).json({ error: 'Hasil pesanan ke Averpay sebelumnya tidak pasti. Cek Riwayat Pesanan Panel di dashboard Averpay; ulangi hanya bila panel ini TIDAK terbeli.', need_confirm: true });
  const [r] = await pool.execute("UPDATE orders SET status='failed', attempts=0 WHERE id=? AND pay_status='paid' AND status IN ('failed','processing') AND pay_method='qris'", [id]);
  if (!r.affectedRows) return res.status(404).json({ error: 'Pesanan tidak bisa diulang' });
  await order.fulfill(id); await audit(req.user.id, 'retry', id, ''); res.json({ ok: true });
}));
// ===== Pengaturan panel Averpay: margin harga & pilihan server panel =====
router.get('/admin/panel/settings', ...adm, wrap(async (_q, res) => {
  const c = await panel.cfg(); let panels = [], items = [], error = null;
  try { panels = await panel.panels({ maxAge: 0 }); items = (await panel.catalog({ maxAge: 0 })).items; } catch (e) { error = e.public || e.message; }
  res.json({ pct: c.pct, min: c.min, panel_id: c.panel, panels, items, error });
}));
router.post('/admin/panel/settings', ...adm, wrap(async (req, res) => {
  const d = parse(z.object({ pct: z.number().min(0).max(500), min: z.number().int().min(0).max(1000000), panel_id: z.string().trim().max(60).optional() }), req.body, res); if (!d) return;
  await settings.set('panel_margin_pct', String(d.pct)); await settings.set('panel_margin_min', String(d.min)); await settings.set('panel_id', d.panel_id || ''); panel._reset();
  await audit(req.user.id, 'panel-settings', null, `margin ${d.pct}% min ${d.min} panel ${d.panel_id || 'otomatis'}`); res.json({ ok: true });
}));
router.get('/admin/claims', ...adm, wrap(async (_q, res) => {
  const [r] = await pool.query("SELECT c.id,c.category,c.reason,c.status,c.admin_note,c.old_server_id,c.new_server_id,c.created_at,o.order_ref trx,o.server_name,o.package_key,o.ptero_server_id server_id,u.username,u.whatsapp FROM claims c JOIN orders o ON o.id=c.order_id JOIN users u ON u.id=c.user_id ORDER BY FIELD(c.status,'pending','failed','processing','done','rejected'), c.id DESC LIMIT 80");
  res.json(r);
}));
router.post('/admin/claims/:id/approve', ...adm, limiter(30), wrap(async (req, res) => {
  const id = intId(req.params.id); if (!id) return res.status(400).json({ error: 'Invalid' });
  const r = await warranty.execute(id); await audit(req.user.id, 'claim-ok', id, r.ok ? 'server ' + r.server_id : r.error);
  if (!r.ok) return res.status(502).json({ error: r.error || 'Gagal memproses klaim' });
  res.json({ ok: true, server_id: r.server_id });
}));
router.post('/admin/claims/:id/reject', ...adm, wrap(async (req, res) => {
  const id = intId(req.params.id), d = parse(z.object({ note: z.string().trim().max(200).optional() }), req.body, res); if (!d) return;
  if (!id || !(await warranty.reject(id, d.note))) return res.status(404).json({ error: 'Klaim tidak bisa ditolak' });
  await audit(req.user.id, 'claim-no', id, d.note); res.json({ ok: true });
}));

// Perisai: daftar IP yang sedang diblokir otomatis + buka blokir manual (mis. pengguna sah di jaringan bersama yang terkena banjir 429)
router.get('/admin/shield', ...adm, wrap(async (_q, res) => res.json(require('../lib/shield').list())));
router.post('/admin/shield/unban', ...adm, wrap(async (req, res) => { const d = parse(z.object({ ip: z.string().trim().min(3).max(64) }), req.body, res); if (!d) return; const ok = require('../lib/shield').unban(d.ip); await audit(req.user.id, 'shield-unban', null, d.ip); res.json({ ok }); }));
router.get('/admin/audit', ...adm, wrap(async (_q, res) => {
  const [r] = await pool.query('SELECT a.id,a.action,a.target,a.detail,a.created_at,u.username admin FROM audit a LEFT JOIN users u ON u.id=a.admin_id ORDER BY a.id DESC LIMIT 100');
  res.json(r);
}));
router.post('/admin/maintenance', ...adm, wrap(async (req, res) => {
  const d = parse(z.object({ on: z.boolean(), msg: z.string().trim().max(200).optional() }), req.body, res); if (!d) return;
  await settings.set('maintenance', d.on ? '1' : ''); await settings.set('maintenance_msg', d.on ? d.msg || '' : '');
  await audit(req.user.id, d.on ? 'maint-on' : 'maint-off', null, d.msg); res.json({ ok: true });
}));
router.get('/admin/health', ...adm, wrap(async (_q, res) => {
  const [[rv]] = await pool.query("SELECT COUNT(*) n FROM premium_orders WHERE status='review'");
  const [[nv]] = await pool.query("SELECT COUNT(*) n FROM nokos_orders WHERE status IN ('review','refund_needed')");
  res.json({ worker: worker.info(), breakers: [averpay.breaker(), ptero.breaker()], maintenance: await settings.maintenance(), uptime: Math.round(process.uptime()), ram_mb: Math.round(process.memoryUsage().rss / 1048576),
    provider_balance: await require('../lib/premium').providerBalance(), premium_review: rv.n, nokos_attention: nv.n });
}));
const ADD_BONUS = warranty.ADD_BONUS;
router.post('/admin/services', ...adm, wrap(async (req, res) => {
  const d = parse(z.object({ name: z.enum(['panel', 'premium', 'nokos', 'garansi']), on: z.boolean(), msg: z.string().trim().max(200).optional() }), req.body, res); if (!d) return;
  await settings.set('svc_' + d.name, d.on ? '' : '0'); await settings.set('svc_' + d.name + '_msg', d.on ? '' : d.msg || '');
  await audit(req.user.id, d.on ? 'svc-on' : 'svc-off', null, `${d.name} ${d.msg || ''}`.slice(0, 100)); res.json({ ok: true });
}));
router.post('/admin/orders/:id/bonus', ...adm, limiter(60), wrap(async (req, res) => {
  const id = intId(req.params.id), d = parse(z.object({ days: z.number().int().min(1).max(365), note: z.string().trim().max(100).optional() }), req.body, res); if (!d || !id) return;
  if (!(await confirmPw(req, res))) return;
  const [r] = await pool.execute(`UPDATE orders SET ${ADD_BONUS} WHERE id=? AND pay_status='paid' AND status='active'`, [d.days, d.days, id]);
  if (!r.affectedRows) return res.status(404).json({ error: 'Hanya pesanan panel yang sudah aktif yang bisa diberi waktu tambahan' });
  await audit(req.user.id, 'bonus', id, `+${d.days} hari ${d.note || ''}`.slice(0, 120)); res.json({ ok: true });
}));
router.post('/admin/compensation', ...adm, limiter(10, 15), wrap(async (req, res) => { // kompensasi massal (mis. setelah gangguan): tambah waktu ke SEMUA panel aktif
  const d = parse(z.object({ days: z.number().int().min(1).max(90), note: z.string().trim().min(3, 'Isi alasan kompensasi').max(100) }), req.body, res); if (!d) return;
  if (!(await confirmPw(req, res))) return;
  const [r] = await pool.execute(`UPDATE orders SET ${ADD_BONUS} WHERE pay_status='paid' AND status='active'`, [d.days, d.days]);
  await audit(req.user.id, 'comp-bulk', null, `+${d.days} hari (${r.affectedRows} panel) ${d.note}`.slice(0, 120)); res.json({ ok: true, affected: r.affectedRows });
}));
router.post('/admin/announcement', ...adm, wrap(async (req, res) => {
  const d = parse(z.object({ text: z.string().trim().max(300) }), req.body, res); if (!d) return;
  await settings.set('announcement', d.text); // kosong = kembali ke teks bawaan
  await audit(req.user.id, 'announce', null, d.text.slice(0, 100)); res.json({ ok: true });
}));

// Aksi admin yang sensitif (koreksi saldo, reset password user) wajib konfirmasi ulang password admin — membatasi dampak jika sesi admin dicuri
const confirmPw = async (req, res) => {
  const pw = req.body && req.body.password;
  if (typeof pw !== 'string' || !pw || pw.length > 72) { res.status(400).json({ error: 'Konfirmasi password diperlukan' }); return false; }
  const [[u]] = await pool.execute('SELECT pass_hash FROM users WHERE id=?', [req.user.id]);
  if (!(await bcrypt.compare(pw, u.pass_hash))) { await evt(req, req.user.id, 'login_fail'); res.status(401).json({ error: 'Password konfirmasi salah' }); return false; }
  return true;
};
router.post('/admin/users/:id/reset-password', ...adm, limiter(10, 15), wrap(async (req, res) => {
  const id = intId(req.params.id); if (!id || id === req.user.id) return res.status(400).json({ error: 'Invalid' });
  if (!(await confirmPw(req, res))) return;
  const tmp = crypto.randomBytes(9).toString('base64url');
  const [r] = await pool.execute("UPDATE users SET pass_hash=?, pv=pv+1, fails=0, locked_until=NULL WHERE id=? AND role='member'", [await bcrypt.hash(tmp, 12), id]); // pv+1: semua sesi lama user langsung mati
  if (!r.affectedRows) return res.status(404).json({ error: 'User tidak ditemukan' });
  await evt(req, id, 'password'); await audit(req.user.id, 'pw-reset', id, ''); res.json({ ok: true, password: tmp });
}));
router.use(require('./premium')({ auth, admin, adm, wrap, parse, limiter, notMaint, svcOn, intId, audit })); // Aplikasi Premium (QRIS langsung)
router.use(require('./nokos')({ auth, admin, adm, wrap, parse, limiter, notMaint, svcOn, intId, audit })); // Nokos / nomor OTP (QRIS langsung)

module.exports = router;
