# SnowyStore App (Flutter)

Aplikasi Android untuk server SnowyStore: login (termasuk 2FA), daftar, beli panel via QRIS (QR + polling status otomatis), riwayat pesanan, akun panel (URL/username/password), ubah password, keluar dari semua perangkat, dan pengaturan alamat server dengan tes koneksi.

## 1. Siapkan server (sekali saja)
Server di folder induk sudah diperbarui. Tambahkan ke `.env` (lihat `.env.example`, bagian "Aplikasi mobile"):

```
APP_API_KEY=string-acak-minimal-16-karakter   # opsional, tapi WAJIB bila Turnstile aktif
APP_MIN_VERSION=1.0.0
APP_DOWNLOAD_URL=
```
Lalu restart server (`node index.js`). Cek: buka `https://domainmu.com/healthz` -> `{"ok":true}`.

Yang berubah di server: login dari app (header `X-Client: snowy-app`) mengembalikan `token` JWT, dan semua endpoint menerima `Authorization: Bearer <token>` selain cookie web. Cookie web tidak berubah. Perisai anti-bot, rate limit, kunci akun, dan cek CSRF tetap berlaku.

## 2. Build APK
Butuh Flutter SDK >= 3.22 dan Android SDK (`flutter doctor`).

```bash
cd snowystore_app
./build.sh https://domainmu.com [APP_KEY]      # Linux / macOS
build.bat  https://domainmu.com [APP_KEY]      # Windows
```
`APP_KEY` = nilai `APP_API_KEY` di server (kosongkan bila Turnstile tidak dipakai). Hasil: `build/app/outputs/flutter-apk/app-release.apk`.

Skrip otomatis menjalankan `flutter create` (membuat folder `android/`), menambah izin INTERNET, mengatur nama app, lalu `flutter build apk --release`. Kode di `lib/` tidak ditimpa.

Tanpa Flutter di komputer: upload folder ini ke GitHub, buka tab Actions -> **Build APK** -> Run workflow, isi alamat server, lalu unduh artifact `snowystore-apk`.

Build manual:
```bash
flutter create --platforms=android --org id.snowystore --project-name snowystore_app .
dart run tool/patch_android.dart
flutter pub get
flutter build apk --release --dart-define=API_BASE=https://domainmu.com --dart-define=APP_KEY=...
```

## 3. Catatan
- Alamat server juga bisa diganti di dalam app (ikon server di layar login, atau Profil -> Server).
- `http://` (tanpa HTTPS) hanya untuk uji coba; skrip otomatis mengizinkan cleartext bila alamat diawali `http://`. Emulator Android mengakses komputer host lewat `http://10.0.2.2:3000`.
- Token disimpan di Keystore Android (flutter_secure_storage). Masa berlaku 30 hari dan diperpanjang otomatis.
- APK dari `--release` memakai tanda tangan debug. Untuk Play Store, buat keystore dan atur `signingConfigs` (lihat dokumentasi Flutter "Build and release an Android app").
- `APP_KEY` tertanam di APK dan bisa diekstrak; anggap sebagai pagar tambahan, bukan rahasia.
- Fitur yang belum ada di app: Aplikasi Premium, Nokos, Garansi, Admin. Gunakan website untuk itu.
- Test unit: `flutter test`.
