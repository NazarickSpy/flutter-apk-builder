# SnowyStore
Server panel Pterodactyl & aplikasi premium, semuanya otomatis lewat AVERPAY: pelanggan bayar QRIS → saldo Averpay bertambah → order dikirim ke Averpay (saldo terpotong otomatis) → akun/panel dikirim ke pelanggan.

## Layanan
- **Server panel Pterodactyl** (RAM 1-10 GB) - Averpay Panel Hosting.
- **Aplikasi premium** - Averpay Premium.
- **Nomor virtual / Nokos (OTP)** - Averpay Nokos. Alur sesuai docs Averpay: pilih aplikasi -> negara -> harga -> bayar QRIS -> nomor tampil -> OTP muncul otomatis (polling status 5 detik, maks 1 panggilan per pesanan per 4 dtk). OTP disimpan terenkripsi. Bila OTP tidak masuk sampai nomor kedaluwarsa, pesanan menjadi *Menunggu pengembalian dana* (admin refund atau Ganti nomor). Margin harga diatur di Admin > Nokos.

## Cara kerja uang (satu saldo saja: saldo Averpay)
- Website TIDAK punya saldo/dompet sendiri. Tidak ada top up di website.
- QRIS pelanggan = deposit ke akun Averpay (saldo Averpay bertambah sebesar harga jual).
- Order panel / aplikasi premium memotong saldo Averpay sebesar modal secara otomatis.
- Selisih harga jual dan modal = untung, tertinggal di saldo Averpay. Tarik lewat menu Withdraw di dashboard Averpay.
- Admin > Saldo Averpay menampilkan saldo tersebut (hanya baca). Margin harga panel diatur di Admin > Pengaturan.

## Pasang / update
1. Pakai `.env` yang sudah ada, lalu **tambahkan** variabel baru dari `.env.example` (bagian "BARU"). Wajib: `CONTACT_WA` (opsional tapi disarankan).
2. **Hapus folder `.next`** lalu jalankan ulang (`node index.js` membangun ulang otomatis). Tanpa ini, tampilan lama masih dipakai.
3. Tabel database dimigrasi otomatis saat start (kolom baru: `hidden`, `activated_at`, `claims_used`, `cancelled_at`; tabel baru: `claims`; status `cancelled`). Data lama aman.
4. Isi `AVERPAY_API_KEY` (dashboard Averpay → Profil) dan di Profil Averpay set **Callback URL** ke `APP_URL/webhook/averpay`.
5. Jadikan admin: `UPDATE users SET role='admin' WHERE username='namamu';`

## Halaman
Publik: `/` `/login` `/register` `/garansi` `/status` `/cara-order` `/bantuan` `/terms` `/404`
Member: `/dashboard` `/orders` (riwayat) `/premium` `/profile` — Admin: `/admin` (tab Ringkasan, User, Pesanan, Garansi, Saldo & Top Up)

## Aplikasi Premium (QRIS langsung, tanpa saldo user)
- Saldo dompet **hanya untuk admin** (membeli panel tanpa QRIS). User biasa membayar **QRIS per pesanan** (uang asli lewat Averpay).
- Alur: pilih produk (gambar + deskripsi, wajib centang "sudah membaca") → QRIS dibuat → lunas terdeteksi otomatis (webhook + polling + worker) → pesanan dikirim ke Averpay **tanpa retry otomatis** (tidak ada idempotency key) → data akun disimpan **terenkripsi permanen** (riwayat hanya menyembunyikan, tidak menghapus).
- Hasil setelah bayar: sukses = selesai; ditolak jelas = **Menunggu pengembalian dana** (admin: *Sudah direfund* / *Kirim ulang* / *Tandai selesai*); diterima belum selesai = dipantau; timeout/5xx = **Diperiksa admin** (mungkin sudah terbeli, tidak pernah di-retry otomatis).
- Validasi SEBELUM QRIS dibuat: produk, harga yang dilihat user, stok, saldo Averpay, sirkuit penyedia, total ≤ Rp 1.000.000 → user tidak membayar untuk pesanan yang pasti gagal.
- **Produk "PAKAI EMAIL KAMU / INVITE"**: API Averpay hanya menerima `product_id` & `qty` (tanpa email). Produk seperti ini **tidak dijual otomatis**; admin bisa mengizinkan di Admin → Premium → Katalog (pembeli lalu mengisi email, dikirim ke penyedia sebagai `email` secara best-effort dan dicatat di pesanan; bila penyedia tidak mengirim data akun, pesanan masuk "Diperiksa admin").
- Gambar produk diambil server (proxy `/api/premium/img/:id`, hanya untuk produk di katalog, anti-SSRF, di-cache) sehingga CSP tetap ketat.
- **PERTAMA KALI PASANG:** Admin → Premium → *Tes Koneksi & Lihat Respons*, lalu beli produk termurah sekali sebelum dibuka ke publik.

## Saklar layanan & kompensasi
- Admin → Pengaturan → **Saklar Layanan**: matikan/hidupkan *Pembelian Panel*, *Aplikasi Premium*, *Klaim Garansi* satu per satu (dengan pesan untuk pelanggan), terpisah dari **Mode Pemeliharaan** global. Pesanan yang sudah dibayar tetap diproses. Admin tetap bisa memakai layanan.
- **Kompensasi = waktu tambahan** (hari) pada masa garansi panel: per panel (Admin → Pesanan → "+ Waktu") atau massal ke semua panel aktif (Pengaturan). Wajib konfirmasi password admin, tercatat di Log Admin, tampil ke pelanggan.

## Tampilan & fitur baru (redesign)
- Desain mengikuti OpenWA Design System, dengan warna **biru** (token `--primary`, `--primary-text`, `--on-primary`) dengan **tema gelap** beraksen teal dan ikon lucide berwarna-warni (referensi yupra.net & zireku.com).
- Shell dashboard: sidebar 260px/72px (collapsible), drawer di HP, bel notifikasi, menu avatar dengan status Online/Offline, toast, skeleton loading.
- **Notifikasi** (`/notifikasi`, bel di navbar): dihitung dari login (termasuk "perangkat baru"), pesanan panel/premium/nokos, dan klaim garansi. Endpoint `GET /api/notifications`, `POST /api/notifications/read`. Kolom baru `users.notif_seen_at` dibuat otomatis oleh migrasi.
- **Profil**: tab Informasi, Keamanan, dan Aktivitas Login (perangkat, browser, IP disamarkan, "Perangkat ini"/"Perangkat baru"). `GET /api/events`.
- **Aktivitas server live** + **Informasi Sistem** (CPU, heap, uptime, Node, OS) di beranda dan `/status`: `GET /api/live` (publik, agregat saja, cache 5 dtk).
- Animasi hanya `transform`/`opacity`, reveal via IntersectionObserver, patuh `prefers-reduced-motion`.
- Komponen dari OpenWA yang diadopsi: PageHeader, kartu stat dengan watermark ikon, toggle switch, titik status pada pill, scrollbar tipis, focus trap dan pengembalian fokus pada modal, serta bottom sheet di HP.

## Status sistem real-time
`/status`: pemantau server memeriksa Website, Database, Server Panel (Averpay), Gateway, Katalog Premium, dan Worker tiap 20 detik (riwayat 1 jam: uptime %, latensi, kendala terakhir). Ketersediaan tiap layanan = saklar admin + kesehatan komponen yang dibutuhkan. Halaman memperbarui diri tiap 10 detik.

## Data & cadangan
Tidak ada kode yang menghapus pesanan/data akun (hapus riwayat = sembunyikan). Cadangan terenkripsi otomatis tiap ~24 jam ke `./backups` (14 terakhir) dan manual: `npm run backup` (baca: `npm run backup -- --read FILE`). **Salin folder backups/ dan simpan ENC_KEY di tempat lain** (satu server = satu titik gagal).

## Login & anti-bot
- Sesi 30 hari, diperpanjang otomatis selama dipakai; halaman login/daftar langsung masuk bila sesi masih aktif. "Keluar dari semua perangkat" tetap mencabut semua sesi.
- **Cloudflare Turnstile** di login & daftar: isi `TURNSTILE_SITE` + `TURNSTILE_SECRET` (dash.cloudflare.com → Turnstile, tambahkan domain situs). Keduanya terisi = wajib (fail-closed); kosong = nonaktif.

## Keamanan & fitur akun
- **Aktivitas Keamanan** (Profil → Keamanan): riwayat login berhasil/gagal, ganti password, reset password panel (IP disamarkan, perangkat dikenali). **Keluar dari semua perangkat** menghapus semua sesi sekaligus.
- Kebijakan password seragam (daftar & ganti): min 8 karakter, bukan password umum, tidak memuat username. Akun terkunci 15 menit setelah 5x salah.
- Cek CSRF memakai host akses (tidak bergantung `APP_URL`), header keamanan Helmet + CSP ketat, rate limit di semua endpoint, respons error seragam JSON (tanpa stack trace), `/api/*` tak dikenal → JSON 404.
- **Admin**: tab *Log Admin* (semua aksi admin tercatat) dan *Pengaturan* (teks pengumuman dashboard). Health-check: `GET /healthz`. `robots.txt` memblokir halaman member/admin/API.

## Ketahanan sistem (mitigasi)
- **Worker rekonsiliasi** (tiap ~45 dtk): memverifikasi pembayaran yang webhook-nya gagal/telat, mencoba ulang pembuatan server yang gagal (backoff 30dtk → 10mnt, maks 8x), memulihkan proses yang macet, dan memproses pembayaran yang masuk setelah dibatalkan/kedaluwarsa. Status di admin → Ringkasan → Kesehatan Sistem.
- **Circuit breaker** untuk gateway Averpay: bila down, request gagal cepat dengan pesan jelas (tidak menggantung/menumpuk), pulih otomatis.
- **Provisioning idempotent** (`external_id` per pesanan/klaim): retry setelah timeout tidak pernah membuat server dobel. Pencarian allocation kosong menelusuri semua halaman.
- **Anti order dobel**: 1 pembuatan QRIS per user pada satu waktu; pesanan identik yang masih berlaku dipakai ulang.
- **Mode pemeliharaan** (admin → Pengaturan, atau `MAINTENANCE=1`): order baru ditolak dengan pesan, fitur lain tetap jalan.
- Tiap request punya **ID** (`X-Request-Id`); error server menampilkan `Ref: xxxx` yang cocok dengan baris log. Graceful shutdown (SIGTERM/SIGINT). Timeout koneksi diperketat.
- **Test otomatis**: `npm test` (20 test: breaker, klien gateway, provisioning idempotent, status, garansi). Jalankan setiap selesai mengubah kode.

## Alur
- **Order:** pilih paket → QRIS → terdeteksi otomatis → server aktif. Bisa **dibatalkan** selama belum dibayar. Riwayat selesai bisa **dihapus** (hanya disembunyikan; server & garansi tidak terpengaruh).
- **Garansi (30 hari sejak aktif, 1x/pesanan):** `/garansi` → TRX ID + WhatsApp pendaftar → ajukan klaim → admin setujui di `/admin` tab Garansi → server **baru (ID baru)** dibuat, server lama dihapus. `WARRANTY_AUTO=1` untuk eksekusi otomatis.
- **Akun panel:** tombol reset password panel di Dashboard → Akun Panel.
- **Pembayaran terlambat:** QRIS yang sudah dibatalkan/kedaluwarsa tapi ternyata dibayar tetap diproses saat webhook Averpay masuk.
- **Gagal provisioning:** dicoba ulang otomatis (maks 5x); admin juga bisa klik Ulangi.

## Catatan Averpay (sesuai docs.json)
- Auth lewat header `x-api-key` (key tidak pernah ada di URL/log). Endpoint yang dipakai: `GET /api/invoice`, `GET /api/invoice/status`, `GET /api/balance` (health-check di /status).
- Nominal invoice: min diatur admin Averpay, **maks Rp 1.000.000**. Total bayar = nominal + fee (dihitung gateway). Pesan validasi gateway (mis. minimal nominal) ditampilkan apa adanya ke user.
- `qris_image` berupa URL → diproxy lewat `/api/qr/...` (same-origin, CSP tetap ketat). URL gateway & `payment_link` tidak pernah dikirim ke browser. `expired_at` tanpa zona waktu → WIB/UTC dideteksi otomatis.
- Webhook `POST /webhook/averpay` (timeout 5 dtk, tanpa retry): dibalas 200 dulu, status selalu diverifikasi ulang ke `/api/invoice/status`. Polling tiap ~3,5 dtk menjadi cadangan bila webhook tidak masuk.


## Keamanan tambahan
- Verifikasi 2 langkah (TOTP, kompatibel Google Authenticator/Authy) + 8 kode pemulihan sekali pakai (Profil → Keamanan). Login 2 langkah memakai tiket 5 menit.
- Kunci akun bertingkat: 5 gagal = 15 menit, 10 = 1 jam, 15+ = 24 jam.
- Penjaga per-IP (credential stuffing): terlalu banyak username berbeda/gagal dari satu IP diblokir 30 menit.
- Halaman 404 baru dengan teks formal.

## Pembaruan terbaru
- Semua gradasi warna dihapus (satu warna teal solid). 404 disederhanakan (teks + tombol Kembali).
- Pencarian cepat Ctrl/⌘+K, tombol kembali ke atas, skor keamanan di Profil, manifest PWA, tag OG, footer publik dirapikan.

- 404 gaya halaman galat (Browser · Server · Halaman, status server nyata), pengumuman dashboard statis.
- Perbaikan modal/sheet di Android: dirender lewat portal ke body, animasi tidak lagi bisa membuat dialog macet di luar layar.

## Integrasi Averpay & ketahanan pembayaran
- Mengikuti https://app.averpay.my.id/docs (+ docs.json): API key lewat header `x-api-key` (tidak di URL), `GET /api/invoice` (maks Rp 1.000.000, divalidasi sebelum dikirim) dan `GET /api/invoice/status`; webhook `POST /webhook/averpay` hanya pemicu, status SELALU diverifikasi ulang ke gateway (timeout 5 dtk, tanpa retry dari Averpay).
- **Idempotency-Key** untuk pembuatan pesanan (panel, premium, nomor virtual): klik ganda/retry memutar ulang respons pertama, tidak membuat invoice ganda (tabel `idem_keys`, dibersihkan 24 jam).
- **Verifikasi nominal**: lunas hanya sah bila total yang diterima gateway >= tagihan (anti kurang bayar/salah invoice).
- **Invoice yatim** (dibuat di gateway tapi gagal disimpan) dicatat ke tabel `orphan_invoices` untuk rekonsiliasi.
- Webhook ganda untuk invoice yang sama diproses sekali; semua langkah (bayar, buat server, order penyedia) memakai klaim atomik, tidak pernah membeli ulang saat hasil tak pasti.
- Log akses di console: `[SnowyStore] 13/10 05:54:01  POST  /api/login  401  38ms  180.252.-.-  #a1b2c3d4` (query string tidak dicatat, IP disamarkan, aset statis dilewati; matikan dengan `LOG_REQUESTS=0`).

## Perisai anti-serangan (lib/shield.js)
- Jalur sensitif (`.env`, `.git`, `.htaccess`, `/uploads`, dsb.) dijawab 404 dan memberi poin; 3 kali = IP diblokir sementara.
- Enumerasi: 404 beruntun (terutama di `/api/`) memblokir IP sementara.
- Alat otomatis (curl, okhttp, python-requests, dll.) ditolak pada `POST /api/login` dan `/api/register`.
- Gagal login/2FA ikut menambah poin IP (melengkapi kunci akun dan penjaga credential stuffing).
- Blokir bertingkat: 30 menit -> 6 jam -> 24 jam; tercatat di console `[shield] BLOKIR ...`. Webhook Averpay tidak pernah diblokir.
- `/healthz` dibatasi 30 request/menit per IP. Env: `SHIELD=0` mematikan, `SHIELD_ALLOW=ip1,ip2` daftar putih (isi IP Anda sendiri).
- Brute force SSH ditangani di level server hosting (gunakan login SSH dengan key bila Anda punya akses server).
- Halaman publik (beranda, status, panduan, ketentuan, bantuan): klik kanan, tahan-salin, seleksi teks, seret gambar, F12/Ctrl+U/Ctrl+Shift+I/J/C/Ctrl+S dinonaktifkan (components/Deterrent.js). Halaman akun tetap bisa disalin (password panel, TRX ID, OTP). Ini hanya penghalang awam; keamanan sebenarnya ada di server.

## Desain OpenWA (port penuh)
Sistem desain dashboard OpenWA dipakai di SnowyStore, dengan **warna merek tetap SnowyStore** (teal `#19808f`, ikon multiwarna):
- **Tema terang saja**: dark mode dan tombol tema sudah dihapus; tampilan selalu terang (warna merek tetap teal SnowyStore).
- **Token & bentuk OpenWA**: slate untuk mode terang, pasangan warna teks yang lulus AA (`--primary-text`, `--ok-text`, `--bad-text`, `--warn-text`), bayangan, radius 4/6/8/10/12/16/pill, tombol dan kartu bergaya OpenWA.
- **Font**: Plus Jakarta Sans Variable + JetBrains Mono Variable (`@fontsource-variable`, lokal, tanpa CDN).
- **Komponen**: CustomSelect (keyboard penuh), grafik area/donat/batang bergaya DashboardCharts (recharts, lazy, di Admin → Ringkasan), PageHeader, kartu stat berwatermark, toggle, toast, modal/bottom-sheet, skeleton, pencarian cepat.
- **Animasi**: transform/opacity saja, `prefers-reduced-motion` dihormati.
- Tidak dibawa: i18n 15 bahasa/RTL dan halaman khusus WhatsApp.
- Setelah memasang: `npm install` (dependensi font berganti & `recharts` ditambah), hapus folder `.next`, jalankan ulang.
- **Avatar**: hanya cincin/pinggir lingkaran huruf (cincin yang dulunya putih) yang memakai 4 warna Google (biru `#4285F4`, merah `#EA4335`, kuning `#FBBC05`, hijau `#34A853`), statis tanpa efek glow. Isi lingkaran tetap teal SnowyStore. Token: `--google-ring`.
- **Watermark ikon di semua kartu**: `components/CardWatermarks.js` (otomatis untuk semua `.card` di semua halaman, memakai ikon judul kartu atau kepingan salju) dan `components/Wm.js` (manual, wajib dengan class `wmk` pada induknya).
- **Panel Admin**: navigasi samping bergrup di desktop dan bar geser (sticky) di HP, kartu KPI dengan watermark, aksi cepat, daftar berbentuk grid kartu, dan Pengaturan/Premium/Nokos/Saldo dalam tata letak dua kolom.

## SEO dan keterbacaan AI (AEO)
Menjawab temuan alat audit (LightSite AI Slop Detector dan slop/check):
- **Canonical** otomatis di semua halaman (`pages/_app.js`), plus `og:url`, `og:image` absolut, dan `twitter:image`.
- **Data terstruktur JSON-LD**: `OnlineStore` (Organization) + `WebSite` di semua halaman, `FAQPage` (landing dan Bantuan), `HowTo` (Cara Order), `BreadcrumbList`, `CollectionPage`, `BlogPosting` (artikel), `AboutPage`, dan `ContactPage`. Helper ada di `components/site.js` dan `components/JsonLd.js`.
- **Identitas dan kontak yang terbaca crawler**: halaman `/tentang` dan `/kontak`, serta kontak di footer. Datanya dibaca saat **build** dari `.env`: `CONTACT_EMAIL`, `CONTACT_WA`, `CONTACT_ADDRESS` (opsional). Isi dulu, baru `npm run build`.
- **Blog/panduan**: `/panduan` dan 5 artikel di `content/panduan.js`, diselaraskan dengan Syarat dan Ketentuan. Tambah artikel baru cukup dengan menambah objek di file itu.
- **`/sitemap.xml` dan `/robots.txt` dinamis** (mengikuti `APP_URL`); `public/robots.txt` lama dihapus karena bentrok dengan rute dinamis.
- Tanda pisah em dash di teks tampilan diganti tanda hubung biasa.

## Integrasi Averpay (sesuai docs.json terbaru)
- **Nokos memakai API terbaru**: server (`ekonomi`, `premium`, `khusus`, `wa_luar`) → layanan → negara → produk dengan `quote_id`, lalu `POST /api/nokos/order`. Kode layanan/negara kini string dan disimpan di kolom lama (`platform_id`, `country_id`, `product_id` otomatis diubah ke VARCHAR saat boot) plus kolom baru `server`, `operator`, `otp_code2`, `resend_at`.
- **`quote_id` hanya berlaku 5 menit**, sedangkan QRIS bisa dibayar lebih lama. Karena itu setelah pembayaran lunas katalog diambil ulang tanpa cache dan produk dicari lewat id buramnya; pesanan memakai quote yang segar. Bila produk hilang, stok habis, atau harga penyedia naik melebihi yang dibayar pelanggan, pesanan masuk "Menunggu pengembalian dana" tanpa memesan nomor.
- **Operator** (any, telkomsel, indosat, axis, three, smartfren, byu) dapat dipilih untuk server Premium.
- **OTP kedua** (`POST /api/nokos/resend`): tombol di detail pesanan, gratis, maksimal sekali, setelah OTP pertama masuk. `otpCode2` dipantau lalu disimpan terenkripsi.
- **Batalkan nomor** (`POST /api/nokos/cancel`): tombol admin untuk nomor yang menunggu OTP (minimal 120 detik dan belum ada OTP); saldo Averpay kembali sekali, dan dana pembeli tetap dikembalikan admin.
- Semua aksi POST memakai `averpay.post()` yang tidak pernah diulang otomatis. Panel (`/api/pterodactyl/*`), Premium (`/api/premium/*`), invoice QRIS, dan webhook `deposit.paid` sudah sesuai dokumentasi dan tidak berubah.
- Pesanan Nokos lama yang masih berstatus menunggu bayar saat Anda memasang versi ini akan masuk "Menunggu pengembalian dana" bila dibayar (ID angka lama tidak dikenal API baru). Itu perilaku aman, tanpa pembelian ganda.
- Tidak diintegrasikan (sengaja): withdraw, Gacha Nokos, Fix No, Suntik Sosmed, dan Reseller. Fitur-fitur itu tidak dijual di toko ini; withdraw sebaiknya tetap lewat dashboard Averpay.

## Perlindungan aplikasi
Berjalan di dalam aplikasi Node (cocok untuk Pterodactyl, tanpa akses root):
- `lib/shield.js`: memblokir sementara IP yang membuka jalur sensitif, 404 beruntun, metode HTTP aneh, URL terlalu panjang, `/api` tanpa User-Agent, atau terlalu banyak request (blokir bertingkat 30 menit, 6 jam, 24 jam). Admin dapat melihat dan membuka blokir di **Admin → Pengaturan → Perisai Keamanan**.
- Batas request per IP, penjaga login, kunci akun, dan Cloudflare Turnstile di login/daftar.
- Server Node memakai batas waktu header/request agar koneksi menggantung tidak menumpuk; `MAX_CONNECTIONS` opsional.
- Config firewall/nginx tingkat server (folder `deploy/`) **sudah dihapus** karena butuh akses root yang tidak ada di Pterodactyl.

## Framework dan arsitektur (keputusan)
Stack tetap **Next.js 16 (React) + Express + MySQL** dengan CSS design system OpenWA buatan sendiri. Tidak diganti ke Vue/Nuxt, Tailwind, atau Bootstrap karena tidak memberi keuntungan nyata di sini (SSR/SEO Next.js sudah setara Nuxt) dan memaksa menulis ulang seluruh halaman, 160 test, dan desain.
Perbaikan yang benar-benar menambah SEO produk: **paket dan harga dirender di server** (ISR 5 menit) di `/` dan halaman baru **`/produk`** (`components/catalog.js`), lengkap dengan JSON-LD `Product`/`Offer`. Data diambil lewat loopback ke `/api/packages` (cache dan perlindungan yang sama); bila gagal, halaman tetap tampil dan terisi saat revalidate.

