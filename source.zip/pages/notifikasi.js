import { useEffect, useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { Bell, CheckCheck, RefreshCw } from 'lucide-react';
import { api } from '../components/api';
import AppShell from '../components/AppShell';
import PageSkeleton from '../components/Skeleton';
import { NotifItem, NotifEmpty, useNotifs } from '../components/Notifications';
const FILTERS = [['all', 'Semua', () => true], ['unread', 'Belum dibaca', (n) => n.unread], ['sec', 'Keamanan', (n) => ['login', 'login_fail', 'security'].includes(n.kind)], ['ord', 'Pesanan', (n) => ['order', 'premium', 'nokos', 'claim'].includes(n.kind)]];
export default function Notifikasi() {
  const r = useRouter(), [me, setMe] = useState(null), [f, setF] = useState('all'), [busy, setBusy] = useState(false), { items, unread, loaded, readAll, reload } = useNotifs(true);
  useEffect(() => { api('/me').then(setMe).catch((e) => { if (e.status === 401) r.push('/login'); }); }, [r]);
  if (!me) return <PageSkeleton cards={2} />;
  const shown = items.filter(FILTERS.find((x) => x[0] === f)[2]);
  return (<AppShell me={me} active="notifikasi"><Head><title>Notifikasi - SnowyStore</title></Head>
    <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
      <div className="pop-h"><b style={{ display: 'flex', gap: 10, alignItems: 'center' }}><Bell size={20} className="pri" />Notifikasi{unread ? <span className="badge">{unread} baru</span> : null}</b>
        <span style={{ display: 'flex', gap: 4 }}><button onClick={async () => { setBusy(true); try { await reload(); } catch {} setBusy(false); }} aria-label="Muat ulang"><RefreshCw size={14} className={busy ? 'spin' : ''} /></button><button onClick={readAll} disabled={!unread}><CheckCheck size={14} className="vm" /> Tandai semua dibaca</button></span></div>
      <div className="chips" style={{ margin: 0, padding: '12px 16px', borderBottom: '1px solid var(--border)' }}>{FILTERS.map(([k, l, fn]) => <button key={k} className={'chip' + (f === k ? ' on' : '')} onClick={() => setF(k)}>{l} ({items.filter(fn).length})</button>)}</div>
      <div className="stag">{!loaded ? <div style={{ padding: 16, display: 'grid', gap: 10 }}><div className="sk l2" /><div className="sk l1" /></div> : shown.length === 0 ? <NotifEmpty /> : shown.map((n) => <NotifItem key={n.id} n={n} />)}</div></div>
    <small className="mut">Notifikasi mencakup 30 hari terakhir: login (termasuk perangkat baru), status pesanan, dan klaim garansi.</small></AppShell>);
}
