import CardWatermarks from '../components/CardWatermarks';
import Head from 'next/head';
import '@fontsource-variable/plus-jakarta-sans';
import '@fontsource-variable/plus-jakarta-sans/wght-italic.css';
import '@fontsource-variable/jetbrains-mono';
import '../styles/globals.css';
import ErrorBoundary from '../components/ErrorBoundary';
import Toasts from '../components/Toast';
import QuickTools from '../components/QuickTools';
import Deterrent from '../components/Deterrent';
import { useRouter } from 'next/router';
import { useReveal } from '../components/hooks';
import JsonLd from '../components/JsonLd';
import { SITE_URL, orgSchema, siteSchema } from '../components/site';
export default function App({ Component, pageProps }) {
  const r = useRouter(); useReveal(r.asPath);
  const path = (r.asPath || '/').split(/[?#]/)[0].replace(/\/+$/, '') || '/', canon = r.pathname === '/404' || r.pathname === '/_error' ? null : SITE_URL + (path === '/' ? '/' : path);
  return (<><Head><title>SnowyStore | Toko Digital: Aplikasi Premium, Nomor OTP &amp; Hosting</title>{canon && <link rel="canonical" href={canon} />}{canon && <meta property="og:url" content={canon} />}<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" /><meta name="theme-color" content="#f8fafc" /><meta name="color-scheme" content="light" /><link rel="manifest" href="/manifest.webmanifest" /><link rel="apple-touch-icon" href="/img/apple-touch-icon.png?v=4" /><meta property="og:type" content="website" /><meta property="og:site_name" content="SnowyStore" /><meta property="og:title" content="SnowyStore | Toko Digital" /><meta property="og:description" content="Aplikasi premium, nomor virtual OTP, dan hosting server panel. Bayar QRIS, diproses otomatis." /><meta property="og:image" content={SITE_URL + '/img/SnowyStore.webp'} /><meta property="og:image:width" content="1254" /><meta property="og:image:height" content="1254" /><meta property="og:image:alt" content="Logo SnowyStore" /><meta name="twitter:image" content={SITE_URL + '/img/SnowyStore.webp'} /><meta name="twitter:card" content="summary" /><meta name="description" content="SnowyStore: toko digital untuk akun aplikasi premium, nomor virtual OTP, dan hosting server panel Pterodactyl. Pembayaran QRIS dan pemrosesan otomatis." /><link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32.png?v=4" /><link rel="icon" type="image/png" sizes="192x192" href="/img/favicon.png?v=4" /><link rel="apple-touch-icon" href="/img/apple-touch-icon.png?v=4" />
    </Head><JsonLd id="ld-org" data={orgSchema()} /><JsonLd id="ld-site" data={siteSchema()} /><ErrorBoundary><Component {...pageProps} /></ErrorBoundary><Toasts /><CardWatermarks /><QuickTools /><Deterrent /></>);
}
