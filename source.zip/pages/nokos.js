import { useEffect, useState, useCallback, useMemo } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { Search, Smartphone, RefreshCw, LoaderCircle, ChevronRight, ChevronLeft, Trash2, TriangleAlert, Ban, Info, Check } from 'lucide-react';
import { api, rp, fdate, NOK, NOKHINT, nokClass } from '../components/api';
import AppShell from '../components/AppShell';
import PageSkeleton from '../components/Skeleton';
import Modal from '../components/Modal';
import Confirm from '../components/Confirm';
import NokosDetail from '../components/NokosDetail';
import CustomSelect from '../components/CustomSelect';

const STEPS = ['Server', 'Aplikasi', 'Negara', 'Harga'], OPLABEL = { any: 'Semua operator', telkomsel: 'Telkomsel', indosat: 'Indosat', axis: 'Axis', three: 'Tri (3)', smartfren: 'Smartfren', byu: 'by.U' };
export default function Nokos() {
  const r = useRouter();
  const [me, setMe] = useState(null), [step, setStep] = useState(1), [srvs, setSrvs] = useState(null), [srv, setSrv] = useState(null), [ops, setOps] = useState(['any']), [op, setOp] = useState('any'), [svc, setSvc] = useState(null), [cty, setCty] = useState(null), [prd, setPrd] = useState(null), [pl, setPl] = useState(null), [co, setCo] = useState(null), [sel, setSel] = useState(null);
  const [q, setQ] = useState(''), [err, setErr] = useState(''), [orders, setOrders] = useState([]), [off, setOff] = useState(''), [agree, setAgree] = useState(false), [busy, setBusy] = useState(false), [oerr, setOerr] = useState(''), [detail, setDetail] = useState(null), [cf, setCf] = useState(null), [note, setNote] = useState(''), [loadingStep, setLoadingStep] = useState(false);
  const loadOrders = useCallback(async () => { try { setOrders(await api('/nokos/orders')); } catch (e) { if (e.status === 401) r.push('/login'); } }, [r]);
  const boot = useCallback(async () => {
    const [m, c] = await Promise.allSettled([api('/me'), api('/config')]);
    if (m.status === 'rejected') { if (m.reason.status === 401) r.push('/login'); else setErr(m.reason.message); return; }
    setMe(m.value);
    if (c.status === 'fulfilled') { const s = (c.value.services || {}).nokos; setOff(c.value.maintenance ? c.value.maintenance_msg || 'Sedang pemeliharaan. Pembelian dibuka kembali sebentar lagi.' : s && s.on === false ? s.msg || 'Pembelian nomor virtual sedang dinonaktifkan sementara.' : ''); }
    try { const s = await api('/nokos/servers'); setSrvs(s.items); setOps(s.operators || ['any']); setErr(''); } catch (e) { setSrvs([]); setErr(e.message); }
    loadOrders();
  }, [r, loadOrders]);
  useEffect(() => { boot(); }, [boot]);
  const pickServer = async (s) => { setSrv(s); setQ(''); setStep(2); setNote(''); setPl(null); setCo(null); setPrd(null); setSvc(null); setOp('any'); setLoadingStep(true); try { const r = await api(`/nokos/services?server=${encodeURIComponent(s.id)}`); setSvc(r.items); setErr(''); } catch (e) { setSvc([]); setErr(e.message); } setLoadingStep(false); };
  const pickApp = async (p) => { setPl(p); setQ(''); setStep(3); setNote(''); setCo(null); setPrd(null); if (!cty) { setLoadingStep(true); try { const c = await api('/nokos/countries'); setCty(c.items); setErr(''); } catch (e) { setCty([]); setErr(e.message); } setLoadingStep(false); } };
  const pickCountry = async (c) => {
    setCo(c); setQ(''); setStep(4); setPrd(null); setLoadingStep(true);
    try { const p = await api(`/nokos/products?server=${encodeURIComponent(srv.id)}&service=${encodeURIComponent(pl.id)}&country=${encodeURIComponent(c.id)}`); setPrd(p.items); setErr(''); } catch (e) { setPrd([]); setErr(e.message); }
    setLoadingStep(false);
  };
  const back = () => { setQ(''); setErr(''); setStep((s) => Math.max(1, s - 1)); };
  const buy = async () => {
    setBusy(true); setOerr('');
    try { const o = await api('/nokos/orders', 'POST', { server: srv.id, service: pl.id, country: co.id, product_id: sel.id, price: sel.price, ...(srv.id === 'premium' ? { operator: op } : {}) }); setSel(null); setAgree(false); setDetail({ id: o.id, initial: o }); loadOrders(); }
    catch (e) { setOerr(e.message); if (e.status === 409) { try { const p = await api(`/nokos/products?server=${encodeURIComponent(srv.id)}&service=${encodeURIComponent(pl.id)}&country=${encodeURIComponent(co.id)}`); setPrd(p.items); } catch {} } }
    setBusy(false);
  };
  const del = async () => { setBusy(true); try { await api(`/nokos/orders/${cf.id}`, 'DELETE'); } catch (e) { setNote(e.message); } setBusy(false); setCf(null); loadOrders(); };
  const clearAll = async () => { setBusy(true); try { const x = await api('/nokos/orders/clear', 'POST'); setNote(`${x.removed} riwayat dihapus (data tetap tersimpan).`); } catch (e) { setNote(e.message); } setBusy(false); setCf(null); loadOrders(); };
  const list = useMemo(() => { const src = step === 1 ? srvs : step === 2 ? svc : step === 3 ? cty : prd; const t = q.trim().toLowerCase(); return (src || []).filter((x) => !t || x.name.toLowerCase().includes(t)); }, [step, srvs, svc, cty, prd, q]);
  const finished = ['done', 'refunded', 'expired', 'cancelled'];
  if (!me) return err ? (<div className="wrap"><div className="card center"><><p className="msg e" style={{ marginTop: 0 }}>{err}</p><button className="btn" onClick={boot}>Coba lagi</button></></div></div>) : <PageSkeleton cards={3} />;
  return (<AppShell me={me} active="nokos" head={{ title: 'Nomor Virtual (OTP)', sub: 'Pilih server, aplikasi, negara, dan harga. Kode OTP muncul otomatis.', icon: Smartphone, actions: <button className="btn ghost sm" onClick={boot}><RefreshCw size={15} />Muat ulang</button> }}><Head><title>Nomor Virtual (Nokos) - SnowyStore</title></Head>
    <div className="card">
      <p className="mut" style={{ marginTop: 0 }}>Sewa nomor sementara untuk menerima kode OTP. Pilih server, aplikasi, negara, lalu harga. Bayar dengan QRIS, nomor tampil otomatis dan kode OTP muncul di halaman ini.</p>
      {off && <div className="msg warnm"><TriangleAlert size={16} className="vm" /> {off}</div>}
      <ol className="steps3" aria-label="Langkah">{STEPS.map((s, i) => <li key={s} className={step === i + 1 ? 'on' : step > i + 1 ? 'ok' : ''}><span>{step > i + 1 ? <Check size={13} /> : i + 1}</span>{s}</li>)}</ol>
      {step > 1 && <div className="crumb"><button className="chip" onClick={back}><ChevronLeft size={14} />Kembali</button><small className="mut">{srv && <b>{srv.name}</b>}{pl && <> - <b>{pl.name}</b></>}{co && <> - <b>{co.name}</b></>}</small></div>}
      {err && <div className="msg e">{err} <button className="linkbtn" onClick={() => (step === 1 ? boot() : step === 2 ? pickServer(srv) : step === 3 ? pickApp(pl) : pickCountry(co))}>Coba lagi</button></div>}
      <label className="srch"><Search size={18} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={step === 1 ? 'Cari server…' : step === 2 ? 'Cari aplikasi (mis. WhatsApp)…' : step === 3 ? 'Cari negara…' : 'Cari paket…'} aria-label="Cari" /></label>
      {(step === 1 && !srvs) || loadingStep ? <div className="center loading"><LoaderCircle size={18} className="spin" /> Memuat…</div> : <>
        {list.length === 0 && !err && <div className="empty"><b>{q ? 'Tidak ada hasil' : step === 4 ? 'Belum ada nomor tersedia' : 'Daftar kosong'}</b><small className="mut">{q ? 'Coba kata kunci lain.' : step === 4 ? 'Stok untuk kombinasi ini sedang habis. Coba negara, aplikasi, atau server lain.' : 'Coba muat ulang beberapa saat lagi.'}</small></div>}
        <div className="nlist">{list.map((x) => step === 4
          ? <button key={x.id} className="nitem" onClick={() => { setSel(x); setAgree(false); setOerr(''); }}><span className="nm">{x.name}<small className="mut">{x.stock != null ? `Stok ${x.stock}` : 'Tersedia'}</small></span><b className="pr">{rp(x.price)}</b><ChevronRight size={18} /></button>
          : <button key={x.id} className="nitem" onClick={() => (step === 1 ? pickServer(x) : step === 2 ? pickApp(x) : pickCountry(x))}><span className="nm">{x.emoji ? `${x.emoji} ` : ''}{x.name}</span><ChevronRight size={18} /></button>)}</div></>}
    </div>
    <div className="card"><div className="ch"><Smartphone size={22} className="pri" /><b>Pesanan Nokos Saya</b></div>
      {note && <div className="msg warnm">{note}</div>}
      {orders.length === 0 && <div className="empty"><b>Belum ada pesanan nomor</b><small className="mut">Pilih aplikasi di atas untuk mulai. Nomor dan kode OTP tampil di sini setelah pembayaran terverifikasi.</small></div>}
      {orders.some((o) => finished.includes(o.status)) && <div style={{ marginBottom: 10 }}><button className="chip danger" onClick={() => setCf({ all: true })}><Trash2 size={14} />Hapus semua riwayat selesai</button></div>}
      {orders.map((o) => <div className="ord2" key={o.id}><div className="ordtop"><div className="ordn"><b>{o.platform_name} - {o.country_name}</b><small className="mut">{o.server_name} - {rp(o.price)} - {fdate(o.created_at)}</small>{o.phone && ['waiting_otp', 'done'].includes(o.status) && <small className="mono">{o.phone}</small>}</div><span className={'stt ' + nokClass(o.status)}>{NOK[o.status]}</span></div>
        {NOKHINT[o.status] && <small className="hint"><Info size={14} />{NOKHINT[o.status]}</small>}
        <div className="ordact"><button className="btn sm" onClick={() => setDetail({ id: o.id, initial: null })}>{o.status === 'awaiting_payment' ? 'Bayar' : o.status === 'waiting_otp' ? 'Lihat OTP' : 'Detail'}<ChevronRight size={14} /></button>
          {finished.includes(o.status) && <button className="chip danger" onClick={() => setCf({ id: o.id })}><Trash2 size={14} />Hapus</button>}</div></div>)}
    </div>
    {sel && <Modal onClose={() => !busy && setSel(null)} label="Konfirmasi pesanan nomor" locked={busy}><h3 className="center">Konfirmasi Pesanan</h3>
      <div className="kv"><span>Server</span><b>{srv && srv.name}</b></div><div className="kv"><span>Aplikasi</span><b>{pl && pl.name}</b></div><div className="kv"><span>Negara</span><b>{co && co.name}</b></div><div className="kv"><span>Paket</span><b>{sel.name}</b></div><div className="kv"><span>Harga</span><b>{rp(sel.price)}</b></div>
      {srv && srv.id === 'premium' && <><label>Operator</label><div className="cs-field"><Smartphone size={18} /><CustomSelect ariaLabel="Operator" value={op} onChange={setOp} options={ops.map((v) => ({ value: v, label: OPLABEL[v] || v }))} /></div></>}
      <label className="chk"><input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} /><span>Saya paham: nomor hanya untuk menerima OTP, bukan untuk aktivitas ilegal. Bila OTP tidak masuk sampai waktu habis, dana dikembalikan.</span></label>
      {oerr && <div className="msg e">{oerr}</div>}
      <div className="two"><button className="btn ghost" disabled={busy} onClick={() => setSel(null)}>Batal</button><button className="btn" disabled={busy || !agree || !!off} onClick={buy}>{busy ? 'Memproses…' : `Bayar ${rp(sel.price)}`}</button></div>
      <small className="mut center" style={{ display: 'block' }}>Dibayar lewat QRIS (biaya layanan ditambahkan di tagihan). {!agree && 'Centang persetujuan untuk melanjutkan.'}</small></Modal>}
    {detail && <NokosDetail id={detail.id} initial={detail.initial} onClose={() => { setDetail(null); loadOrders(); }} onChange={loadOrders} />}
    {cf && <Confirm title={cf.all ? 'Hapus Semua Riwayat Selesai?' : 'Hapus dari Riwayat?'} text={cf.all ? 'Semua pesanan yang sudah selesai, dikembalikan, kedaluwarsa, atau dibatalkan disembunyikan dari daftar. Pastikan kode OTP yang diperlukan sudah Anda salin.' : 'Pesanan hanya disembunyikan dari daftar. Datanya tetap tersimpan, tetapi pastikan kode OTP yang diperlukan sudah Anda salin.'} yes="Ya, Hapus" busy={busy} onNo={() => setCf(null)} onYes={cf.all ? clearAll : del} />}
  </AppShell>);
}
