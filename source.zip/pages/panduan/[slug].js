import Link from 'next/link';
import { Clock, CalendarDays, UserRound } from 'lucide-react';
import PublicLayout from '../../components/PublicLayout';
import JsonLd from '../../components/JsonLd';
import { ARTICLES, bySlug, fmtDate, wordCount } from '../../content/panduan';
import { SITE_URL, abs } from '../../components/site';
export function getStaticPaths() { return { paths: ARTICLES.map((a) => ({ params: { slug: a.slug } })), fallback: false }; }
export function getStaticProps({ params }) { const a = bySlug(params.slug); return a ? { props: { slug: a.slug } } : { notFound: true }; }
export default function Artikel({ slug }) {
  const a = bySlug(slug), url = abs('/panduan/' + a.slug), rel = (a.related || []).map(bySlug).filter(Boolean);
  const post = { '@context': 'https://schema.org', '@type': 'BlogPosting', headline: a.title, description: a.desc, datePublished: a.date, dateModified: a.updated || a.date, inLanguage: 'id-ID', wordCount: wordCount(a), articleSection: a.cat, mainEntityOfPage: { '@type': 'WebPage', '@id': url }, image: SITE_URL + '/img/SnowyStore.webp',
    author: { '@type': 'Organization', name: 'Tim SnowyStore', url: SITE_URL + '/' }, publisher: { '@type': 'Organization', name: 'SnowyStore', url: SITE_URL + '/', logo: { '@type': 'ImageObject', url: SITE_URL + '/img/logo-icon.png' } } };
  return (<PublicLayout title={a.title} sub="Panduan" desc={a.desc} og="article" crumbs={[['Beranda', '/'], ['Panduan', '/panduan'], [a.title, '/panduan/' + a.slug]]}>
    <JsonLd id="ld-post" data={post} />
    <article className="art">
      <header><span className="badge">{a.cat}</span><h1>{a.title}</h1>
        <div className="byline"><span><UserRound size={15} /> Tim SnowyStore</span><span><CalendarDays size={15} /> <time dateTime={a.date}>{fmtDate(a.date)}</time></span><span><Clock size={15} /> {a.read} menit baca</span></div>
        <p className="lead">{a.intro}</p></header>
      {a.body.map(([t, v], i) => t === 'h2' ? <h2 key={i}>{v}</h2> : t === 'p' ? <p key={i}>{v}</p> : t === 'ul' ? <ul key={i}>{v.map((x) => <li key={x}>{x}</li>)}</ul> : <ol key={i}>{v.map((x) => <li key={x}>{x}</li>)}</ol>)}
    </article>
    {rel.length ? <section className="artrel"><h2>Baca juga</h2><div className="artgrid">{rel.map((r) => <Link key={r.slug} href={`/panduan/${r.slug}`} className="card hov artcard"><span className="badge">{r.cat}</span><h3>{r.title}</h3><p className="mut">{r.desc}</p></Link>)}</div></section> : null}
    <div className="card center"><h3>Siap mencoba?</h3><div className="two"><Link href="/register" className="btn">Daftar Akun</Link><Link href="/kontak" className="btn ghost">Hubungi Kami</Link></div></div>
  </PublicLayout>);
}
