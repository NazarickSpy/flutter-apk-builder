import Link from 'next/link';
import { Newspaper, Clock, ChevronRight } from 'lucide-react';
import PublicLayout from '../../components/PublicLayout';
import JsonLd from '../../components/JsonLd';
import { ARTICLES, fmtDate } from '../../content/panduan';
import { abs } from '../../components/site';
export default function Panduan() {
  const list = { '@context': 'https://schema.org', '@type': 'CollectionPage', name: 'Panduan SnowyStore', url: abs('/panduan'), inLanguage: 'id-ID', mainEntity: { '@type': 'ItemList', itemListElement: ARTICLES.map((a, i) => ({ '@type': 'ListItem', position: i + 1, url: abs('/panduan/' + a.slug), name: a.title })) } };
  return (<PublicLayout title="Panduan dan Artikel" sub="Panduan" desc="Panduan lengkap SnowyStore: cara memilih server panel Pterodactyl, membeli nomor virtual OTP, membayar dengan QRIS, garansi, dan keamanan akun." crumbs={[['Beranda', '/'], ['Panduan', '/panduan']]}>
    <JsonLd id="ld-panduan" data={list} />
    <section className="pubhead"><span className="pubico ico2"><Newspaper size={30} /></span><h1>Panduan dan Artikel</h1><p className="mut">Penjelasan praktis seputar layanan, pembayaran, garansi, dan keamanan di SnowyStore.</p></section>
    <div className="artgrid">{ARTICLES.map((a) => <Link key={a.slug} href={`/panduan/${a.slug}`} className="card hov artcard"><span className="badge">{a.cat}</span><h2>{a.title}</h2><p className="mut">{a.desc}</p><div className="artmeta"><span><Clock size={14} /> {a.read} menit baca</span><time dateTime={a.date}>{fmtDate(a.date)}</time><span className="artgo">Baca <ChevronRight size={16} /></span></div></Link>)}</div>
  </PublicLayout>);
}
