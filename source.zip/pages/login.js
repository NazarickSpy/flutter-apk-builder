import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { User, KeyRound, ArrowRight, ShieldCheck } from 'lucide-react';
import { api } from '../components/api';
import Shell, { Field } from '../components/Shell';
import Turnstile from '../components/Turnstile';
export default function Login() {
  const r = useRouter(); const [f, setF] = useState({ username: '', password: '' }); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const [tk, setTk] = useState(''), [code, setCode] = useState('');
  const [site, setSite] = useState(null), [tok, setTok] = useState(''), [nonce, setNonce] = useState(0);
  useEffect(() => { // sesi masih aktif -> langsung masuk (tanpa login ulang); sekaligus ambil kunci Turnstile
    let dead = false;
    api('/me').then((m) => { if (!dead) r.replace(m.role === 'admin' ? '/admin' : '/dashboard'); }).catch(() => {});
    api('/config').then((c) => { if (!dead) setSite(c.turnstile || ''); }).catch(() => { if (!dead) setSite(''); });
    return () => { dead = true; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const go = async (e) => { e.preventDefault(); setBusy(true); setErr(''); try { const x = await api('/login', 'POST', { ...f, cf: tok }); if (x.need_2fa) { setTk(x.ticket); setBusy(false); return; } r.push(x.role === 'admin' ? '/admin' : '/dashboard'); } catch (x) { setErr(x.message); setBusy(false); setTok(''); setNonce((n) => n + 1); } }; // token sekali pakai: minta yang baru
  const go2 = async (e) => { e.preventDefault(); setBusy(true); setErr(''); try { const x = await api('/login/2fa', 'POST', { ticket: tk, code }); r.push(x.role === 'admin' ? '/admin' : '/dashboard'); } catch (x) { setErr(x.message); setBusy(false); if (/berakhir|tidak valid/i.test(x.message)) { setTk(''); setCode(''); } } };
  if (tk) return (<Shell tab="login"><form onSubmit={go2}><h1 className="ttl">Verifikasi 2 Langkah</h1><p className="mut">Masukkan 6 digit kode dari aplikasi autentikator Anda, atau salah satu kode pemulihan.</p>
    <Field icon={ShieldCheck} label="Kode Verifikasi" placeholder="123456" autoComplete="one-time-code" inputMode="text" value={code} onChange={(e) => setCode(e.target.value)} required autoFocus />
    {err && <div className="msg e">{err}</div>}
    <button className="btn full pill" disabled={busy || code.trim().length < 6}>{busy ? 'Memeriksa…' : <>Verifikasi <ArrowRight size={20} /></>}</button></form>
    <p className="mut center sep"><button type="button" className="lnk" onClick={() => { setTk(''); setCode(''); setErr(''); }}>Kembali ke login</button></p></Shell>);
  return (<Shell tab="login">
    <form onSubmit={go}><h1 className="ttl">Selamat Datang Kembali</h1><p className="mut">Masuk dengan email atau username untuk mengelola pesanan Anda.</p>
      <Field icon={User} label="Email atau Username" placeholder="nama@email.com atau username" autoComplete="username" value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} required />
      <Field icon={KeyRound} label="Kata Sandi" type="password" placeholder="••••••••" autoComplete="current-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} required />
      <div className="forgot"><Link href="/bantuan" className="lnk">Lupa sandi?</Link></div>
      <Turnstile siteKey={site} onToken={setTok} onError={() => setErr('Verifikasi keamanan gagal dimuat. Nonaktifkan pemblokir iklan atau coba jaringan lain, lalu muat ulang.')} resetNonce={nonce} />
      {err && <div className="msg e">{err}</div>}
      <button className="btn full pill" disabled={busy || site === null || (!!site && !tok)}>{busy ? 'Memproses…' : site && !tok ? 'Memverifikasi…' : <>Masuk Sekarang <ArrowRight size={20} /></>}</button></form>
    <p className="mut center sep">Belum memiliki akun? <Link href="/register" className="lnk">Daftar Akun Baru</Link></p></Shell>);
}
