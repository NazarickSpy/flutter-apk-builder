import Link from 'next/link';
import { BookOpen } from 'lucide-react';
import PublicLayout from '../components/PublicLayout';
import JsonLd from '../components/JsonLd';
import { abs } from '../components/site';
const STEPS = [
  ['Buat Akun', 'Daftar dengan username, email, dan nomor WhatsApp aktif. Nomor WhatsApp dipakai untuk bantuan dan verifikasi pesanan, jadi pastikan nomornya benar.'],
  ['Pilih Layanan', 'Pilih server panel Pterodactyl (RAM 1 GB sampai 10 GB) atau aplikasi premium. Harga dihitung oleh sistem dan ditampilkan sebelum Anda membayar.'],
  ['Bayar dengan QRIS', 'Scan QRIS lewat e-wallet atau m-banking apa pun dan bayar sesuai nominal tagihan, yang sudah termasuk biaya layanan. QRIS memiliki batas waktu. Untuk aplikasi premium, baca deskripsi produk sebelum membayar.'],
  ['Pesanan Diproses', 'Pembayaran terdeteksi otomatis. Server panel dibuat dan data login tampil di Akun Panel, atau data akun premium tampil di halaman pesanan. Semua data tersimpan di akun Anda. Jika pesanan gagal diproses, dana dikembalikan oleh admin.'],
  ['Membatalkan atau Menghapus Riwayat', 'Pesanan yang belum dibayar dapat dibatalkan dari Dashboard atau Riwayat Pesanan. Riwayat pesanan yang sudah selesai dapat dihapus kapan saja; penghapusan hanya menyembunyikan catatan dan tidak memengaruhi server maupun garansi.'],
  ['Ada Kendala?', 'Server panel berstatus non-garansi dan memiliki masa aktif sesuai paket. Jika pesanan sudah dibayar tetapi panel belum aktif, hubungi bantuan dengan TRX ID Anda; dana dikembalikan bila pesanan gagal dibuat. Untuk aplikasi premium, hubungi bantuan dengan kode pesanan.']];
export default function CaraOrder() {
  const howto = { '@context': 'https://schema.org', '@type': 'HowTo', name: 'Cara order di SnowyStore', description: 'Dari pendaftaran sampai pesanan aktif dengan pembayaran QRIS.', inLanguage: 'id-ID', step: STEPS.slice(0, 4).map(([name, text], i) => ({ '@type': 'HowToStep', position: i + 1, name, text, url: abs('/cara-order') + '#langkah-' + (i + 1) })) };
  return (<PublicLayout crumbs={[['Beranda', '/'], ['Cara Order', '/cara-order']]} title="Panduan & Cara Order" sub="Panduan Order" desc="Panduan memesan server panel Pterodactyl dan aplikasi premium di SnowyStore dengan pembayaran QRIS.">
    <JsonLd id="ld-howto" data={howto} />
    <section className="pubhead"><span className="pubico ico1"><BookOpen size={30} /></span><h1>Panduan &amp; Cara Order</h1><p className="mut">Dari pendaftaran sampai pesanan aktif, langkah demi langkah.</p></section>
    {STEPS.map(([t, d], i) => <div className={`card step ico${(i % 6) + 1}`} key={t} id={`langkah-${i + 1}`}><span className="stepn">{String(i + 1).padStart(2, '0')}</span><div><h3>{t}</h3><p className="mut">{d}</p></div></div>)}
    <div className="card center"><h3>Siap memulai?</h3><div className="two"><Link href="/register" className="btn">Daftar Akun</Link><Link href="/login" className="btn ghost">Masuk Portal</Link></div></div>
  </PublicLayout>);
}
