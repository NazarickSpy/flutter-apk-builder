import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { User, ShieldCheck, LogOut, UserCog, Lock, Check, BadgeCheck, Copy, Calendar, MonitorSmartphone, History, Mail, Fingerprint, CirclePlus } from 'lucide-react';
import Link from 'next/link';
import { toast } from '../components/Toast';
import { useOnline } from '../components/hooks';
import PageSkeleton from '../components/Skeleton';
import { api, fdate } from '../components/api';
import Confirm from '../components/Confirm';
import AppShell from '../components/AppShell';
import TwoFactor from '../components/TwoFactor';
import SecScore from '../components/SecScore';
export default function Profile() {
  const r = useRouter(); const [me, setMe] = useState(null); const [ev, setEv] = useState(null); const [cfAll, setCfAll] = useState(false); const [busy, setBusy] = useState(false); const on = useOnline(); const [tab, setTab] = useState('info'); const [wa, setWa] = useState(''); const [o, setO] = useState(''); const [n, setN] = useState(''); const [m, setM] = useState(null); const [cp, setCp] = useState(false);
  useEffect(() => { api('/me').then((x) => { setMe(x); setWa(x.whatsapp); }).catch(() => r.push('/login')); }, [r]);
  useEffect(() => { const q = new URLSearchParams(window.location.search).get('tab'); if (q === 'sec' || q === 'act') setTab(q); }, []);
  useEffect(() => { if (tab === 'act') api('/events').then(setEv).catch(() => setEv([])); }, [tab]);
  const outAll = async () => { setBusy(true); try { await api('/logout-all', 'POST'); } catch {} r.push('/login'); };
  const EV = { login: ['Login berhasil', 'ok'], login_fail: ['Percobaan login gagal', 'bad'], password: ['Password diganti', 'ok'], panel_reset: ['Password panel direset', 'ok'], logout_all: ['Keluar dari semua perangkat', 'ok'], '2fa_on': ['Verifikasi 2 langkah aktif', 'ok'], '2fa_off': ['Verifikasi 2 langkah dimatikan', 'warn'] };
  const run = (fn, ok) => async () => { try { await fn(); toast(ok, 'ok'); setM(null); } catch (e) { setM({ t: e.message, s: 'e' }); } };
  if (!me) return <PageSkeleton cards={2} />;
  const date = new Date(me.created_at).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
  const copy = async () => { try { await navigator.clipboard.writeText(me.uid); setCp(true); toast('UID disalin', 'ok'); setTimeout(() => setCp(false), 1500); } catch {} };
  return (<AppShell me={me} active="profile">
    <div className="card prof"><span className="avr xl"><span className="av">{me.username[0].toUpperCase()}</span><span className={'st' + (on ? '' : ' off')} title={on ? 'Online' : 'Offline'} /></span>
      <h2>{me.username}<BadgeCheck size={22} className="pri" /></h2>
      <div className="pchips"><span className="pchip pr">{me.role.toUpperCase()}</span><span className="pchip ok">Akun Aktif</span><span className="pchip"><Mail size={14} />{me.email}</span><span className="pchip mono"><Fingerprint size={14} />{me.uid}<button onClick={copy} aria-label="Salin UID">{cp ? <Check size={14} /> : <Copy size={14} />}</button></span></div>
      <div className="welc"><Calendar size={14} />Bergabung {date}</div>
      <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap', marginTop: 16 }}><button className="btn ghost" onClick={copy}><Copy size={16} />Salin ID</button><Link href="/dashboard#paket" className="btn"><CirclePlus size={16} />Beli Panel</Link><button className="btn ghost dangertxt" onClick={() => window.dispatchEvent(new Event('snowy:logout'))}><LogOut size={16} />Keluar</button></div></div>
    <div className="tabs"><button className={tab === 'info' ? 'on' : ''} onClick={() => { setTab('info'); setM(null); }}><User size={20} />Informasi Profil</button><button className={tab === 'sec' ? 'on' : ''} onClick={() => { setTab('sec'); setM(null); }}><ShieldCheck size={20} />Keamanan</button><button className={tab === 'act' ? 'on' : ''} onClick={() => { setTab('act'); setM(null); }}><History size={20} />Aktivitas</button></div>
    {tab === 'info' ? <>
      <div className="card"><div className="ch"><span className="ico"><UserCog size={22} /></span><b>Informasi Akun</b></div>
        <label>Username Akun</label><input value={me.username} readOnly />
        <label>Nomor WhatsApp</label><input value={wa} onChange={(e) => setWa(e.target.value)} />
        <label className="lk">Email Terdaftar<span><Lock size={14} /> Permanen</span></label><input className="mono lock" value={me.email} readOnly />
        {m && <div className={'msg ' + m.s}>{m.t}</div>}
        <div style={{ textAlign: 'right' }}><button className="btn" style={{ marginTop: 18 }} onClick={run(async () => { await api('/profile', 'POST', { whatsapp: wa }); }, 'Profil disimpan')}><Check size={20} />Simpan Perubahan</button></div></div>
      <div className="card"><div className="ch"><span className="ico"><BadgeCheck size={22} /></span><b style={{ flex: 1 }}>Detail Keanggotaan</b><span className="okb">Akun Aktif</span></div>
        <div className="ib2"><div><small className="cap">ID PENGGUNA (UID)</small><div className="mono val">{me.uid}</div></div><button className="sqbtn sm" onClick={copy} aria-label="Salin UID">{cp ? <Check size={20} /> : <Copy size={20} />}</button></div>
        <div className="ib2"><div><small className="cap">LEVEL PENGGUNA</small><div className="val pri">{me.role.toUpperCase()}</div></div><span className="tier">{me.role === 'admin' ? 'Administrator' : 'Tier Standar'}</span></div>
        <div className="ib2"><div><small className="cap">TANGGAL TERDAFTAR</small><div className="val">{date}</div></div><Calendar size={22} className="mut" /></div></div>
    </> : tab === 'act' ? <>
      <div className="card"><div className="ch"><span className="ico"><History size={22} /></span><b>Aktivitas Login</b></div>
        {!ev && <div style={{ display: 'grid', gap: 10 }}><div className="sk l2" /><div className="sk l2" /></div>}{ev && ev.length === 0 && <p className="mut" style={{ margin: 0 }}>Belum ada aktivitas tercatat.</p>}
        {ev && ev.map((e) => { const x = EV[e.type] || [e.type, 'ok']; return <div className="ord" key={e.id}><div style={{ minWidth: 0 }}><b>{x[0]}</b> {e.current && <span className="pchip pr" style={{ padding: '.1rem .5rem' }}>Perangkat ini</span>} {e.new_device && <span className="pchip" style={{ padding: '.1rem .5rem', color: 'var(--warn-text)' }}>Perangkat baru</span>}<small className="mut">{e.browser} - {e.os} - IP {e.ip}</small><small className="mut">{fdate(e.created_at)}</small></div><span className={'stt ' + (x[1] === 'bad' ? 'failed' : 'active')}>{x[1] === 'bad' ? 'Waspada' : 'OK'}</span></div>; })}
        <small className="mut" style={{ display: 'block', marginTop: 12 }}>Melihat aktivitas yang bukan dari Anda? Ganti password lalu keluar dari semua perangkat.</small></div>
    </> : <>
      <SecScore me={me} />
      <div className="card"><div className="ch"><span className="ico"><ShieldCheck size={22} /></span><b>Ganti Password</b></div>
      <label>Password lama</label><input type="password" autoComplete="current-password" value={o} onChange={(e) => setO(e.target.value)} /><label>Password baru (min 8, jangan memuat username)</label><input type="password" autoComplete="new-password" value={n} onChange={(e) => setN(e.target.value)} />
      {m && <div className={'msg ' + m.s}>{m.t}</div>}<div style={{ textAlign: 'right' }}><button className="btn" style={{ marginTop: 18 }} onClick={run(async () => { await api('/password', 'POST', { old: o, next: n }); setO(''); setN(''); }, 'Password diganti')}><Check size={20} />Simpan Perubahan</button></div></div>
      <TwoFactor />
      <div className="card"><div className="ch"><span className="ico"><MonitorSmartphone size={22} /></span><b>Sesi Perangkat</b></div>
        <p className="mut" style={{ marginTop: 0 }}>Akun Anda dipakai di perangkat lain atau merasa tidak aman? Keluar dari semua perangkat sekaligus, termasuk perangkat ini.</p>
        <button className="btn ghost full dangertxt" onClick={() => setCfAll(true)}><LogOut size={18} />Keluar dari semua perangkat</button></div>
</>}
    {cfAll && <Confirm title="Keluar dari Semua Perangkat?" text="Semua sesi login akun Anda di semua perangkat akan diakhiri dan Anda perlu login ulang." yes="Ya, Keluar Semua" busy={busy} onNo={() => setCfAll(false)} onYes={outAll} />}
  </AppShell>);
}
