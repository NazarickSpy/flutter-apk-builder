import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { ShieldCheck, Clock, RotateCcw, Search, TriangleAlert, LoaderCircle, CircleCheck, LifeBuoy } from 'lucide-react';
import { api, fday, fdate, CLAIM } from '../components/api';
import PublicLayout from '../components/PublicLayout';
const CAT = { server_down: 'Server mati / tidak bisa online', panel_error: 'Error di panel / server tidak bisa dijalankan', lainnya: 'Kendala operasional lainnya' };

export default function Garansi() {
  const r = useRouter(); const [f, setF] = useState({ trx: '', wa: '' }), [d, setD] = useState(null), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  const [c, setC] = useState({ category: 'server_down', reason: '' }), [cerr, setCerr] = useState(''), [cbusy, setCbusy] = useState(false), [sent, setSent] = useState(false);
  useEffect(() => { if (r.isReady && r.query.trx) setF((x) => ({ ...x, trx: String(r.query.trx).toUpperCase().replace(/[^A-Z0-9]/g, '') })); }, [r.isReady, r.query.trx]);
  useEffect(() => { api('/me').then((m) => setF((x) => (x.wa ? x : { ...x, wa: m.whatsapp || '' }))).catch(() => {}); }, []); // jika sedang login, WA terisi otomatis

  const check = async (e) => { e && e.preventDefault(); setBusy(true); setErr(''); setSent(false); try { setD(await api('/garansi/check', 'POST', f)); } catch (x) { setD(null); setErr(x.message); } setBusy(false); };
  const claim = async (e) => { e.preventDefault(); setCbusy(true); setCerr(''); try { const x = await api('/garansi/claim', 'POST', { ...f, ...c }); setD(x); setSent(true); setC({ category: 'server_down', reason: '' }); } catch (x2) { setCerr(x2.message); } setCbusy(false); };
  const w = d?.warranty, open = d?.claim && ['pending', 'processing'].includes(d.claim.status);
  return (<PublicLayout title="Portal Garansi" sub="Portal Garansi" desc="Verifikasi pesanan dan ajukan klaim garansi server SnowyStore.">
    <section className="pubhead"><span className="pubico ico3"><ShieldCheck size={30} /></span><h1>Portal Garansi</h1><p className="mut">Periksa status pesanan dan masa garansi dengan TRX ID dan nomor WhatsApp pendaftar. Server panel baru dari paket Averpay berstatus non-garansi; klaim penggantian hanya berlaku untuk pesanan panel lama.</p></section>
    <div className="pillrow"><div className="card mini"><Clock size={22} className="pri" /><b>30 Hari</b><small className="mut">Sejak server aktif</small></div><div className="card mini"><RotateCcw size={22} className="pri" /><b>1x per Order</b><small className="mut">Klaim resmi</small></div><div className="card mini"><ShieldCheck size={22} className="pri" /><b>Server Baru</b><small className="mut">Paket sama</small></div></div>

    <form className="card" onSubmit={check}><h3>Verifikasi Pesanan</h3>
      <label>TRX ID Pesanan</label><input className="mono" placeholder="SNWXXXXXXXXXXXX" value={f.trx} autoCapitalize="characters" autoCorrect="off" onChange={(e) => setF({ ...f, trx: e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '') })} required />
      <small className="mut">TRX ID ada di kartu pesanan (Dashboard &rarr; Server Saya / Riwayat).</small>
      <label>Nomor WhatsApp Terdaftar</label><input inputMode="tel" placeholder="081234567890" value={f.wa} onChange={(e) => setF({ ...f, wa: e.target.value })} required />
      {err && <div className="msg e">{err}</div>}
      <button className="btn full" disabled={busy || f.trx.length < 8 || f.wa.length < 8}>{busy ? <><LoaderCircle size={18} className="spin" />Memeriksa…</> : <><Search size={18} />Periksa Status Garansi</>}</button></form>

    {d && <div className="card"><h3>Hasil Verifikasi</h3>
      <div className="kv"><span>TRX ID</span><b className="mono">{d.trx}</b></div>
      <div className="kv"><span>Paket Server</span><b>{d.pkg_name || d.package_key.toUpperCase()} - {d.server_name}</b></div>{d.panel_user ? <div className="kv"><span>Username Panel</span><b className="mono">{d.panel_user}</b></div> : null}{d.panel_expires_at ? <div className="kv"><span>Masa Aktif Panel</span><b>{fday(d.panel_expires_at)}</b></div> : null}
      {d.server_id ? <div className="kv"><span>ID Server Saat Ini</span><b className="mono">#{d.server_id}</b></div> : null}
      <div className="kv"><span>Tanggal Order</span><b>{fday(d.ordered_at)}</b></div>
      <div className="kv"><span>Sisa Masa Garansi</span><b>{d.panel_user && !d.server_id ? 'Non-garansi' : w.days_left > 0 ? `${w.days_left} hari (s/d ${fday(w.expires_at)})` : 'Habis'}</b></div>
      {d.warranty.bonus > 0 && <div className="kv"><span>Waktu Tambahan (kompensasi)</span><b>+{d.warranty.bonus} hari</b></div>}
      <div className="kv"><span>Kuota Klaim</span><b>{w.used} / {w.max} terpakai</b></div>
      <div className="kv"><span>Status Klaim</span><b>{d.claim ? <span className={'stt cl-' + d.claim.status}>{CLAIM[d.claim.status]}</span> : 'Belum ada klaim'}</b></div>
      {d.claim?.admin_note && <div className="msg">{d.claim.admin_note}</div>}
      {d.claim?.status === 'done' && d.claim.new_server_id && <div className="msg s"><CircleCheck size={18} className="vm" /> Server baru sudah dibuat dengan ID <b>#{d.claim.new_server_id}</b>. Cek di panel dengan akun panel yang sama.</div>}
      {sent && <div className="msg s">Klaim terkirim. Tim kami memprosesnya secepatnya - cek kembali halaman ini untuk melihat statusnya.</div>}
      {!w.eligible && !open && <div className="msg e"><TriangleAlert size={18} className="vm" /> {w.reason}.</div>}
      {open && <div className="msg"><Clock size={18} className="vm" /> Klaim Anda sedang diproses. Mohon tunggu, jangan kirim klaim lagi.</div>}
      {d.claim && <button className="btn ghost full" onClick={check}>Muat ulang status</button>}</div>}

    {d && w.eligible && <form className="card" onSubmit={claim}><h3>Ajukan Klaim Garansi</h3>
      <label>Jenis kendala</label><div className="cs-field"><LifeBuoy size={18} /><CustomSelect ariaLabel="Jenis kendala" value={c.category} onChange={(v) => setC({ ...c, category: v })} options={Object.entries(CAT).map(([k, v]) => ({ value: k, label: v }))} /></div>
      <label>Jelaskan kendala</label><textarea rows={4} maxLength={300} placeholder="Contoh: server tidak bisa online sejak kemarin, console error..." value={c.reason} onChange={(e) => setC({ ...c, reason: e.target.value })} required />
      <small className="mut">{c.reason.length}/300</small>
      <div className="msg warnm"><TriangleAlert size={18} className="vm" /> Klaim disetujui = dibuatkan <b>server baru (ID baru)</b> dan server lama dihapus. Data di server lama <b>tidak ikut pindah</b> - backup dulu file pentingmu.</div>
      {cerr && <div className="msg e">{cerr}</div>}
      <button className="btn full" disabled={cbusy || c.reason.trim().length < 10}>{cbusy ? 'Mengirim…' : 'Kirim Klaim'}</button></form>}

    <div className="card"><h3>Ketentuan Penting Garansi</h3><ul className="list"><li>Server panel dari paket Averpay berstatus <b>non-garansi</b> dan dihapus otomatis saat masa aktif paket berakhir.</li><li>Garansi {w?.days || 30} hari (1x klaim per pesanan) hanya berlaku untuk pesanan panel lama, dan mencakup kendala operasional server, bukan kesalahan penggunaan.</li><li>Tidak berlaku untuk server yang melanggar aturan (penyalahgunaan jaringan, phishing, dll.) atau dihapus manual oleh pengguna.</li><li>Pesanan sudah dibayar tapi panel belum aktif? Tidak perlu klaim: sistem memproses ulang otomatis bila gagal sebelum diproses, atau <Link href="/bantuan" className="lnk">hubungi bantuan</Link> dengan TRX ID Anda.</li></ul>
      <small className="mut">Butuh masuk ke dashboard? <Link href="/login" className="lnk">Masuk ke akun Anda</Link></small></div>
  </PublicLayout>);
}
