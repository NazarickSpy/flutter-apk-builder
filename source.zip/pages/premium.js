import { useEffect, useState, useCallback } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { Search, Gem, RefreshCw, LoaderCircle, Minus, Plus, Trash2, ChevronRight, TriangleAlert, Ban, Info } from 'lucide-react';
import { api, rp, fdate, PRM, PRMHINT, prmClass } from '../components/api';
import AppShell from '../components/AppShell';
import PageSkeleton from '../components/Skeleton';
import Modal from '../components/Modal';
import Confirm from '../components/Confirm';
import PremiumDetail from '../components/PremiumDetail';

function Img({ src, size = 56 }) {
  const [bad, setBad] = useState(false);
  return src && !bad ? <img className="pimg" src={src} alt="" width={size} height={size} loading="lazy" decoding="async" onError={() => setBad(true)} /> : <span className="pimg ph"><Gem size={size / 2.4} /></span>;
}
export default function Premium() {
  const r = useRouter();
  const [me, setMe] = useState(null), [items, setItems] = useState(null), [meta, setMeta] = useState({ stale: false, max: 5 }), [orders, setOrders] = useState([]), [perr, setPerr] = useState(''), [off, setOff] = useState('');
  const [q, setQ] = useState(''), [sel, setSel] = useState(null), [qty, setQty] = useState(1), [email, setEmail] = useState(''), [agree, setAgree] = useState(false), [busy, setBusy] = useState(false), [err, setErr] = useState(''), [detail, setDetail] = useState(null), [cf, setCf] = useState(null), [note, setNote] = useState('');
  const load = useCallback(async () => {
    const [m, p, o, c] = await Promise.allSettled([api('/me'), api('/premium/products'), api('/premium/orders'), api('/config')]);
    if (m.status === 'rejected') { if (m.reason.status === 401) r.push('/login'); else setPerr(m.reason.message); return; }
    setMe(m.value);
    if (p.status === 'fulfilled') { setItems(p.value.items); setMeta({ stale: p.value.stale, max: p.value.max_qty || 5 }); setPerr(''); } else { setItems((x) => x || []); setPerr(p.reason.message); }
    if (o.status === 'fulfilled') setOrders(o.value);
    if (c.status === 'fulfilled') { const s = (c.value.services || {}).premium; setOff(c.value.maintenance ? c.value.maintenance_msg || 'Sedang pemeliharaan. Pembelian dibuka kembali sebentar lagi.' : s && s.on === false ? s.msg || 'Pembelian aplikasi premium sedang dinonaktifkan sementara.' : ''); }
  }, [r]);
  useEffect(() => { load(); }, [load]);
  const open = (p) => { setSel(p); setQty(1); setEmail(''); setAgree(false); setErr(''); };
  const maxQ = sel ? Math.max(1, Math.min(meta.max, sel.stock == null ? meta.max : sel.stock)) : 1, total = sel ? sel.price * qty : 0;
  const buy = async () => {
    setBusy(true); setErr('');
    try { const o = await api('/premium/orders', 'POST', { product_id: sel.id, qty, price: sel.price, ...(sel.needs_input ? { email } : {}) }, { timeout: 40000 }); setSel(null); setDetail({ id: o.id, initial: o }); load(); }
    catch (e) { setErr(e.message); if (e.status === 409 || e.status === 404) load(); }
    setBusy(false);
  };
  const clearAll = async () => { setBusy(true); try { const x = await api('/premium/orders/clear', 'POST'); setNote(`${x.removed} riwayat dihapus (data tetap tersimpan).`); } catch (e) { setNote(e.message); } setBusy(false); setCf(null); load(); };
  const del = async () => { setBusy(true); try { await api(`/premium/orders/${cf.id}`, 'DELETE'); setNote('Dihapus dari riwayat (data tetap tersimpan).'); } catch (e) { setNote(e.message); } setBusy(false); setCf(null); load(); };
  if (!me) return perr ? (<div className="wrap"><div className="card center"><><p className="msg e" style={{ marginTop: 0 }}>{perr}</p><button className="btn" onClick={() => { setPerr(''); load(); }}><RefreshCw size={16} />Coba lagi</button></></div></div>) : <PageSkeleton cards={3} />;
  const list = (items || []).filter((p) => p.name.toLowerCase().includes(q.trim().toLowerCase()));
  const canBuy = !off || me.role === 'admin';
  return (<AppShell me={me} active="premium" head={{ title: 'Aplikasi Premium', sub: 'Pilih produk, bayar dengan QRIS, dan data akun tampil otomatis.', icon: Gem, actions: <button className="btn ghost sm" onClick={load}><RefreshCw size={15} />Muat ulang</button> }}><Head><title>Aplikasi Premium - SnowyStore</title></Head>
    <div className="card">
      <div className="fld"><Search size={18} className="fi" /><input placeholder="Cari aplikasi…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      {off && <div className="msg warnm"><TriangleAlert size={16} className="vm" /> {off}</div>}
      {meta.stale && <div className="msg warnm">Katalog sementara memakai data terakhir. Harga dan stok dicek ulang saat memesan.</div>}
      {perr && <div className="msg e">{perr} <button className="linkbtn" onClick={load}>Coba lagi</button></div>}
      {!items && <p className="mut loading"><LoaderCircle size={18} className="spin" /> Memuat katalog…</p>}
      {items && list.length === 0 && !perr && <p className="mut" style={{ margin: '12px 0 0' }}>{q ? 'Tidak ada hasil.' : 'Belum ada produk tersedia.'}</p>}
      <div className="pgrid2">{list.map((p) => <button key={p.id} className="pcard" disabled={p.stock === 0 || !canBuy} onClick={() => open(p)}><Img src={p.image} /><div className="pinfo"><b>{p.name}</b><small className={p.stock === 0 ? 'badt' : 'mut'}>{p.stock === 0 ? 'Stok habis' : p.stock != null ? `Stok ${p.stock}` : p.category || 'Tersedia'}</small><div className="pr">{rp(p.price)}</div></div></button>)}</div></div>
    <div className="card"><div className="ch"><Gem size={20} className="pri" /><b>Pesanan Premium Saya</b></div>
      {note && <div className="msg s" style={{ marginTop: 0, marginBottom: 10 }}>{note}</div>}
      {orders.length === 0 && <div className="empty"><b>Belum ada pesanan premium</b><small className="mut">Pilih aplikasi di daftar atas, baca deskripsinya, lalu bayar dengan QRIS. Data akun tampil di sini setelah pembayaran terverifikasi.</small></div>}
      {orders.some((o) => ['done', 'refunded', 'expired', 'cancelled'].includes(o.status)) && <div style={{ marginBottom: 10 }}><button className="chip danger" onClick={() => setCf({ all: true })}><Trash2 size={14} />Hapus semua riwayat selesai</button></div>}
      {orders.map((o) => <div className="ord2" key={o.id}><div className="ordtop"><div className="ordn"><b>{o.product_name}{o.qty > 1 ? ` ×${o.qty}` : ''}</b><small className="mut">{rp(o.total || o.price)} - {fdate(o.created_at)}</small></div><span className={'stt ' + prmClass(o.status)}>{PRM[o.status]}</span></div>
        {PRMHINT[o.status] && <small className="hint"><Info size={14} />{PRMHINT[o.status]}</small>}
        <div className="ordact"><button className="chip pri" onClick={() => setDetail({ id: o.id })}>{o.status === 'awaiting_payment' ? 'Bayar' : 'Detail'}<ChevronRight size={13} /></button>{['done', 'refunded', 'expired', 'cancelled'].includes(o.status) && <button className="chip danger" onClick={() => setCf(o)}><Trash2 size={14} />Hapus</button>}</div></div>)}</div>
    {sel && <Modal onClose={() => !busy && setSel(null)} label="Beli" locked={busy}>
      <div className="center"><Img src={sel.image} size={72} /></div><h3 className="center" style={{ marginTop: 8 }}>{sel.name}</h3>
      {sel.desc && <div className="pdesc">{sel.desc}</div>}
      <div className="two2" style={{ alignItems: 'center', marginTop: 10 }}><span>Jumlah</span><div className="stepper"><button className="sqbtn sm" disabled={qty <= 1 || busy} onClick={() => setQty(qty - 1)} aria-label="Kurangi"><Minus size={16} /></button><b>{qty}</b><button className="sqbtn sm" disabled={qty >= maxQ || busy} onClick={() => setQty(qty + 1)} aria-label="Tambah"><Plus size={16} /></button></div></div>
      {sel.needs_input && <><label>Email tujuan</label><input type="email" inputMode="email" autoCapitalize="none" placeholder="nama@email.com" value={email} onChange={(e) => setEmail(e.target.value)} /></>}
      <div className="kv"><span>Harga satuan</span><b>{rp(sel.price)}</b></div><div className="kv"><span>Total</span><b>{rp(total)}</b></div>
      <label className="chk"><input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} /> Saya sudah membaca deskripsi dan ketentuan produk di atas.</label>
      {err && <div className="msg e">{err}</div>}
      <div className="two"><button className="btn ghost" disabled={busy} onClick={() => setSel(null)}>Batal</button><button className="btn" disabled={busy || !agree || !canBuy || (sel.needs_input && !email.includes('@'))} onClick={buy}>{busy ? 'Membuat QRIS…' : `Bayar ${rp(total)}`}</button></div>
      <small className="mut" style={{ display: 'block', marginTop: 10, textAlign: 'center' }}>Dibayar lewat QRIS (biaya layanan ditambahkan di tagihan). Data akun tersimpan di akun Anda setelah pembayaran terverifikasi.</small></Modal>}
    {detail && <PremiumDetail id={detail.id} initial={detail.initial} onClose={() => { setDetail(null); load(); }} onChange={load} />}
    {cf && <Confirm title={cf.all ? 'Hapus Semua Riwayat Selesai?' : 'Hapus dari Riwayat?'} text={cf.all ? 'Semua pesanan berstatus selesai, dikembalikan, kedaluwarsa, atau dibatalkan disembunyikan dari daftar. Pesanan yang masih berjalan tidak ikut. Pastikan data akun sudah Anda salin.' : 'Pesanan hanya disembunyikan dari daftar. Datanya tetap tersimpan, tapi pastikan Anda sudah menyalin data akun yang diperlukan.'} yes="Ya, Hapus" busy={busy} onNo={() => setCf(null)} onYes={cf.all ? clearAll : del} />}</AppShell>);
}
