import Link from 'next/link';
import { useEffect, useState } from 'react';
import { ChevronDown, ChevronRight, MessageCircle, Cpu, Server, ShieldCheck, Zap, Terminal, Lock, Shield, Send, RotateCcw, ReceiptText, Gem, Smartphone, ArrowUpRight, CircleCheck, LifeBuoy, Activity, Rocket, Users, ReceiptText as Receipt } from 'lucide-react';
import { api, rp, compact } from '../components/api';
import Brand from '../components/Brand';
import PublicNav from '../components/PublicNav';
import { LivePanel, SystemInfo, useLive } from '../components/Live';
import { useReveal } from '../components/hooks';
import JsonLd from '../components/JsonLd';
import FooterContact from '../components/FooterContact';
import { faqSchema, productSchema } from '../components/site';
import { fetchPackages } from '../components/catalog';
import { ARTICLES } from '../content/panduan';
const FAQ = [
  ['Apa saja yang dijual di SnowyStore?', 'Tiga layanan digital: aplikasi premium, nomor virtual untuk menerima OTP (Nokos), dan hosting server panel Pterodactyl (RAM 1 GB sampai 10 GB). Semuanya dibeli dari satu akun, dibayar dengan QRIS, dan diproses otomatis.'],
  ['Bagaimana cara membeli server panel?', 'Daftar akun, pilih paket, isi username panel, lalu bayar dengan QRIS. Setelah pembayaran terverifikasi, server dibuat otomatis dan data login panel tampil di dashboard.'],
  ['Bagaimana cara membeli nomor virtual (OTP)?', 'Buka menu Nomor Virtual, pilih server, aplikasi, negara, lalu harga, dan bayar dengan QRIS. Setelah pembayaran terverifikasi, nomor tampil otomatis dan kode OTP muncul di halaman pesanan. Jika OTP tidak masuk sampai waktu habis, dana dikembalikan oleh admin.'],
  ['Bagaimana cara membeli aplikasi premium?', 'Buka menu Aplikasi Premium, pilih produk, baca deskripsinya, lalu bayar dengan QRIS. Setelah pembayaran terverifikasi, pesanan diproses otomatis dan data akun tampil di halaman pesanan serta tersimpan di akun Anda.'],
  ['Metode pembayaran apa yang tersedia?', 'QRIS, yang dapat dibayar melalui e-wallet atau m-banking apa pun. Total tagihan sudah termasuk biaya layanan dan berlaku sampai batas waktu yang ditampilkan di halaman pembayaran.'],
  ['Berapa harga paket server panel?', 'Harga mengikuti paket yang tersedia (RAM 1 GB sampai 10 GB) dan tertera pada tiap paket sebelum pembayaran. Harga aplikasi premium ditampilkan di menu Aplikasi Premium setelah Anda masuk.'],
  ['Bagaimana jika sudah membayar tetapi pesanan belum selesai?', 'Sistem memeriksa pembayaran dan memproses pesanan secara otomatis, termasuk mengulang pembuatan server bila diperlukan. Jika pesanan premium gagal diproses oleh penyedia, status berubah menjadi Menunggu pengembalian dana dan dana dikembalikan penuh oleh admin. Hubungi bantuan dengan kode pesanan Anda.'],
  ['Apakah server panel bergaransi?', 'Server panel berstatus non-garansi dan memiliki masa aktif sesuai paket; server dihapus otomatis saat masa aktif berakhir. Pesanan yang sudah dibayar tetapi gagal dibuat ditangani dan dananya dikembalikan. Garansi aplikasi premium mengikuti deskripsi masing-masing produk.'],
  ['Bagaimana keamanan data dan pembayaran saya?', 'Kata sandi disimpan dalam bentuk hash, data akses panel dienkripsi, dan status pembayaran diperiksa langsung ke penyedia pembayaran. Login dibatasi jumlah percobaannya dan akun dikunci bila terdeteksi aktivitas mencurigakan.']];
const WHY = [[Zap, 'Aktivasi Otomatis', 'Pesanan diproses otomatis setelah pembayaran terverifikasi, tanpa menunggu konfirmasi manual.'],
  [Lock, 'Pembayaran per Pesanan', 'Bayar langsung dengan QRIS untuk setiap pesanan, tanpa top up saldo dan tanpa langganan.'],
  [Send, 'Pembayaran Terverifikasi', 'Status pembayaran dicek langsung ke penyedia pembayaran sebelum pesanan diproses.'],
  [Shield, 'Data Terlindungi', 'Kata sandi di-hash, data akses dienkripsi, dan login dibatasi untuk mencegah penyalahgunaan akun.'],
  [RotateCcw, 'Garansi & Pengembalian Dana', 'Pesanan yang sudah dibayar tetapi gagal diproses ditangani dan dananya dikembalikan. Masa aktif hosting tampil jelas di akun Anda.'],
  [ReceiptText, 'Riwayat Pesanan', 'Semua pesanan, status server, dan data akun tersimpan di dashboard dan dapat dilihat kapan saja.']];
// Paket & harga dirender di SERVER (ISR, segar tiap 5 menit) agar terbaca Google/AI tanpa menjalankan JavaScript; klien tetap memperbarui lewat API.
export async function getStaticProps() { const packages = await fetchPackages(); return { props: { packages }, revalidate: packages.length ? 300 : 20 }; }
export default function Home({ packages = [] }) {
  const [list, setList] = useState(packages); const [open, setOpen] = useState(-1), [ct, setCt] = useState(null), { d: live, err: liveErr } = useLive(10000);
  useEffect(() => { api('/packages').then((x) => { if (Array.isArray(x) && x.length) setList(x); }).catch(() => {}); api('/config').then((c) => setCt(c.contact)).catch(() => {}); }, []);
  useReveal(list.length); const prices = list.map((x) => Number(x.price)).filter((n) => n > 0), minp = prices.length ? Math.min(...prices) : 0;
  const stat = (v) => (v == null ? '-' : compact(v));
  return (<div>
    <PublicNav home />
    <main id="konten">
    <section className="yhero"><div className="yh"><h1>Toko Digital untuk <em>Aplikasi Premium</em>, Nomor OTP &amp; Hosting</h1>
      <p className="ys">Beli akun aplikasi premium, nomor virtual penerima OTP, dan hosting server panel dalam satu akun. Bayar dengan QRIS, pesanan diproses otomatis, dan semua riwayat tersimpan rapi di dashboard Anda.</p>
      <div className="ybtn"><Link href="/register" className="yp"><Rocket size={18} />Mulai Belanja</Link><Link href="/login" className="yo">Masuk ke Akun <ArrowUpRight size={18} /></Link></div>
      <div className="ychips"><span><Gem size={20} className="pri" />Premium</span><span><Smartphone size={20} className="pri" />OTP</span><span><Server size={20} className="pri" />Hosting</span><span><ShieldCheck size={20} className="pri" />Garansi</span><span><Zap size={20} className="pri" />QRIS</span></div>
      <div className="ymock" aria-hidden="true"><div className="ymh"><ShieldCheck size={16} className="pri" />Dashboard SnowyStore<span className="dots"><i /><i /><i /></span></div><div className="ymt"><span className="on">Dashboard</span><span>Premium</span><span>Nomor OTP</span><span>Hosting</span><span>Pesanan</span><span>Garansi</span></div>
        <div className="ymb"><div className="ymr"><Gem size={16} /><b>Netflix Premium 1 Bulan</b><span className="stt active">Selesai</span></div><div className="ymr"><Smartphone size={16} /><b>OTP WhatsApp</b><span className="stt processing">Menunggu OTP</span></div><div className="ymr"><Server size={16} /><b>Hosting Panel 4 GB</b><span className="stt active">Aktif</span></div></div></div></div></section>
    <section className="tstrip" aria-label="Ringkasan"><div className="ts"><b>{stat(live && live.orders_total)}</b><small>Pesanan diproses</small></div><div className="ts"><b>{stat(live && live.members)}</b><small>Member terdaftar</small></div><div className="ts"><b>24/7</b><small>Pemrosesan otomatis</small></div><div className="ts"><b>QRIS</b><small>Semua e-wallet &amp; m-banking</small></div></section>
    <section className="sec" id="layanan"><h2 className="h2">Layanan Kami</h2><p className="mut center sub">Tiga layanan digital dalam satu akun, dengan pembayaran dan riwayat yang sama.</p>
      <div className="svc3">{[[Gem, 'ico2', 'Aplikasi Premium', 'Akun aplikasi premium pilihan dengan harga jelas dan stok yang diperbarui.', ['Katalog bergambar dengan stok terkini', 'Data akun tampil otomatis setelah bayar', 'Dana dikembalikan bila pesanan gagal'], 'Lihat Produk', '/register'],
        [Smartphone, 'ico3', 'Nomor Virtual (OTP)', 'Nomor sementara untuk menerima kode verifikasi dari berbagai aplikasi.', ['Pilih server, aplikasi, negara, dan harga', 'Kode OTP muncul otomatis di halaman pesanan', 'Dana dikembalikan bila OTP tidak masuk'], 'Lihat Layanan', '/register'],
        [Server, 'ico1', 'Hosting Server Panel', 'Server panel Pterodactyl untuk bot, game server, dan aplikasi Anda.', ['RAM 1 GB sampai 10 GB, mulai ' + (minp ? rp(minp) : 'harga terjangkau'), 'Server dibuat otomatis setelah pembayaran', 'Masa aktif jelas dan akses login lengkap'], 'Lihat Paket', '#paket']]
        .map(([I, c, t, d, bl, cta, h]) => <div className={'card svc3c hov ' + c} key={t} data-rv><span className="svico"><I size={26} strokeWidth={1.8} /></span><h3>{t}</h3><p className="mut">{d}</p><ul className="blist">{bl.map((x) => <li key={x}><CircleCheck size={16} />{x}</li>)}</ul>{h[0] === '#' ? <a href={h} className="go">{cta} <ChevronRight size={18} /></a> : <Link href={h} className="go">{cta} <ChevronRight size={18} /></Link>}</div>)}</div>
      <div className="qlinks">{[[ShieldCheck, 'ico4', 'Portal Garansi', 'Cek status & klaim garansi', '/garansi'], [Activity, 'ico7', 'Status Sistem', 'Aktivitas server langsung', '/status'], [LifeBuoy, 'ico5', 'Pusat Bantuan', 'FAQ & panduan order', '/bantuan']].map(([I, c, t, d, h]) => <Link href={h} className={'ql ' + c} key={t} data-rv><i><I size={20} /></i><div><b>{t}</b><small className="mut">{d}</small></div><ChevronRight size={18} /></Link>)}</div></section>
    <section className="sec alt" id="cara"><h2 className="h2">Cara Belanja</h2><p className="mut center sub">Empat langkah dari daftar sampai pesanan siap dipakai.</p>
      <div className="fgrid steps">{[['1', 'Buat Akun', 'Daftar dengan username, email, dan nomor WhatsApp aktif. Pendaftaran gratis.'], ['2', 'Pilih Layanan', 'Pilih aplikasi premium, nomor virtual, atau paket hosting. Harga tampil sebelum pembayaran.'], ['3', 'Bayar dengan QRIS', 'Scan lewat e-wallet atau m-banking apa pun. Nominal sudah termasuk biaya layanan.'], ['4', 'Pesanan Diproses', 'Setelah pembayaran terverifikasi, pesanan selesai otomatis dan datanya tersimpan di dashboard.']].map(([n, t, d], i) => <div className={'card feat hov ico' + (i + 1)} key={n} data-rv><div className="ft"><span className="stepn">{n}</span><h3>{t}</h3></div><p className="mut">{d}</p></div>)}</div></section>
    <section className="sec" id="live"><h2 className="h2">Aktivitas &amp; Kondisi Sistem</h2><p className="mut center sub">Transparan: jumlah pesanan 24 jam terakhir dan kondisi server kami, diperbarui langsung.</p>
      <div style={{ maxWidth: 760, margin: '0 auto' }} data-rv><LivePanel d={live} err={liveErr} /></div>
      <h3 className="h3c">Informasi Sistem</h3><div style={{ maxWidth: 760, margin: '0 auto' }} data-rv><SystemInfo d={live} /></div></section>
    <section className="sec alt" id="paket"><h2 className="h2">Paket Hosting Server Panel</h2><p className="mut center sub">Pilih ukuran sesuai kebutuhan, dari 1 GB sampai 10 GB RAM. Harga tertera pada tiap paket.</p>
      <div className="grid pkgrid">{list.map((p) => <Link href="/register" key={p.key} className="pkg" style={{ textDecoration: 'none' }}><b>{p.name}</b><small className="spec">{p.memory === p.disk ? <span>RAM &amp; Disk {p.memory / 1024} GB</span> : <><span>RAM {p.memory / 1024} GB</span><span>Disk {p.disk / 1024} GB</span></>}<span>CPU {p.cpu}%</span>{p.days ? <span>Aktif {p.days} hari</span> : null}</small><div className="pr">{rp(p.price)}</div></Link>)}</div>
      {list.length === 0 && <p className="mut center">Daftar paket belum dapat ditampilkan. Muat ulang halaman beberapa saat lagi.</p>}</section>
    <section className="sec" id="kenapa"><h2 className="h2">Mengapa SnowyStore</h2><p className="mut center sub">Proses pembelian yang jelas, dari pembayaran sampai pesanan selesai.</p>
      <div className="fgrid">{WHY.map(([I, t, d]) => <div className="card feat hov" key={t} data-rv><div className="ft"><I size={22} /><h3>{t}</h3></div><p className="mut">{d}</p></div>)}</div></section>
    {list.length > 0 && <JsonLd id="ld-products" data={productSchema(list)} />}
    <section className="sec" id="panduan"><h2 className="h2">Panduan Terbaru</h2><p className="mut center sub">Artikel praktis seputar server panel, nomor virtual, pembayaran QRIS, garansi, dan keamanan akun.</p>
      <div className="artgrid">{ARTICLES.slice(0, 3).map((a) => <Link key={a.slug} href={`/panduan/${a.slug}`} className="card hov artcard"><span className="badge">{a.cat}</span><h3>{a.title}</h3><p className="mut">{a.desc}</p><div className="artmeta"><span className="artgo">Baca panduan <ChevronRight size={16} /></span></div></Link>)}</div>
      <p className="center" style={{ marginTop: 16 }}><Link href="/panduan" className="lnk">Lihat semua panduan</Link></p></section>
    <section className="sec alt" id="faq"><JsonLd id="ld-faq" data={faqSchema(FAQ)} /><h2 className="h2">Pertanyaan Populer</h2><p className="mut center sub">Jawaban untuk pertanyaan umum seputar layanan, pembayaran, dan garansi.</p>
      <div className="faqw">{FAQ.map(([q, a], i) => <div className="card qa" key={q}><button className="qh" aria-expanded={open === i} onClick={() => setOpen(open === i ? -1 : i)}><b>{q}</b><ChevronDown size={22} className={'pri' + (open === i ? ' rot' : '')} /></button><div className={'qa-b' + (open === i ? ' open' : '')}><div><p className="mut">{a}</p></div></div></div>)}</div></section>
    <section className="sec" id="mulai"><div className="ctaband"><h2>Siap mulai belanja di SnowyStore?</h2><p>Daftar gratis, pilih layanan, bayar dengan QRIS, dan pesanan Anda diproses otomatis.</p><div className="ybtn"><Link href="/register" className="yp"><Rocket size={18} />Daftar Gratis</Link>{ct && (ct.telegram || ct.wa) ? <a href={ct.telegram || `https://wa.me/${ct.wa}`} target="_blank" rel="noopener noreferrer" className="yo"><MessageCircle size={18} />Hubungi Kami</a> : <Link href="/login" className="yo">Masuk ke Akun <ArrowUpRight size={18} /></Link>}</div></div></section>
    </main>
    <footer className="ftr"><Brand />
      <p className="mut">Toko digital untuk aplikasi premium, nomor virtual OTP, dan hosting server panel. Pembayaran QRIS dan pemrosesan otomatis.</p>
      <div className="fcols"><div><h4>LAYANAN</h4><a href="#layanan">Aplikasi Premium</a><a href="#layanan">Nomor Virtual (OTP)</a><a href="#layanan">Hosting Server Panel</a><a href="#paket">Daftar Paket Hosting</a></div>
        <div><h4>KETENTUAN &amp; STATUS</h4><Link href="/garansi">Portal Garansi</Link><Link href="/status">Status Sistem</Link><Link href="/tentang">Tentang Kami</Link><Link href="/terms">Syarat &amp; Ketentuan</Link></div>
        <div><h4>BANTUAN &amp; AKUN</h4><Link href="/bantuan">Pusat Bantuan &amp; FAQ</Link><Link href="/produk">Katalog &amp; Harga</Link><Link href="/cara-order">Panduan &amp; Cara Order</Link><Link href="/panduan">Artikel &amp; Panduan</Link><Link href="/kontak">Kontak</Link><Link href="/login">Portal Member</Link><Link href="/register">Daftar Akun</Link></div></div>
      <FooterContact />
      <p className="mut center fine">© 2026 SnowyStore. Seluruh hak cipta dilindungi.</p></footer>
  </div>);
}
