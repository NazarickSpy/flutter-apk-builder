import Link from 'next/link';
import { Server, Gem, Smartphone, Store, ChevronRight } from 'lucide-react';
import PublicLayout from '../components/PublicLayout';
import JsonLd from '../components/JsonLd';
import { fetchPackages } from '../components/catalog';
import { productSchema } from '../components/site';
import { rp } from '../components/api';
// Katalog dirender di server (ISR): daftar paket, spesifikasi, dan harga langsung ada di HTML (terbaca Google & AI), lengkap dengan data terstruktur Product/Offer.
export async function getStaticProps() { const packages = await fetchPackages(); return { props: { packages }, revalidate: packages.length ? 300 : 20 }; }
export default function Produk({ packages = [] }) {
  return (<PublicLayout title="Katalog Produk dan Harga" sub="Katalog" desc="Katalog SnowyStore: paket server panel Pterodactyl dengan harga, aplikasi premium, dan nomor virtual OTP. Bayar dengan QRIS, pesanan diproses otomatis." crumbs={[['Beranda', '/'], ['Katalog', '/produk']]}>
    {packages.length > 0 && <JsonLd id="ld-products" data={productSchema(packages)} />}
    <section className="pubhead"><span className="pubico ico1"><Store size={30} /></span><h1>Katalog Produk dan Harga</h1><p className="mut">Tiga layanan dalam satu akun. Semua dibayar dengan QRIS dan diproses otomatis.</p></section>
    <h2 className="h2l"><Server size={20} /> Server Panel Pterodactyl</h2>
    <p className="mut">Untuk bot WhatsApp/Telegram/Discord, aplikasi Node.js atau Python, dan server game. Server dibuat otomatis setelah pembayaran terverifikasi. Server baru bersifat non-garansi, ketentuan lengkap di <Link href="/terms" className="lnk">Syarat dan Ketentuan</Link>.</p>
    {packages.length ? <div className="grid pkgrid">{packages.map((p) => <Link href="/register" key={p.key} className="pkg" style={{ textDecoration: 'none' }}><b>{p.name}</b><small className="spec">{p.memory === p.disk ? <span>RAM &amp; Disk {p.memory / 1024} GB</span> : <><span>RAM {p.memory / 1024} GB</span><span>Disk {p.disk / 1024} GB</span></>}{p.cpu ? <span>CPU {p.cpu}%</span> : null}</small><span className="pr">{rp(p.price)}</span></Link>)}</div>
      : <div className="card"><p className="mut" style={{ margin: 0 }}>Daftar paket sedang dimuat. Muat ulang beberapa saat lagi, atau lihat harga lengkap setelah <Link href="/register" className="lnk">mendaftar</Link>.</p></div>}
    <h2 className="h2l"><Gem size={20} /> Aplikasi Premium</h2>
    <div className="card"><p className="mut" style={{ marginTop: 0 }}>Akun aplikasi premium dengan masa aktif dan garansi sesuai deskripsi tiap produk. Pesanan diproses otomatis; bila gagal, dana dikembalikan oleh admin. Daftar produk dan harga terkini tampil setelah login.</p><div className="two"><Link href="/register" className="btn">Lihat Produk <ChevronRight size={16} /></Link><Link href="/panduan/garansi-dan-pengembalian-dana" className="btn ghost">Aturan Garansi</Link></div></div>
    <h2 className="h2l"><Smartphone size={20} /> Nomor Virtual (OTP)</h2>
    <div className="card"><p className="mut" style={{ marginTop: 0 }}>Nomor sementara untuk menerima kode OTP: pilih server, aplikasi, negara, lalu harga. Bila OTP tidak masuk, dana dikembalikan penuh.</p><div className="two"><Link href="/register" className="btn">Beli Nomor <ChevronRight size={16} /></Link><Link href="/panduan/cara-beli-nomor-virtual-otp" className="btn ghost">Cara Membeli</Link></div></div>
  </PublicLayout>);
}
