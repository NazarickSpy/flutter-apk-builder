import Marquee from '../components/Marquee';
import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { Headset, Eye, EyeOff, Plus, Server, ReceiptText, Megaphone, Layers, CirclePlus, ShieldAlert, Gift, Send, KeyRound, Copy, Check, ShoppingBag, ShieldCheck, RefreshCw, LoaderCircle, ChevronRight, Gem, Activity, QrCode, LifeBuoy, Smartphone } from 'lucide-react';
import { api, rp, copyText, fdate } from '../components/api';
import AppShell from '../components/AppShell';
import PageSkeleton from '../components/Skeleton';
import Checkout from '../components/Checkout';
import Confirm from '../components/Confirm';
import OrderRow from '../components/OrderRow';

export default function Dashboard() {
  const r = useRouter();
  const [me, setMe] = useState(null), [pk, setPk] = useState([]), [orders, setOrders] = useState([]), [panel, setPanel] = useState(null), [loadErr, setLoadErr] = useState('');
  const [sel, setSel] = useState(''), [name, setName] = useState(''), [pay, setPay] = useState(null), [payInit, setPayInit] = useState(null);
  const [hide, setHide] = useState(true), [show, setShow] = useState({}), [cp, setCp] = useState(''), [err, setErr] = useState(''), [busy, setBusy] = useState(false), [cf, setCf] = useState(null), [cfBusy, setCfBusy] = useState(false), [note, setNote] = useState(''), [ann, setAnn] = useState(''), [maint, setMaint] = useState('');

  // Allsettled: satu endpoint gagal TIDAK lagi menendang user ke /login. Hanya 401 (sesi habis) yang redirect.
  const load = useCallback(async () => {
    const [m, p, o, pn, cfg] = await Promise.allSettled([api('/me'), api('/packages'), api('/orders'), api('/panel'), api('/config')]);
    if (m.status === 'rejected') { if (m.reason.status === 401) r.push('/login'); else setLoadErr(m.reason.message); return; }
    if (o.status === 'rejected' && o.reason.status === 401) { r.push('/login'); return; }
    setLoadErr(''); setMe(m.value);
    if (p.status === 'fulfilled') setPk(p.value);
    if (o.status === 'fulfilled') setOrders(o.value);
    if (pn.status === 'fulfilled') setPanel(pn.value);
    if (cfg.status === 'fulfilled') { const sv = cfg.value.services || {}, off = sv.panel && sv.panel.on === false ? (sv.panel.msg || 'Pembelian panel sedang dinonaktifkan sementara.') : ''; setAnn(cfg.value.announcement || ''); setMaint(cfg.value.maintenance ? cfg.value.maintenance_msg || 'Sedang pemeliharaan. Order baru dibuka kembali sebentar lagi.' : off); }
  }, [r]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (pk.length && !pk.some((p) => p.key === sel)) setSel(pk[0].key); }, [pk, sel]);

  const go = async () => { setBusy(true); setErr(''); try { const x = await api('/orders', 'POST', { package: sel, name, price: (pk.find((p) => p.key === sel) || {}).price }); setName(''); setPayInit(x.order || null); setPay(x.id); load(); } catch (e) { setErr(e.message); } setBusy(false); };
  const copy = async (k, v) => { if (await copyText(v)) { setCp(k); setTimeout(() => setCp(''), 1500); } };
  const runConfirm = async () => {
    setCfBusy(true); setNote('');
    try {
      if (cf.kind === 'cancel') { await api(`/orders/${cf.o.id}/cancel`, 'POST'); setNote('Pesanan dibatalkan.'); }
      if (cf.kind === 'del') { await api(`/orders/${cf.o.id}`, 'DELETE'); setNote('Riwayat dihapus.'); }
      if (cf.kind === 'reset') { await api('/panel/reset', 'POST'); setShow({ legacy: true }); setNote('Password panel baru sudah dibuat.'); }
    } catch (e) { setNote(e.message); }
    setCfBusy(false); setCf(null); load();
  };
  const CF = { cancel: ['Batalkan Pesanan?', 'Pesanan yang belum dibayar akan dibatalkan. Jangan bayar QRIS-nya lagi setelah ini.', 'Ya, Batalkan'], del: ['Hapus dari Riwayat?', 'Pesanan disembunyikan dari akun Anda. Server yang sudah aktif tidak ikut terhapus dan garansi tetap bisa diklaim dengan TRX ID.', 'Ya, Hapus'], reset: ['Reset Password Panel?', 'Password login panel akan diganti dengan yang baru. Password lama tidak berlaku lagi.', 'Ya, Reset'] };

  if (!me) return loadErr ? (<div className="wrap"><div className="card center"><><p className="msg e" style={{ marginTop: 0 }}>{loadErr}</p><button className="btn" onClick={() => { setLoadErr(''); load(); }}><RefreshCw size={18} />Coba lagi</button></></div></div>) : <PageSkeleton cards={3} />;

  const admin = me.role === 'admin', active = orders.filter((o) => o.state === 'active').length, waiting = orders.filter((o) => ['unpaid', 'processing'].includes(o.state)).length;
  const act = [[ShoppingBag, 'Beli Panel', '#paket'], [Server, 'Server', '#orders'], [KeyRound, 'Akun Panel', '#akunpanel'], [Activity, 'Status', '/status']];
  const svc = [[CirclePlus, 'Beli Panel', '#paket'], [Gem, 'Aplikasi Premium', '/premium'], [Smartphone, 'Nomor OTP', '/nokos'], [Server, 'Server Saya', '#orders'], [KeyRound, 'Akun Panel', '#akunpanel'], [ReceiptText, 'Riwayat', '/orders'], [Activity, 'Status Layanan', '/status'], [ShieldAlert, 'Keamanan', '/profile']];
  // Langkah berikutnya: satu petunjuk jelas sesuai kondisi akun, supaya pengguna tidak perlu menebak harus ke mana
  const unpaid = orders.find((o) => o.state === 'unpaid'), failed = orders.find((o) => o.state === 'failed'), proc = orders.find((o) => o.state === 'processing');
  const next = unpaid ? { I: QrCode, t: 'Selesaikan pembayaran Anda', d: `Pesanan ${unpaid.server_name} menunggu pembayaran QRIS. Bayar sebelum waktu habis; server dibuat otomatis setelah terverifikasi.`, cta: 'Bayar Sekarang', fn: () => { setPayInit(null); setPay(unpaid.id); } }
    : failed ? { I: LifeBuoy, t: 'Pesanan Anda butuh bantuan', d: `Pembayaran untuk ${failed.server_name} sudah diterima tetapi server belum jadi. Hubungi bantuan dan sebutkan TRX ID ${failed.trx}.`, cta: 'Hubungi Bantuan', href: '/bantuan' }
    : proc ? { I: LoaderCircle, spin: true, t: 'Server Anda sedang dibuat', d: `Pesanan ${proc.server_name} sedang diproses. Biasanya selesai dalam 1-2 menit.`, cta: 'Periksa Lagi', fn: load }
    : active > 0 ? { I: KeyRound, t: 'Server Anda sudah aktif', d: 'Login ke panel memakai URL, username, dan password di bagian Akun Panel.', cta: 'Lihat Akun Panel', href: '#akunpanel' }
    : orders.length === 0 ? { I: ShoppingBag, t: 'Mulai dari sini: beli panel pertama Anda', d: 'Pilih paket, isi nama server, lalu bayar dengan QRIS. Server aktif otomatis setelah pembayaran terverifikasi.', cta: 'Pilih Paket', href: '#paket' }
    : { I: ShoppingBag, t: 'Butuh server baru?', d: 'Pilih paket lain di bagian Beli Panel. Pesanan lama tetap tersimpan di Riwayat.', cta: 'Pilih Paket', href: '#paket' };
  const tile = ([I, l, t], K) => (t.startsWith('#') ? <a key={l} className={K} href={t}><i><I size={22} /></i>{l}</a> : <Link key={l} className={K} href={t}><i><I size={22} /></i>{l}</Link>);
  return (<AppShell me={me} active="dashboard"><div className="dash">
    <div className="card hdc" style={{ order: 1 }}><span className="av lgav">{me.username[0].toUpperCase()}</span><div style={{ flex: 1, minWidth: 0 }}><b className="nm">{me.username}</b><br /><small className="mut">Selamat Datang di SnowyStore</small></div><Link href="/bantuan" className="sqbtn" aria-label="Bantuan"><Headset size={22} /></Link></div>
    <div className="card nxt" style={{ order: 2 }} role="status"><span className="nxi"><next.I size={22} className={next.spin ? 'spin' : ''} /></span><div className="nxt-b"><small className="cap">LANGKAH BERIKUTNYA</small><b>{next.t}</b><small className="mut">{next.d}</small></div>{next.href ? (next.href.startsWith('#') ? <a className="btn" href={next.href}>{next.cta}</a> : <Link className="btn" href={next.href}>{next.cta}</Link>) : <button className="btn" onClick={next.fn}>{next.cta}</button>}</div>
    <div className="card" style={{ order: 3 }}><div className="two2"><div><small className="cap">SERVER AKTIF</small><div className="bal">{active}</div></div><div className="vsep" /><div><small className="cap">MENUNGGU</small><div className="bal">{waiting}</div></div></div>
      <div className="actions">{act.map((a) => tile(a, 'act'))}</div></div>
    <div className="card ann" style={{ order: 2 }}><Megaphone size={20} className="pri" /><Marquee text={ann || 'SnowyStore - server panel Pterodactyl dan aplikasi premium. Bayar dengan QRIS, pesanan diproses otomatis.'} /></div>
    <div className="card" style={{ order: 5 }}><div className="ch"><Layers size={22} className="pri" /><b>Layanan SnowyStore</b></div><div className="svc">{svc.map((a) => tile(a, 'sv'))}</div></div>
    <div className="card" id="paket" style={{ order: 6 }}><div className="ch"><ShoppingBag size={22} className="pri" /><b>Beli Panel</b></div>
      <div className="grid">{pk.map((p) => <button key={p.key} className={'pkg' + (sel === p.key ? ' sel' : '')} onClick={() => setSel(p.key)}><b>{p.name}</b><small className="spec">{p.memory === p.disk ? <span>RAM &amp; Disk {p.memory / 1024} GB</span> : <><span>RAM {p.memory / 1024} GB</span><span>Disk {p.disk / 1024} GB</span></>}<span>CPU {p.cpu}%</span>{p.days ? <span>Aktif {p.days} hari</span> : null}</small><div className="pr">{rp(p.price)}</div></button>)}</div>
      {pk.length === 0 && <p className="mut">Paket belum tersedia atau sedang dimuat. Coba muat ulang beberapa saat lagi.</p>}
      <label>Username panel (3–14 karakter: huruf, angka, underscore)</label><input value={name} maxLength={14} placeholder="contoh: botwa01" autoCapitalize="none" autoCorrect="off" onChange={(e) => setName(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))} />
      <small className="mut" style={{ display: 'block', marginTop: 6 }}>Akun panel dibuat otomatis dengan email akun Anda. Server panel berstatus non-garansi dan dihapus otomatis saat masa aktif paket berakhir.</small>
      {maint && <div className="msg warnm">{maint}</div>}{err && <div className="msg e">{err}</div>}
      <button className="btn full" disabled={busy || !sel || name.length < 3 || (!!maint && !admin)} onClick={go}>{busy ? 'Memproses…' : 'Lanjut ke Pembayaran'}</button>
      {name.length < 3 && !busy && <small className="mut" style={{ display: 'block', marginTop: 8, textAlign: 'center' }}>Isi username panel minimal 3 karakter untuk melanjutkan.</small>}</div>
    <div className="card" id="orders" style={{ order: 7 }}><div className="ch"><Server size={22} className="pri" /><b style={{ flex: 1 }}>Server Saya</b>{orders.length > 5 && <Link href="/orders" className="lnk sm2">Semua ({orders.length}) <ChevronRight size={16} className="vm" /></Link>}</div>
      {note && <div className="msg s" style={{ marginTop: 0, marginBottom: 12 }}>{note}</div>}
      {orders.length === 0 && <p className="mut" style={{ margin: 0 }}>Belum ada pesanan. Pilih paket di atas untuk memulai.</p>}
      {orders.slice(0, 5).map((o) => <OrderRow key={o.id} o={o} copied={cp} onCopy={(v) => copy(v, v)} onPay={(i) => { setPayInit(null); setPay(i); }} onCancel={(x) => setCf({ kind: 'cancel', o: x })} onDelete={(x) => setCf({ kind: 'del', o: x })} />)}
      {orders.length > 0 && <Link href="/orders" className="btn full ghost">Lihat semua riwayat pesanan</Link>}</div>
    <div className="card" id="akunpanel" style={{ order: 8 }}><div className="ch"><KeyRound size={22} className="pri" /><b>Akun Panel</b></div>
      {!panel?.ready ? <p className="mut" style={{ margin: 0 }}>Akun panel dibuat otomatis untuk setiap pesanan panel. Setelah pesanan aktif, URL, username, dan password tampil di sini.</p> : <div className="cred">
        {(panel.accounts || []).map((a) => { const sh = !!show[a.order_id]; return <div className="acc" key={a.order_id}>
          <div className="acch"><b>{a.name}</b><small className="mut">{a.trx}{a.expires_at ? ` - aktif sampai ${fdate(a.expires_at)}` : ''}</small></div>
          {[['URL PANEL', a.url || '-'], ['USERNAME', a.username || '-'], ...(a.email ? [['EMAIL', a.email]] : [])].map(([k, v]) => <div className="ib2" key={k}><div style={{ minWidth: 0 }}><small className="cap">{k}</small><div className="mono val">{v}</div></div>{v !== '-' && <button className="sqbtn sm" onClick={() => copy(k + a.order_id, v)} aria-label="Salin">{cp === k + a.order_id ? <Check size={20} /> : <Copy size={20} />}</button>}</div>)}
          <div className="ib2"><div style={{ minWidth: 0 }}><small className="cap">PASSWORD</small><div className="mono val">{a.password ? (sh ? a.password : '••••••••••••') : 'Tidak dapat dibaca. Hubungi bantuan.'}</div></div>
            {a.password && <div style={{ display: 'flex', gap: 6 }}><button className="sqbtn sm" onClick={() => setShow({ ...show, [a.order_id]: !sh })} aria-label="Lihat">{sh ? <EyeOff size={20} /> : <Eye size={20} />}</button><button className="sqbtn sm" onClick={() => copy('PW' + a.order_id, a.password)} aria-label="Salin">{cp === 'PW' + a.order_id ? <Check size={20} /> : <Copy size={20} />}</button></div>}</div></div>; })}
        {panel.legacy && <div className="acc"><div className="acch"><b>Akun panel lama</b><small className="mut">Server yang dibuat sebelum pembelian lewat Averpay</small></div>
          {[['URL PANEL', panel.legacy.url], ['USERNAME', panel.legacy.username]].map(([k, v]) => <div className="ib2" key={k}><div style={{ minWidth: 0 }}><small className="cap">{k}</small><div className="mono val">{v}</div></div><button className="sqbtn sm" onClick={() => copy(k + 'L', v)} aria-label="Salin">{cp === k + 'L' ? <Check size={20} /> : <Copy size={20} />}</button></div>)}
          <div className="ib2"><div style={{ minWidth: 0 }}><small className="cap">PASSWORD</small><div className="mono val">{panel.legacy.password ? (show.legacy ? panel.legacy.password : '••••••••••••') : panel.legacy.unreadable ? 'Tidak dapat dibaca. Pakai tombol reset di bawah.' : 'Gunakan password panel yang sudah ada'}</div></div>
            {panel.legacy.password && <div style={{ display: 'flex', gap: 6 }}><button className="sqbtn sm" onClick={() => setShow({ ...show, legacy: !show.legacy })} aria-label="Lihat">{show.legacy ? <EyeOff size={20} /> : <Eye size={20} />}</button><button className="sqbtn sm" onClick={() => copy('PWL', panel.legacy.password)} aria-label="Salin">{cp === 'PWL' ? <Check size={20} /> : <Copy size={20} />}</button></div>}</div>
          <button className="btn ghost full" style={{ marginTop: 4 }} onClick={() => setCf({ kind: 'reset' })}><RefreshCw size={18} />Reset / buat password panel baru</button>
          <small className="mut">Server lama bermasalah? Ajukan penggantian lewat <Link href="/garansi" className="lnk">Portal Garansi</Link>.</small></div>}
        <small className="mut">Anda dapat mengganti password langsung di panel setelah login. Panel baru berstatus non-garansi dan dihapus otomatis saat masa aktif berakhir.</small></div>}</div>
    <div className="card" style={{ order: 9 }}><div className="ch" style={{ border: 0, margin: 0, padding: 0 }}><Send size={22} className="pri" /><b style={{ flex: 1 }}>Telegram Channel Updates</b><span className="soonb">COMING SOON</span></div></div>
  </div>
    {pay && <Checkout id={pay} initial={payInit} onClose={() => { setPay(null); setPayInit(null); load(); }} onChange={load} />}
    {cf && <Confirm title={CF[cf.kind][0]} text={CF[cf.kind][1]} yes={CF[cf.kind][2]} danger={cf.kind !== 'reset'} busy={cfBusy} onNo={() => setCf(null)} onYes={runConfirm} />}</AppShell>);
}
