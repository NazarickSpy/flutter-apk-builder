import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ChevronDown, LifeBuoy, MessageCircle, Send } from 'lucide-react';
import { api } from '../components/api';
import PublicLayout from '../components/PublicLayout';
import JsonLd from '../components/JsonLd';
import { faqSchema } from '../components/site';
const FAQ = [
  ['Bagaimana cara membeli server panel?', 'Daftar akun, pilih paket, isi username panel, lalu bayar dengan QRIS. Setelah pembayaran terverifikasi otomatis, server dibuat dan data login panel tampil di dashboard.'],
  ['Bagaimana cara membeli nomor virtual (OTP)?', 'Buka menu Nomor Virtual (OTP), pilih server, aplikasi, negara, lalu harga, dan bayar dengan QRIS. Nomor tampil otomatis setelah pembayaran terverifikasi, dan kode OTP muncul di halaman pesanan (diperbarui otomatis).'],
  ['OTP tidak masuk. Bagaimana dengan dana saya?', 'Jika nomor tidak menerima OTP sampai waktu habis, pesanan berubah menjadi Menunggu pengembalian dana dan admin mengembalikan dana penuh. Hubungi bantuan dengan kode pesanan (NOK…) untuk mempercepat.'],
  ['Bagaimana cara membeli aplikasi premium?', 'Buka menu Aplikasi Premium, pilih produk, baca deskripsinya, lalu bayar dengan QRIS. Data akun tampil di halaman pesanan dan tersimpan di akun Anda.'],
  ['Metode pembayaran apa yang tersedia?', 'QRIS, yang dapat dibayar melalui e-wallet atau m-banking apa pun. QRIS memiliki batas waktu (hitung mundur tampil di halaman pembayaran) dan harus dibayar sesuai nominal persis.'],
  ['QRIS tidak muncul atau terus memuat. Apa yang harus dilakukan?', 'Tekan Coba lagi pada jendela pembayaran, atau tutup lalu buka kembali dari Riwayat Pesanan (pesanan dan QRIS yang sama). Jika masih gagal, batalkan pesanan lalu buat pesanan baru.'],
  ['Bagaimana membatalkan pesanan?', 'Buka Dashboard atau Riwayat Pesanan, lalu tekan Batalkan pada pesanan berstatus Menunggu Bayar. Pesanan yang sudah dibayar tidak dapat dibatalkan.'],
  ['Bagaimana menghapus riwayat pesanan?', 'Di Riwayat Pesanan (panel) maupun Pesanan Premium Saya, tekan Hapus pada pesanan yang sudah selesai, kedaluwarsa, atau dibatalkan, atau hapus sekaligus lewat tombol hapus massal. Penghapusan hanya menyembunyikan catatan; server dan garansi tidak terpengaruh.'],
  ['Sudah membayar tetapi server belum aktif.', 'Sistem mencoba membuat server secara otomatis beberapa kali. Jika setelah beberapa menit server belum aktif, hubungi bantuan dan sebutkan TRX ID pesanan Anda.'],
  ['Sudah membayar tetapi akun premium belum muncul.', 'Buka Aplikasi Premium, Pesanan Premium Saya, lalu Detail; status diperbarui otomatis. Jika statusnya Diperiksa admin atau Menunggu pengembalian dana, pembayaran Anda aman: admin akan menyelesaikan pesanan atau mengembalikan dana penuh. Hubungi bantuan dengan kode pesanan (PRM…).'],
  ['Apakah server panel bergaransi?', 'Server panel baru berstatus non-garansi dan dihapus otomatis saat masa aktif paket berakhir (tanggalnya tampil di Akun Panel). Jika pesanan sudah dibayar tetapi panel belum aktif, hubungi bantuan dengan TRX ID Anda. Portal Garansi hanya untuk pesanan panel lama.'],
  ['Lupa password panel?', 'Password panel tampil di Dashboard > Akun Panel (tekan ikon mata). Anda juga dapat menggantinya langsung di panel setelah login.']];
export default function Bantuan() {
  const [open, setOpen] = useState(0), [ct, setCt] = useState(null);
  useEffect(() => { api('/config').then((c) => setCt(c.contact)).catch(() => {}); }, []);
  return (<PublicLayout title="Pusat Bantuan & FAQ" sub="Pusat Bantuan" desc="Jawaban seputar pemesanan, pembayaran QRIS, pembatalan, dan masa aktif panel di SnowyStore." crumbs={[['Beranda', '/'], ['Bantuan', '/bantuan']]}><JsonLd id="ld-faq" data={faqSchema(FAQ)} />
    <section className="pubhead"><span className="pubico ico5"><LifeBuoy size={30} /></span><h1>Pusat Bantuan &amp; FAQ</h1><p className="mut">Jawaban untuk pertanyaan seputar pemesanan, pembayaran, dan garansi.</p></section>
    {FAQ.map(([q, a], i) => <div className="card qa" key={q}><button className="qh" aria-expanded={open === i} onClick={() => setOpen(open === i ? -1 : i)}><b>{q}</b><ChevronDown size={22} className={'pri' + (open === i ? ' rot' : '')} /></button><div className={'qa-b' + (open === i ? ' open' : '')}><div><p className="mut">{a}</p></div></div></div>)}
    <div className="card center"><h3>Masih butuh bantuan?</h3><p className="mut">Sebutkan <b>TRX ID</b> pesanan Anda agar kami dapat membantu lebih cepat.</p>
      <div className="two">{ct?.wa ? <a className="btn" href={`https://wa.me/${ct.wa}`} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} />WhatsApp</a> : <Link href="/garansi" className="btn">Portal Garansi</Link>}{ct?.telegram ? <a className="btn ghost" href={ct.telegram} target="_blank" rel="noopener noreferrer"><Send size={18} />Telegram</a> : <Link href="/cara-order" className="btn ghost">Cara Order</Link>}</div></div>
  </PublicLayout>);
}
