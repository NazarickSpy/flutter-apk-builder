import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { ArrowLeft, Monitor, Cloud, FileQuestion, Check, X, Loader } from 'lucide-react';
import { api } from '../components/api';
import { useOnline } from '../components/hooks';
import PublicLayout from '../components/PublicLayout';
// Halaman 404: tiga indikator (Browser · SnowyStore · Halaman) dengan status nyata, lalu penjelasan dua kolom.
const Node = ({ I, who, label, state, ico }) => (<div className={'nfn ' + state}><div className={'nfi ' + ico}><I size={44} strokeWidth={1.5} /><span className="nfb">{state === 'load' ? <Loader size={13} /> : state === 'ok' ? <Check size={14} strokeWidth={3} /> : <X size={14} strokeWidth={3} />}</span></div>
  <small className="nfw">{who}</small><b>{label}</b><span className="nfs">{state === 'load' ? 'Memeriksa…' : state === 'ok' ? 'Berfungsi' : state === 'err' ? 'Error' : 'Tidak Ada'}</span></div>);
export default function NotFound() {
  const r = useRouter(), net = useOnline(), [srv, setSrv] = useState('load'), [path, setPath] = useState('');
  useEffect(() => {
    setPath(window.location.pathname.slice(0, 60)); let dead = false;
    const chk = () => api('/live').then(() => !dead && setSrv('ok')).catch(() => !dead && setSrv('err'));
    chk(); const t = setInterval(() => { if (!document.hidden) chk(); }, 15000); return () => { dead = true; clearInterval(t); };
  }, []);
  const back = () => (window.history.length > 1 ? r.back() : r.push('/'));
  return (<PublicLayout title="Halaman Tidak Tersedia"><section className="nf">
    <div className="nfband"><div className="nfrow">
      <Node I={Monitor} who="Anda" label="Browser" state={net ? 'ok' : 'err'} ico="ico4" />
      <Node I={Cloud} who="SnowyStore" label="Server" state={srv} ico="ico1" />
      <Node I={FileQuestion} who={path || 'Halaman'} label="Halaman" state="nf" ico="ico8" />
    </div></div>
    <div className="nfcols"><div><h1>Apa yang terjadi?</h1><p className="mut">Halaman tidak tersedia. Alamat yang Anda buka tidak ada atau telah dipindahkan.</p></div>
      <div><h2>Apa yang bisa dilakukan?</h2><p className="mut"><b>Pengunjung:</b> periksa kembali alamat yang dimasukkan, atau kembali ke halaman sebelumnya.</p><p className="mut"><b>Pemilik tautan:</b> pastikan alamat benar dan halaman belum dihapus. Jika masalah berlanjut, hubungi kami lewat Pusat Bantuan.</p>
        <button type="button" className="btn pill" onClick={back}><ArrowLeft size={18} />Kembali</button></div></div>
  </section></PublicLayout>);
}
