import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { AtSign, Mail, Phone, KeyRound, ArrowRight } from 'lucide-react';
import { api } from '../components/api';
import Shell, { Field } from '../components/Shell';
import Turnstile from '../components/Turnstile';
export default function Register() {
  const r = useRouter(); const [f, setF] = useState({ username: '', email: '', whatsapp: '', password: '' }); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const [site, setSite] = useState(null), [tok, setTok] = useState(''), [nonce, setNonce] = useState(0);
  useEffect(() => {
    let dead = false;
    api('/me').then((m) => { if (!dead) r.replace(m.role === 'admin' ? '/admin' : '/dashboard'); }).catch(() => {});
    api('/config').then((c) => { if (!dead) setSite(c.turnstile || ''); }).catch(() => { if (!dead) setSite(''); });
    return () => { dead = true; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const go = async (e) => { e.preventDefault(); setBusy(true); setErr(''); try { await api('/register', 'POST', { ...f, username: f.username.toLowerCase(), cf: tok }); r.push('/login'); } catch (x) { setErr(x.message); setBusy(false); setTok(''); setNonce((n) => n + 1); } };
  return (<Shell tab="register">
    <form onSubmit={go}><h1 className="ttl">Daftar Akun Baru</h1><p className="mut">Lengkapi data berikut untuk membuat akun. Nomor WhatsApp dipakai untuk bantuan dan verifikasi pesanan.</p>
      <Field icon={AtSign} label="Username" placeholder="username_anda" value={f.username} onChange={set('username')} required />
      <Field icon={Mail} label="Alamat Email" type="email" placeholder="nama@email.com" value={f.email} onChange={set('email')} required />
      <Field icon={Phone} label="Nomor WhatsApp" inputMode="numeric" placeholder="081234567890" value={f.whatsapp} onChange={set('whatsapp')} required />
      <Field icon={KeyRound} label="Kata Sandi" type="password" autoComplete="new-password" placeholder="Minimal 8 karakter" value={f.password} onChange={set('password')} required />
      <Turnstile siteKey={site} onToken={setTok} onError={() => setErr('Verifikasi keamanan gagal dimuat. Nonaktifkan pemblokir iklan atau coba jaringan lain, lalu muat ulang.')} resetNonce={nonce} />
      {err && <div className="msg e">{err}</div>}
      <button className="btn full pill" disabled={busy || site === null || (!!site && !tok)}>{busy ? 'Memproses…' : site && !tok ? 'Memverifikasi…' : <>Daftar Sekarang <ArrowRight size={20} /></>}</button></form>
    <p className="mut center sep">Sudah memiliki akun? <Link href="/login" className="lnk">Masuk di Sini</Link></p></Shell>);
}
