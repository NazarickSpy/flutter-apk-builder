import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Headset, Mail, MessageCircle, MapPin, Send, ShieldCheck, Activity, BookOpen } from 'lucide-react';
import PublicLayout from '../components/PublicLayout';
import JsonLd from '../components/JsonLd';
import { api } from '../components/api';
import { CONTACT, SITE_URL, abs } from '../components/site';
export default function Kontak() {
  const [ct, setCt] = useState(null);
  useEffect(() => { api('/config').then((c) => setCt(c.contact)).catch(() => {}); }, []);
  const wa = CONTACT.wa || (ct && ct.wa) || '', tg = (ct && ct.telegram) || '';
  const page = { '@context': 'https://schema.org', '@type': 'ContactPage', name: 'Kontak SnowyStore', url: abs('/kontak'), inLanguage: 'id-ID', mainEntity: { '@id': SITE_URL + '/#organization' } };
  return (<PublicLayout title="Kontak" sub="Kontak" desc="Hubungi SnowyStore lewat WhatsApp atau email untuk bantuan pesanan, pembayaran, garansi, dan pengembalian dana." crumbs={[['Beranda', '/'], ['Kontak', '/kontak']]}>
    <JsonLd id="ld-contact" data={page} />
    <section className="pubhead"><span className="pubico ico3"><Headset size={30} /></span><h1>Hubungi Kami</h1><p className="mut">Tim SnowyStore siap membantu soal pesanan, pembayaran, garansi, dan pengembalian dana.</p></section>
    <div className="card"><h3>Saluran kontak</h3>
      {wa ? <div className="kv"><span><MessageCircle size={14} /> WhatsApp</span><b><a className="lnk" href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">+{wa}</a></b></div> : null}
      {tg ? <div className="kv"><span><Send size={14} /> Telegram</span><b><a className="lnk" href={tg} target="_blank" rel="noopener noreferrer">{tg.replace(/^https?:\/\//, '')}</a></b></div> : null}
      {CONTACT.email ? <div className="kv"><span><Mail size={14} /> Email</span><b><a className="lnk" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a></b></div> : null}
      {CONTACT.address ? <div className="kv"><span><MapPin size={14} /> Alamat</span><b>{CONTACT.address}</b></div> : null}
      {!wa && !tg && !CONTACT.email ? <p className="mut" style={{ margin: 0 }}>Silakan gunakan Portal Garansi atau Pusat Bantuan di bawah ini.</p> : null}
      <div className="two" style={{ marginTop: 14 }}>{wa ? <a className="btn" href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} />Chat WhatsApp</a> : <Link className="btn" href="/bantuan"><Headset size={18} />Pusat Bantuan</Link>}<Link className="btn ghost" href="/garansi"><ShieldCheck size={18} />Portal Garansi</Link></div></div>
    <div className="card"><h3>Agar cepat ditangani</h3><p className="mut" style={{ margin: 0 }}>Sertakan kode pesanan Anda: TRX ID untuk server panel, PRM untuk aplikasi premium, atau NOK untuk nomor virtual, lalu jelaskan kendalanya singkat dan jelas. Admin tidak akan meminta kata sandi akun Anda.</p></div>
    <div className="card"><h3>Mungkin sudah terjawab di sini</h3><div className="flinks"><Link href="/bantuan"><Headset size={15} /> Pusat Bantuan dan FAQ</Link><Link href="/panduan"><BookOpen size={15} /> Panduan dan Artikel</Link><Link href="/status"><Activity size={15} /> Status Sistem</Link><Link href="/terms">Syarat dan Ketentuan</Link></div></div>
  </PublicLayout>);
}
