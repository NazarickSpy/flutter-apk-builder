import { SITE_URL } from '../components/site';
import { ARTICLES } from '../content/panduan';
// Peta situs dinamis (mengikuti APP_URL). Hanya halaman publik yang boleh diindeks.
const PAGES = [['/', '1.0'], ['/produk', '0.9'], ['/panduan', '0.8'], ['/cara-order', '0.8'], ['/garansi', '0.6'], ['/bantuan', '0.7'], ['/tentang', '0.6'], ['/kontak', '0.6'], ['/status', '0.4'], ['/terms', '0.4'], ['/register', '0.5']];
export async function getServerSideProps({ res }) {
  const u = (loc, pri, last) => `  <url><loc>${SITE_URL}${loc === '/' ? '/' : loc}</loc>${last ? `<lastmod>${last}</lastmod>` : ''}<priority>${pri}</priority></url>`;
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${[...PAGES.map(([p, pr]) => u(p, pr)), ...ARTICLES.map((a) => u('/panduan/' + a.slug, '0.7', a.updated || a.date))].join('\n')}\n</urlset>\n`;
  res.setHeader('Content-Type', 'application/xml; charset=utf-8'); res.setHeader('Cache-Control', 'public, s-maxage=3600, stale-while-revalidate=86400'); res.write(xml); res.end();
  return { props: {} };
}
export default function SiteMap() { return null; }
