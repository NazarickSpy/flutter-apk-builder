import { SITE_URL } from '../components/site';
export async function getServerSideProps({ res }) {
  const txt = `User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /dashboard\nDisallow: /orders\nDisallow: /profile\nDisallow: /admin\nDisallow: /notifikasi\nDisallow: /webhook/\n\nSitemap: ${SITE_URL}/sitemap.xml\n`;
  res.setHeader('Content-Type', 'text/plain; charset=utf-8'); res.setHeader('Cache-Control', 'public, s-maxage=3600'); res.write(txt); res.end();
  return { props: {} };
}
export default function Robots() { return null; }
