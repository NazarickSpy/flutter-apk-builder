import Link from 'next/link';
import { useEffect, useState, useCallback } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { History, Trash2, RefreshCw, LoaderCircle } from 'lucide-react';
import { api, copyText } from '../components/api';
import AppShell from '../components/AppShell';
import PageSkeleton from '../components/Skeleton';
import Checkout from '../components/Checkout';
import Confirm from '../components/Confirm';
import OrderRow from '../components/OrderRow';
const TABS = [['all', 'Semua', () => true], ['wait', 'Menunggu', (o) => ['unpaid', 'processing'].includes(o.state)], ['active', 'Aktif', (o) => o.state === 'active'], ['done', 'Selesai', (o) => ['expired', 'cancelled', 'failed'].includes(o.state)]];

export default function Orders() {
  const r = useRouter(); const [me, setMe] = useState(null), [list, setList] = useState(null), [err, setErr] = useState(''), [tab, setTab] = useState('all'), [pay, setPay] = useState(null), [cf, setCf] = useState(null), [busy, setBusy] = useState(false), [cp, setCp] = useState(''), [note, setNote] = useState('');
  const load = useCallback(async () => {
    try { const [m, o] = await Promise.all([api('/me'), api('/orders')]); setMe(m); setList(o); setErr(''); }
    catch (e) { if (e.status === 401) r.push('/login'); else setErr(e.message); }
  }, [r]);
  useEffect(() => { load(); }, [load]);
  const copy = async (v) => { if (await copyText(v)) { setCp(v); setTimeout(() => setCp(''), 1500); } };
  const run = async () => {
    setBusy(true);
    try {
      if (cf.kind === 'cancel') { await api(`/orders/${cf.o.id}/cancel`, 'POST'); setNote('Pesanan dibatalkan.'); }
      if (cf.kind === 'del') { await api(`/orders/${cf.o.id}`, 'DELETE'); setNote('Riwayat dihapus.'); }
      if (cf.kind === 'finished' || cf.kind === 'all') { const x = await api('/orders/clear', 'POST', { scope: cf.kind }); setNote(`${x.removed} riwayat dihapus.`); }
    } catch (e) { setNote(e.message); }
    setBusy(false); setCf(null); load();
  };
  const CF = {
    cancel: ['Batalkan Pesanan?', 'Pesanan yang belum dibayar akan dibatalkan. Jangan bayar QRIS-nya lagi setelah ini.', 'Ya, Batalkan', true],
    del: ['Hapus dari Riwayat?', 'Pesanan disembunyikan dari akun Anda. Server panel yang sudah aktif tidak ikut terhapus. Simpan TRX ID bila Anda perlu menghubungi bantuan.', 'Ya, Hapus', true],
    finished: ['Bersihkan Riwayat?', 'Semua pesanan berstatus kedaluwarsa dan dibatalkan akan dihapus dari riwayat. Pesanan aktif tidak disentuh.', 'Ya, Bersihkan', true],
    all: ['Hapus Semua Riwayat?', 'Semua riwayat (termasuk pesanan aktif) disembunyikan dari akun Anda. Server aktif tetap berjalan. Pesanan yang belum dibayar/perlu bantuan tidak ikut dihapus.', 'Ya, Hapus Semua', true]
  };
  const shown = list ? list.filter(TABS.find((t) => t[0] === tab)[2]) : [];
  if (!me) return err ? (<div className="wrap"><div className="card center"><><p className="msg e" style={{ marginTop: 0 }}>{err}</p><button className="btn" onClick={() => { setErr(''); load(); }}><RefreshCw size={18} />Coba lagi</button></></div></div>) : <PageSkeleton cards={3} />;
  return (<AppShell me={me} active="orders" head={{ title: 'Riwayat Pesanan', sub: 'Semua pesanan panel Anda, lengkap dengan status dan masa aktif.', icon: History, actions: <button className="btn ghost sm" onClick={load}><RefreshCw size={15} />Muat ulang</button> }}><Head><title>Riwayat Pesanan - SnowyStore</title></Head>
    <div className="card">
      <div className="chips" style={{ marginTop: 0, marginBottom: 14 }}>{TABS.map(([k, l, f]) => <button key={k} className={'chip' + (tab === k ? ' on' : '')} onClick={() => setTab(k)}>{l}{list ? ` (${list.filter(f).length})` : ''}</button>)}</div>
      {note && <div className="msg s" style={{ marginTop: 0, marginBottom: 12 }}>{note}</div>}{err && <div className="msg e" style={{ marginTop: 0, marginBottom: 12 }}>{err}</div>}
      {!list && <p className="mut loading"><LoaderCircle size={20} className="spin" /> Memuat…</p>}
      {list && shown.length === 0 && <div className="empty"><b>{list.length === 0 ? 'Belum ada pesanan' : 'Tidak ada pesanan di kategori ini'}</b><small className="mut">{list.length === 0 ? 'Pesanan yang Anda buat akan tampil di sini beserta statusnya.' : 'Pilih kategori lain di atas untuk melihat pesanan Anda.'}</small>{list.length === 0 && <Link href="/dashboard#paket" className="btn">Beli Panel Pertama</Link>}</div>}
      {shown.map((o) => <OrderRow key={o.id} o={o} copied={cp} onCopy={copy} onPay={setPay} onCancel={(x) => setCf({ kind: 'cancel', o: x })} onDelete={(x) => setCf({ kind: 'del', o: x })} />)}</div>
    {list && list.length > 0 && <div className="card"><div className="ch"><Trash2 size={22} className="pri" /><b>Kelola Riwayat</b></div>
      <div className="two bulk"><button className="btn ghost" onClick={() => setCf({ kind: 'finished' })}>Bersihkan kedaluwarsa &amp; batal</button><button className="btn ghost dangertxt" onClick={() => setCf({ kind: 'all' })}>Hapus semua riwayat</button></div>
      <small className="mut" style={{ display: 'block', marginTop: 12 }}>Menghapus riwayat hanya menyembunyikannya dari akun Anda dan tidak menghapus server panel. Salin dulu kredensial panel dari Dashboard (Akun Panel) bila diperlukan.</small></div>}
    {pay && <Checkout id={pay} onClose={() => { setPay(null); load(); }} onChange={load} />}
    {cf && <Confirm title={CF[cf.kind][0]} text={CF[cf.kind][1]} yes={CF[cf.kind][2]} danger={CF[cf.kind][3]} busy={busy} onNo={() => setCf(null)} onYes={run} />}</AppShell>);
}
