import { Activity } from 'lucide-react';
import PublicLayout from '../components/PublicLayout';
import { LivePanel, SystemInfo, useLive } from '../components/Live';
export default function Status() {
  const { d: live, err } = useLive(10000);
  return (<PublicLayout title="Status Sistem" sub="System Status" desc="Aktivitas server SnowyStore secara langsung: jumlah pesanan 24 jam terakhir, CPU, memori, dan waktu aktif.">
    <section className="pubhead"><span className="pubico ico7"><Activity size={24} /></span><h1>Aktivitas Server</h1><p className="mut">Pantauan langsung, diperbarui otomatis setiap 10 detik.</p></section>
    <LivePanel d={live} err={err} />
    <h2 className="h2" style={{ textAlign: 'center', margin: '26px 0 6px' }}>Informasi Sistem</h2><p className="mut center" style={{ marginBottom: 14 }}>Kinerja server real-time dan pemanfaatan sumber daya.</p>
    <SystemInfo d={live} />
  </PublicLayout>);
}
