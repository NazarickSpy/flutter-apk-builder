import Link from 'next/link';
import { Info, Mail, MessageCircle, MapPin, Globe } from 'lucide-react';
import PublicLayout from '../components/PublicLayout';
import JsonLd from '../components/JsonLd';
import { CONTACT, SITE_URL, abs } from '../components/site';
export default function Tentang() {
  const page = { '@context': 'https://schema.org', '@type': 'AboutPage', name: 'Tentang SnowyStore', url: abs('/tentang'), inLanguage: 'id-ID', about: { '@id': SITE_URL + '/#organization' } };
  return (<PublicLayout title="Tentang SnowyStore" sub="Tentang Kami" desc="Tentang SnowyStore: toko digital untuk aplikasi premium, nomor virtual OTP, dan hosting server panel Pterodactyl dengan pembayaran QRIS dan pemrosesan otomatis." crumbs={[['Beranda', '/'], ['Tentang', '/tentang']]}>
    <JsonLd id="ld-about" data={page} />
    <section className="pubhead"><span className="pubico ico1"><Info size={30} /></span><h1>Tentang SnowyStore</h1><p className="mut">Toko digital all-in-one: aplikasi premium, nomor OTP, dan hosting panel dalam satu akun.</p></section>
    <div className="card"><h3>Apa itu SnowyStore?</h3><p className="mut">SnowyStore adalah toko digital berbahasa Indonesia yang menjual tiga layanan: aplikasi premium, nomor virtual untuk menerima kode OTP, dan hosting server panel Pterodactyl dengan RAM 1 GB sampai 10 GB. Semua layanan dibeli dari satu akun dan dibayar dengan QRIS.</p></div>
    <div className="card"><h3>Cara kami bekerja</h3><p className="mut">Pesanan diproses otomatis setelah pembayaran terverifikasi. Status pembayaran dicek langsung ke penyedia pembayaran, server panel dibuat otomatis, dan data akun tersimpan di dashboard Anda. Pesanan yang sudah dibayar tetapi gagal diproses ditangani dan dananya dikembalikan oleh admin sesuai Syarat dan Ketentuan.</p></div>
    <div className="card"><h3>Prinsip kami</h3><ul className="mut" style={{ margin: 0, paddingLeft: 20 }}><li>Harga ditampilkan jelas sebelum Anda membayar.</li><li>Aturan garansi dan pengembalian dana ditulis terbuka di <Link href="/terms" className="lnk">Syarat dan Ketentuan</Link>.</li><li>Kata sandi di-hash, data akses panel dienkripsi, dan login dibatasi untuk mencegah penyalahgunaan.</li><li>Kondisi layanan dapat dipantau di <Link href="/status" className="lnk">halaman Status</Link>.</li></ul></div>
    <div className="card"><h3>Identitas usaha</h3>
      <div className="kv"><span>Nama</span><b>SnowyStore</b></div>
      <div className="kv"><span><Globe size={14} /> Situs</span><b><a className="lnk" href={SITE_URL + '/'}>{SITE_URL.replace(/^https?:\/\//, '')}</a></b></div>
      {CONTACT.email ? <div className="kv"><span><Mail size={14} /> Email</span><b><a className="lnk" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a></b></div> : null}
      {CONTACT.wa ? <div className="kv"><span><MessageCircle size={14} /> WhatsApp</span><b><a className="lnk" href={`https://wa.me/${CONTACT.wa}`} target="_blank" rel="noopener noreferrer">+{CONTACT.wa}</a></b></div> : null}
      {CONTACT.address ? <div className="kv"><span><MapPin size={14} /> Alamat</span><b>{CONTACT.address}</b></div> : null}
      <div className="two" style={{ marginTop: 14 }}><Link href="/kontak" className="btn">Hubungi Kami</Link><Link href="/panduan" className="btn ghost">Baca Panduan</Link></div></div>
  </PublicLayout>);
}
