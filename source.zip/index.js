// SnowyStore — entry point (Express + Next.js). Jalankan: `node index.js`  (mode dev: `node index.js --dev`)
const path = require('path'), fs = require('fs'), { spawnSync } = require('child_process');
require('dotenv').config({ path: path.join(__dirname, '.env') });
{ const gone = require('./lib/cleanup').removeStale(); if (gone.length) console.log('[SnowyStore] File lama dibersihkan:', gone.join(', ')); } // wajib sebelum build Next.js
const dev = process.argv.includes('--dev');
process.env.NODE_ENV = dev ? 'development' : 'production'; // deterministik, tidak bergantung setelan host
process.env.NEXT_TELEMETRY_DISABLED = '1';

// Build produksi otomatis bila folder .next belum ada (mis. hosting panel yang hanya menjalankan `npm install` + `node index.js`)
if (!dev && !fs.existsSync(path.join(__dirname, '.next', 'BUILD_ID'))) {
  console.log('[SnowyStore] Build produksi belum ada, menjalankan "next build" (butuh beberapa menit)...');
  const r = spawnSync(process.execPath, [require.resolve('next/dist/bin/next'), 'build'], { cwd: __dirname, stdio: 'inherit', env: process.env });
  if (r.status !== 0) { console.error('[SnowyStore] "next build" gagal. Jalankan "npm run build" manual lalu start ulang (cek RAM server, minimal ~1GB).'); process.exit(1); }
}
if (process.platform !== 'win32') { try { const m = fs.statSync(path.join(__dirname, '.env')).mode & 0o777; if (m & 0o007) console.warn(`[SnowyStore] PERINGATAN KEAMANAN: file .env bisa dibaca semua user di server (izin ${m.toString(8)}). Jalankan: chmod 600 .env`); } catch {} }
process.on('uncaughtException', (e) => console.error('[uncaughtException]', e && e.message ? e.message : e));
process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e && e.message ? e.message : e));

const express = require('express'), next = require('next'), helmet = require('helmet'), cookieParser = require('cookie-parser'), rateLimit = require('express-rate-limit');
const { migrate } = require('./lib/db');
const app = next({ dev, dir: __dirname }), handle = app.getRequestHandler();

for (const k of ['JWT_SECRET', 'DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME', 'APP_URL', 'AVERPAY_API_KEY']) if (!process.env[k]) { console.error(`ENV ${k} belum diisi`); process.exit(1); }
if (process.env.JWT_SECRET.length < 32) { console.error('JWT_SECRET terlalu pendek (minimal 32 karakter acak)'); process.exit(1); }
if (/domainkamu|example\.(com|org)/i.test(process.env.APP_URL + (process.env.PTERO_DOMAIN || ''))) console.warn('[SnowyStore] PERINGATAN: APP_URL / PTERO_DOMAIN di .env masih berisi contoh (placeholder). Isi dengan domain asli.');
if (process.env.ENC_KEY && process.env.ENC_KEY === process.env.JWT_SECRET) console.warn('[SnowyStore] PERINGATAN: ENC_KEY sama dengan JWT_SECRET. Pakai nilai berbeda agar satu kebocoran tidak membuka semuanya.');
if (!process.env.WEBHOOK_TOKEN) console.warn('[SnowyStore] SARAN KEAMANAN: isi WEBHOOK_TOKEN di .env dan daftarkan URL webhook Averpay dengan ?token=... (tanpa token, siapa pun bisa memicu pengecekan pembayaran).');
if (!process.env.ENC_KEY) console.warn('[SnowyStore] PERINGATAN: ENC_KEY belum diisi. Isi dengan string acak 32+ karakter DAN simpan cadangannya: kunci ini membuka password panel & data akun premium. (Data lama tetap terbaca.)');

app.prepare().then(async () => {
  await migrate();
  try { const [[ad]] = await require('./lib/db').pool.query("SELECT COUNT(*) n FROM users WHERE role='admin'"); if (ad.n && process.env.ADMIN_PASS) console.warn('[SnowyStore] PERINGATAN: ADMIN_PASS masih ada di .env padahal akun admin sudah dibuat. Hapus baris itu dari .env (ganti password lewat Profil).'); } catch {}
  const s = express();
  s.disable('x-powered-by'); s.set('trust proxy', 1);
  s.use((req, res, nx) => { req.id = require('crypto').randomBytes(4).toString('hex'); res.set('X-Request-Id', req.id); nx(); }); // ID unik tiap request: dilaporkan di pesan error & log
  s.use(require('./lib/accesslog')());
  s.use(require('./lib/shield').middleware); // perisai: blokir otomatis pemindai, enumerasi 404, dan alat otomatis pada login/daftar // log akses di console (LOG_REQUESTS=0 untuk mematikan)
  const ts = require('./lib/turnstile').enabled() ? ['https://challenges.cloudflare.com'] : [];
  if (!ts.length && (process.env.TURNSTILE_SITE || process.env.TURNSTILE_SECRET)) console.warn('[SnowyStore] PERINGATAN: Turnstile butuh TURNSTILE_SITE dan TURNSTILE_SECRET sekaligus. Saat ini NONAKTIF.');
  if (!ts.length) console.log('[SnowyStore] Turnstile nonaktif (isi TURNSTILE_SITE & TURNSTILE_SECRET untuk mewajibkan verifikasi saat login/daftar).');
  s.use(helmet({
    contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'", ...ts].concat(dev ? ["'unsafe-inline'", "'unsafe-eval'"] : []), scriptSrcAttr: ["'none'"], // produksi: TIDAK ada script inline yang boleh jalan (blokir XSS)

      styleSrc: ["'self'", "'unsafe-inline'"], fontSrc: ["'self'", 'data:'],
      frameSrc: ts.length ? ts : ["'none'"], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'", ...ts], objectSrc: ["'none'"], frameAncestors: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], ...(!dev && /^https:/i.test(process.env.APP_URL) ? { upgradeInsecureRequests: [] } : {}) } },
    hsts: { maxAge: 31536000, includeSubDomains: true }, referrerPolicy: { policy: 'same-origin' }, crossOriginOpenerPolicy: { policy: 'same-origin' }, crossOriginResourcePolicy: { policy: 'same-origin' }
  }));
  s.use((req, res, nx) => { let p; try { p = decodeURIComponent(req.path); } catch { return res.status(400).end(); } if (/(^|\/)\.(?!well-known)|\.(map|bak|sql|env|log|ya?ml|lock|pem|key)$|^\/(backups|lib|routes|tests|scripts|node_modules)(\/|$)/i.test(p)) return res.status(404).end(); nx(); }); // berkas rahasia/sumber tidak pernah dilayani
  s.use((_q, res, n) => { res.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()'); n(); });
  // aset statis (/_next, /img) tidak dihitung agar pengguna di jaringan bersama (NAT/wifi) tidak terkena limit saat memuat halaman
  s.use(rateLimit({ windowMs: 60e3, max: 240, standardHeaders: true, legacyHeaders: false, skip: (req) => req.path.startsWith('/_next/') || req.path.startsWith('/img/') }));
  s.use(express.json({ limit: '10kb' }), cookieParser());
  s.use(require('./routes/callback')); // webhook Averpay (/webhook/averpay) — di luar router /api, jadi tidak kena cek CSRF
  s.use('/api', require('./routes/api'));
  s.get('/healthz', rateLimit({ windowMs: 60e3, max: 30, standardHeaders: true, legacyHeaders: false }), async (_q, res) => { try { await require('./lib/db').pool.query('SELECT 1'); res.set('Cache-Control', 'no-store').json({ ok: true }); } catch { res.status(503).set('Cache-Control', 'no-store').json({ ok: false }); } });
  s.use('/api', (_q, res) => res.status(404).json({ error: 'Endpoint tidak ditemukan' })); // /api/* yang tak dikenal -> JSON, bukan halaman HTML
  s.use((err, req, res, next) => { // JSON rusak / body terlalu besar / error tak terduga -> respons JSON seragam, tanpa stack trace
    if (res.headersSent) return next(err);
    const bad = err && (err.type === 'entity.parse.failed' || err.type === 'entity.too.large');
    if (!bad) console.error(`[error ${req.id}]`, err && err.message ? err.message : err);
    res.status(bad ? 400 : 500).json(bad ? { error: 'Permintaan tidak valid' } : { error: 'Terjadi kesalahan server', ref: req.id });
  });
  s.all('*', (req, res) => handle(req, res));
  const worker = require('./lib/worker');
  const srv = s.listen(process.env.PORT || 3000, () => { console.log(`[SnowyStore] siap di port ${process.env.PORT || 3000} (${dev ? 'development' : 'production'})`); worker.start(); require('./lib/health').start(); });
  // Batas waktu koneksi (cegah koneksi lambat/menggantung menumpuk): header harus selesai < 15 dtk, seluruh request < 30 dtk, header maks 60 baris, 1000 request per koneksi.
  // keepAliveTimeout 65 dtk > keepalive upstream nginx (60 dtk) supaya nginx tidak memakai koneksi yang sudah ditutup Node. MAX_CONNECTIONS=0 -> tanpa batas (batasi di nginx/firewall).
  srv.headersTimeout = 15e3; srv.requestTimeout = 30e3; srv.keepAliveTimeout = 65e3; srv.maxHeadersCount = 60; srv.maxRequestsPerSocket = 1000;
  if (+process.env.MAX_CONNECTIONS > 0) srv.maxConnections = +process.env.MAX_CONNECTIONS;
  srv.on('clientError', (err, socket) => { if (err && err.code !== 'ECONNRESET' && socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); else socket.destroy(); }); // request cacat: tutup cepat, tanpa log berisik
  let closing = false;
  const shutdown = (sig) => { // matikan rapi: berhenti terima request & worker, tunggu proses berjalan, tutup DB
    if (closing) return; closing = true; console.log(`[SnowyStore] ${sig}: mematikan dengan rapi…`);
    worker.stop(); require('./lib/health').stop(); srv.close(async () => { try { await require('./lib/db').pool.end(); } catch {} process.exit(0); });
    setTimeout(() => process.exit(0), 8000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM')); process.on('SIGINT', () => shutdown('SIGINT'));
}).catch((e) => { console.error(e.message); process.exit(1); });
