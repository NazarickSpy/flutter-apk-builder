const test = require('node:test'), assert = require('node:assert/strict');
const accessLog = require('../lib/accesslog');
const run = (path, status, method = 'GET') => { const lines = []; const mw = accessLog({ out: (l) => lines.push(l), tty: false }); const h = {}; const res = { statusCode: status, on: (e, f) => { h[e] = f; } }; let nx = false; mw({ method, originalUrl: path, ip: '180.252.248.157', id: 'ab12' }, res, () => { nx = true; }); if (h.finish) h.finish(); return { lines, nx }; };
test('mencatat method, path, status, durasi, IP tersamar; query string tidak dicatat', () => {
  const r = run('/webhook/averpay?token=RAHASIA', 200, 'POST'); assert.equal(r.nx, true); assert.equal(r.lines.length, 1);
  assert.match(r.lines[0], /POST\s+\/webhook\/averpay\s+200\s+\d+ms\s+180\.252\.-\.-\s+#ab12/); assert.ok(!r.lines[0].includes('RAHASIA'));
});
test('404 dan 500 tercatat; aset statis & polling dilewati', () => {
  assert.match(run('/api/auth/ayshs', 404).lines[0], /\/api\/auth\/ayshs\s+404/);
  assert.match(run('/api/login', 500, 'POST').lines[0], /500/);
  for (const p of ['/_next/static/x.js', '/img/logo.webp', '/healthz', '/api/live']) assert.equal(run(p, 200).lines.length, 0);
});
