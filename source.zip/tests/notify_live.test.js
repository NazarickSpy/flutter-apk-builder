const test = require('node:test'), assert = require('node:assert/strict');
const { mockModules } = require('./helpers'), { makePool } = require('./dbshim');
process.env.JWT_SECRET = 'x'.repeat(40);
const pool = makePool(); mockModules({ './db': { pool } });
const notify = require('../lib/notify'), live = require('../lib/live');
const R = (s, p) => pool._run(s, p)[0];
const AND = 'Mozilla/5.0 (Linux; Android 14; CPH2000) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36';
const WIN = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36 Edg/126.0';
const ago = (ms) => new Date(Date.now() - ms).toISOString().slice(0, 19).replace('T', ' ');
let uid;
test.beforeEach(() => { for (const t of ['events', 'orders', 'premium_orders', 'nokos_orders', 'claims', 'users']) R(`DELETE FROM ${t}`); uid = R("INSERT INTO users(username,role) VALUES('budi','member')").insertId; });

test('UA: browser & OS dikenali; IP disamarkan (IPv4 dan IPv6)', () => {
  assert.deepEqual(notify.parseUa(AND), { os: 'Android', browser: 'Chrome', device: 'Chrome - Android' });
  assert.equal(notify.parseUa(WIN).browser, 'Edge'); assert.equal(notify.parseUa('').os, 'Perangkat');
  assert.equal(notify.maskIp('180.252.248.157'), '180.252.-.-'); assert.equal(notify.maskIp('2001:db8:1:2::1'), '2001:db8:---'); assert.equal(notify.maskIp(''), '—');
});
test('login: perangkat (browser+OS) yang belum pernah dipakai ditandai BARU (warn); yang sudah dikenal = info; login pertama tidak ditandai baru', async () => {
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [uid, 'login', '1.2.3.4', AND, ago(3 * 864e5)]);
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [uid, 'login', '1.2.3.5', AND, ago(2 * 864e5)]);
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [uid, 'login', '9.9.9.9', WIN, ago(60e3)]);
  const { items } = await notify.list(uid), logins = items.filter((n) => n.kind === 'login');
  assert.equal(logins.length, 3); assert.equal(logins[0].level, 'warn'); assert.match(logins[0].title, /perangkat baru/i); assert.deepEqual(logins[0].tags.map((t) => t.label), ['Windows', '9.9.-.-', 'Edge']);
  assert.equal(logins[1].level, 'info'); assert.equal(logins[2].level, 'info'); assert.match(logins[2].title, /berhasil/i);
  assert.ok(!JSON.stringify(items).includes('9.9.9.9'), 'IP asli tidak boleh keluar');
});
test('login gagal tampil sebagai bahaya; urutan terbaru dulu; data user lain tidak ikut', async () => {
  const other = R("INSERT INTO users(username) VALUES('lain')").insertId;
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [uid, 'login', '1.1.1.1', AND, ago(5000)]);
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [uid, 'login_fail', '1.1.1.1', AND, ago(1000)]);
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [other, 'login', '5.5.5.5', AND, ago(500)]);
  const { items } = await notify.list(uid); assert.equal(items.length, 2); assert.equal(items[0].kind, 'login_fail'); assert.equal(items[0].level, 'bad');
});
test('pesanan panel/premium/nokos & klaim menjadi notifikasi sesuai status; pesanan tersembunyi dan data lama (>30 hari) tidak ikut', async () => {
  R("INSERT INTO orders(user_id,package_key,price,server_name,pay_status,status,order_ref,updated_at) VALUES(?,?,?,?,?,?,?,?)", [uid, '1gb', 1, 'botwa01', 'paid', 'active', 'SNW1', ago(2000)]);
  R("INSERT INTO orders(user_id,package_key,price,server_name,pay_status,status,order_ref,hidden,updated_at) VALUES(?,?,?,?,?,?,?,?,?)", [uid, '1gb', 1, 'sembunyi', 'paid', 'active', 'SNW2', 1, ago(2000)]);
  R("INSERT INTO orders(user_id,package_key,price,server_name,pay_status,status,order_ref,updated_at) VALUES(?,?,?,?,?,?,?,?)", [uid, '1gb', 1, 'lama', 'paid', 'active', 'SNW3', ago(40 * 864e5)]);
  R("INSERT INTO premium_orders(user_id,ref,product_id,product_name,cost,price,status,updated_at) VALUES(?,?,?,?,?,?,?,?)", [uid, 'P1', '4', 'Capcut Pro', 1, 1, 'refund_needed', ago(3000)]);
  R("INSERT INTO nokos_orders(user_id,ref,platform_id,platform_name,country_id,country_name,product_id,product_name,cost,price,status,phone,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", [uid, 'N1', 1, 'WhatsApp', 6, 'Indonesia', 'x', 'x', 1, 1, 'waiting_otp', '+62812', ago(4000)]);
  const o1 = R("INSERT INTO orders(user_id,package_key,price,server_name,pay_status,status,order_ref) VALUES(?,?,?,?,?,?,?)", [uid, '1gb', 1, 'klaimsrv', 'paid', 'active', 'SNW4']).insertId;
  R("INSERT INTO claims(order_id,user_id,category,reason,status,updated_at) VALUES(?,?,?,?,?,?)", [o1, uid, 'x', 'y', 'rejected', ago(1000)]);
  const { items } = await notify.list(uid), t = (k) => items.filter((n) => n.kind === k);
  assert.equal(t('order').filter((n) => /botwa01/.test(n.text)).length, 1); assert.equal(t('order').find((n) => /botwa01/.test(n.text)).level, 'ok'); assert.ok(!items.some((n) => /sembunyi|lama:|\blama\b/.test(n.text)));
  assert.equal(t('premium')[0].level, 'warn'); assert.match(t('premium')[0].text, /Capcut Pro/); assert.match(t('nokos')[0].text, /\+62812/); assert.equal(t('claim')[0].level, 'bad'); assert.match(t('claim')[0].text, /klaimsrv/);
  for (const n of items) assert.ok(n.id && n.title && n.href && n.at, 'tiap notifikasi punya id, judul, tautan, waktu');
  const times = items.map((n) => n.at); assert.deepEqual(times, [...times].sort().reverse());
});
test('belum dibaca: dihitung dari notif_seen_at; markRead menolkan; kejadian baru setelahnya menambah lagi', async () => {
  R("UPDATE users SET notif_seen_at=? WHERE id=?", [ago(10 * 60e3), uid]);
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [uid, 'login', '1.1.1.1', AND, ago(60 * 60e3)]);
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [uid, 'login', '1.1.1.1', AND, ago(30e3)]);
  let r = await notify.list(uid); assert.equal(r.unread, 1); assert.deepEqual(r.items.map((n) => n.unread), [true, false]);
  await notify.markRead(uid); r = await notify.list(uid); assert.equal(r.unread, 0);
  R("INSERT INTO events(user_id,type,ip,ua,created_at) VALUES(?,?,?,?,?)", [uid, 'password', '1.1.1.1', AND, new Date(Date.now() + 5000).toISOString().slice(0, 19).replace('T', ' ')]);
  r = await notify.list(uid); assert.equal(r.unread, 1);
});
test('riwayat login (Profil): menandai perangkat ini & perangkat baru, IP disamarkan', () => {
  const rows = [{ id: 3, type: 'login', ip: '9.9.9.9', ua: WIN, created_at: new Date() }, { id: 2, type: 'login_fail', ip: '1.2.3.4', ua: AND, created_at: new Date() }, { id: 1, type: 'login', ip: '1.2.3.4', ua: AND, created_at: new Date() }];
  const h = notify.loginHistory(rows, { ua: WIN, ip: '9.9.9.9' });
  assert.equal(h[0].current, true); assert.equal(h[0].new_device, true); assert.equal(h[0].ip, '9.9.-.-'); assert.equal(h[0].browser, 'Edge'); assert.equal(h[2].current, false); assert.equal(h[2].new_device, false); assert.equal(h[1].new_device, false);
});

test('live: pesanan 24 jam dibucket per jam (24 slot, terbaru di kanan), top layanan benar, di luar jendela diabaikan', () => {
  const now = Date.now(), at = (h) => new Date(now - h * 3600e3 - 60e3).toISOString();
  const b = live.bucket([{ at: at(0), kind: 'panel' }, { at: at(0), kind: 'premium' }, { at: at(0), kind: 'premium' }, { at: at(5), kind: 'nokos' }, { at: at(23), kind: 'panel' }, { at: at(30), kind: 'panel' }], now);
  assert.equal(b.hourly.length, 24); assert.equal(b.hourly[23], 3); assert.equal(b.hourly[18], 1); assert.equal(b.hourly[0], 1); assert.equal(b.hourly.reduce((a, c) => a + c, 0), 5);
  assert.deepEqual(b.by, { panel: 2, premium: 2, nokos: 1 }); assert.ok(b.top && b.top.n === 2); assert.equal(live.bucket([], now).top, null);
});
test('live: snapshot dari DB berisi agregat tanpa data pribadi + info sistem lengkap', async () => {
  R("INSERT INTO orders(user_id,package_key,price,server_name,pay_status,status,pkg_name,order_ref) VALUES(?,?,?,?,?,?,?,?)", [uid, '1gb', 1, 'rahasia_srv', 'paid', 'active', 'Panel 1 GB', 'SNWX']);
  R("INSERT INTO premium_orders(user_id,ref,product_id,product_name,cost,price,status) VALUES(?,?,?,?,?,?,?)", [uid, 'PX', '4', 'Capcut Pro', 1, 1, 'done']);
  live._clear(); const s = await live.snapshot();
  assert.equal(s.ok, true); assert.equal(s.hourly.length, 24); assert.equal(s.orders_24h, 2); assert.equal(s.orders_total, 2); assert.equal(s.panels_active, 1); assert.equal(s.members, 1); assert.ok(s.recent.length >= 2);
  const raw = JSON.stringify(s); assert.ok(!/rahasia_srv|budi|SNWX|PX\b/.test(raw), 'nama server/user/kode pesanan tidak boleh bocor');
  const y = s.system; assert.ok(y.cpu >= 0 && y.cpu <= 100); assert.ok(y.cores >= 1); assert.ok(y.heap_used > 0 && y.heap_limit > y.heap_used); assert.ok(y.uptime >= 0); assert.match(y.node, /^v\d+$/); assert.match(y.os, /\(/); assert.ok(y.mem_total_gb > 0);
});
