const test = require('node:test'), assert = require('node:assert');
const t = require('../lib/totp'), g = require('../lib/guard');
test('TOTP cocok vektor RFC 6238 & tolak pakai ulang', () => {
  const sec = t.b32(Buffer.from('12345678901234567890'));
  assert.equal(t.hotp(sec, 1), '287082');
  const now = 59000, code = '287082'; const st = t.verify(sec, code, { now }); assert.equal(st, 1);
  assert.equal(t.verify(sec, code, { now, last: st }), null);
  assert.equal(t.verify(sec, '000000', { now }), null); assert.equal(t.verify(sec, 'abc', { now }), null);
});
test('kode pemulihan sekali pakai', () => {
  const c = t.recoveryCodes(); assert.equal(c.length, 8); assert.match(c[0], /^[A-Z2-9]{5}-[A-Z2-9]{5}$/);
  const left = t.useRecovery(JSON.stringify(c.map(t.hashCode)), c[0].toLowerCase()); assert.equal(left.length, 7);
  assert.equal(t.useRecovery(JSON.stringify(left), c[0]), null);
});
test('kunci akun bertingkat', () => { assert.deepEqual([4, 5, 10, 15, 30].map(g.lockMinutes), [0, 15, 60, 1440, 1440]); });
test('penjaga IP: banyak username berbeda memblokir', () => {
  g._clear(); const ip = '1.2.3.4'; for (let i = 0; i < 7; i++) g.fail(ip, 'u' + i); assert.equal(g.blocked(ip), false);
  g.fail(ip, 'u8'); assert.equal(g.blocked(ip), true); assert.equal(g.blocked('9.9.9.9'), false);
});
