// Nokos (nomor OTP) lewat API Nokos Averpay terbaru: server -> layanan -> negara -> produk (quote_id), QRIS -> order (POST) -> OTP, OTP kedua, refund & keamanan alur
const test = require('node:test'), assert = require('node:assert/strict'), { mockModules } = require('./helpers'), { makePool } = require('./dbshim');
process.env.JWT_SECRET = 'x'.repeat(40); process.env.NOKOS_RETRY_MS = '0';
const pool = makePool();
let handler, calls = [], circuit = false, gw = {}, invN = 0, createFail = null;
const E = (status, msg, extra) => Object.assign(new Error(msg || 'x'), { status, ...extra });
const fake = {
  get: async (path, params) => { calls.push({ path, params, method: 'GET' }); return handler(path, params || {}); },
  post: async (path, params) => { calls.push({ path, params, method: 'POST' }); return handler(path, params || {}); },
  create: async (amount) => { calls.push({ path: 'create', amount }); if (createFail) throw createFail; const id = 'INV' + ++invN; return { transaction_id: id, total: amount + 500, qr_image: `https://qr.example/${id}.png`, expires_at: new Date(Date.now() + 15 * 60e3) }; },
  status: async (tx) => { if (gw[tx] === 'err') throw new Error('gateway down'); return { paid: gw[tx] === 'paid', expired: gw[tx] === 'expired' }; },
  breaker: () => ({ open: circuit, name: 'averpay' }), flat: (j) => j };
mockModules({ './db': { pool }, './averpay': fake });
const nokos = require('../lib/nokos'), settings = require('../lib/settings'), { dec } = require('../lib/crypto');
const R = (sql, p) => pool._run(sql, p)[0];
const mkUser = () => ({ id: R('INSERT INTO users(username,email) VALUES(?,?)', ['u' + Math.random(), 'a@b.c']).insertId });
const row = (id) => R('SELECT * FROM nokos_orders WHERE id=?', [id])[0];
const SERVERS = { success: true, data: [{ id: 'ekonomi', name: 'Ekonomi' }, { id: 'premium', name: 'Premium' }] };
const SERVICES = { success: true, data: [{ code: 'wa', name: 'WhatsApp' }, { code: 'tg', name: 'Telegram' }, { code: '', name: 'Rusak' }] };
const COUNTRIES = { success: true, data: [{ code: 'id', name: 'Indonesia', emoji: 'ID' }, { code: 'us', name: 'USA' }] };
const PRODUCTS = { success: true, data: [{ id: 'p142', quote_id: 'q142', price: 18000, stock: 12 }, { id: 'p143', quote_id: 'q143', price: 1500, stock: 3 }, { id: 'p144', quote_id: 'q144', price: 900, stock: 0 }, { id: 'p145', quote_id: 'q145', price: 0 }] };
const base = (over = {}) => (path, p) => {
  if (path === '/api/nokos/servers') return SERVERS; if (path === '/api/nokos/services') return SERVICES; if (path === '/api/nokos/countries') return COUNTRIES; if (path === '/api/nokos/products') return over.products ? over.products(p) : PRODUCTS;
  if (path === '/api/nokos/order') return over.order ? over.order(p) : { success: true, data: { _id: 'NOKOSa1b2', phoneNumber: '+6281234567890', sellPrice: 1500, status: 'ACTIVE', expiresAt: new Date(Date.now() + 20 * 60e3).toISOString() } };
  if (path === '/api/nokos/status') return over.status ? over.status(p) : { success: true, data: { _id: 'NOKOSa1b2', phoneNumber: '+6281234567890', status: 'ACTIVE' } };
  if (path === '/api/nokos/resend') return over.resend ? over.resend(p) : { success: true };
  if (path === '/api/nokos/cancel') return over.cancel ? over.cancel(p) : { success: true };
};
test.beforeEach(() => { calls = []; circuit = false; gw = {}; createFail = null; nokos._reset(); handler = base(); R('DELETE FROM settings'); settings._clear(); R('DELETE FROM nokos_orders'); });
const orders = () => calls.filter((c) => c.path === '/api/nokos/order'), invoices = () => calls.filter((c) => c.path === 'create');
const PRICE_WA_MURAH = 2000; // modal 1.500 + margin (15% = 225 < min 500) = 2.000
const make = (u, over = {}) => nokos.create(u, { server: 'ekonomi', service: 'wa', country: 'id', product_id: 'p143', price: PRICE_WA_MURAH, ...over });
const pay = async (o, u) => { gw[row(o.id).invoice_id] = 'paid'; return nokos.view(u.id, o.id); };

test('katalog bertahap sesuai aturan Averpay: server -> layanan -> negara -> produk (server, service, country dikirim), data rusak dibuang', async () => {
  assert.deepEqual((await nokos.servers()).items.map((x) => x.id), ['ekonomi', 'premium']);
  assert.deepEqual((await nokos.services('ekonomi')).items.map((x) => x.name), ['Telegram', 'WhatsApp']);
  assert.deepEqual(calls.find((x) => x.path === '/api/nokos/services').params, { server: 'ekonomi' });
  assert.deepEqual((await nokos.countries()).items.map((x) => x.id), ['id', 'us']); // urut nama: Indonesia, USA; kode negara huruf kecil
  const p = await nokos.products('ekonomi', 'wa', 'id'); assert.deepEqual(p.items.map((x) => x.id), ['p144', 'p143', 'p142']); // urut harga; harga 0 dibuang
  assert.deepEqual(calls.find((x) => x.path === '/api/nokos/products').params, { server: 'ekonomi', service: 'wa', country: 'id' }); assert.equal(p.items[1].quote, 'q143');
});
test('daftar server: bila /servers kosong/tak dikenali, dipakai 4 server resmi (ekonomi, premium, khusus, wa_luar)', async () => {
  handler = (path, p) => (path === '/api/nokos/servers' ? { success: true, data: [] } : base()(path, p));
  assert.deepEqual((await nokos.servers()).items.map((x) => x.id), ['ekonomi', 'premium', 'khusus', 'wa_luar']);
  nokos._reset(); handler = (path, p) => (path === '/api/nokos/servers' ? ['ekonomi', 'wa_luar'] : base()(path, p)); assert.deepEqual((await nokos.servers()).items.map((x) => x.id), ['ekonomi', 'wa_luar']);
});
test('cache: daftar aplikasi/negara tidak diambil ulang tiap klik (aturan rate limit)', async () => {
  await nokos.services('ekonomi'); await nokos.services('ekonomi'); await nokos.countries(); await nokos.countries(); await nokos.products('ekonomi', 'wa', 'id'); await nokos.products('ekonomi', 'wa', 'id');
  assert.equal(calls.filter((x) => x.path === '/api/nokos/services').length, 1); assert.equal(calls.filter((x) => x.path === '/api/nokos/countries').length, 1); assert.equal(calls.filter((x) => x.path === '/api/nokos/products').length, 1);
});
test('Averpay gangguan: daftar terakhir dipakai (stale) maks 30 menit, bukan kosong', async () => {
  await nokos.products('ekonomi', 'wa', 'id'); handler = () => { throw E(502, 'down'); }; const r = await nokos.products('ekonomi', 'wa', 'id', 0); assert.equal(r.stale, true); assert.equal(r.items.length, 3);
  await assert.rejects(nokos.products('ekonomi', 'tg', 'us', 0));
});
test('harga jual = modal + margin (15% / min Rp500, dibulatkan ke atas Rp100), selalu > modal; pengaturan admin berlaku', async () => {
  const c = await nokos.cfg(); assert.equal(nokos.priceFor(1500, c), 2000); assert.equal(nokos.priceFor(18000, c), 20700);
  R("INSERT INTO settings(k,v) VALUES('nokos_margin_pct','0'),('nokos_margin_min','1000')"); settings._clear(); assert.equal(nokos.priceFor(1500, await nokos.cfg()), 2500);
});
test('CREATE: ditolak SEBELUM QRIS dibuat: kode tidak valid, server/produk tak dikenal, stok habis, harga berubah, sirkuit terbuka', async () => {
  const u = mkUser();
  await assert.rejects(make(u, { service: '' }), (e) => e.http === 400); await assert.rejects(make(u, { product_id: 'bad id!' }), (e) => e.http === 400); await assert.rejects(make(u, { country: 'indonesia-raya' }), (e) => e.http === 400);
  await assert.rejects(make(u, { service: 'zz' }), (e) => e.http === 404); await assert.rejects(make(u, { product_id: 'p999' }), (e) => e.http === 404); await assert.rejects(make(u, { server: 'nope' }), (e) => e.http === 404);
  await assert.rejects(make(u, { server: 'premium', operator: 'xl' }), (e) => e.http === 400);
  await assert.rejects(make(u, { product_id: 'p144', price: 1500 }), (e) => e.http === 409 && /habis/i.test(e.message));
  await assert.rejects(make(u, { price: 1 }), (e) => e.http === 409 && e.price === PRICE_WA_MURAH);
  handler = base({ products: () => ({ success: true, data: [{ id: 'p143', price: 1500, stock: 3 }] }) }); nokos._reset(); await assert.rejects(make(u), (e) => e.http === 409 && /belum siap/i.test(e.message)); handler = base(); nokos._reset();
  circuit = true; await assert.rejects(make(u), (e) => e.http === 503); circuit = false;
  assert.equal(invoices().length, 0, 'tidak ada QRIS untuk pesanan yang pasti gagal');
});
test('CREATE sukses: QRIS = harga jual, modal dicatat, klik ganda memakai pesanan yang sama (tanpa QRIS dobel)', async () => {
  const u = mkUser(), a = await make(u), b = await make(u);
  assert.equal(a.status, 'awaiting_payment'); assert.equal(a.id, b.id); assert.equal(invoices().length, 1); assert.equal(invoices()[0].amount, PRICE_WA_MURAH);
  const r = row(a.id); assert.equal(r.cost, 1500); assert.equal(r.platform_name, 'WhatsApp'); assert.equal(r.country_name, 'Indonesia'); assert.equal(r.server, 'ekonomi'); assert.equal(r.platform_id, 'wa'); assert.equal(r.country_id, 'id'); assert.equal(a.server_name, 'Ekonomi'); assert.equal(a.phone, undefined, 'nomor belum tampil sebelum bayar');
});
test('PAY: lunas -> POST /api/nokos/order dengan quote_id (dari katalog segar) -> waiting_otp; nomor tampil', async () => {
  const u = mkUser(), o = await make(u), v = await pay(o, u);
  assert.equal(v.status, 'waiting_otp'); assert.equal(orders().length, 1); assert.equal(orders()[0].method, 'POST'); assert.deepEqual(orders()[0].params, { quote_id: 'q143' });
  assert.equal(v.phone, '+6281234567890'); assert.ok(v.otp_expires_at); assert.equal(row(o.id).provider_id, 'NOKOSa1b2'); assert.equal(v.otp, undefined, 'OTP belum ada');
});
test('quote_id hanya berlaku 5 menit: setelah lunas katalog DIAMBIL ULANG dan quote segar yang dipakai, bukan quote saat memilih', async () => {
  let n = 0; handler = base({ products: () => ({ success: true, data: [{ id: 'p143', quote_id: 'Q' + ++n, price: 1500, stock: 3 }] }) });
  const u = mkUser(), o = await make(u); await pay(o, u); assert.equal(orders()[0].params.quote_id, 'Q2'); assert.equal(n, 2);
});
test('server premium: operator ikut dikirim (bawaan any); server lain tanpa operator', async () => {
  const u = mkUser(), a = await make(u, { server: 'premium', operator: 'telkomsel' }); await pay(a, u); assert.deepEqual(orders()[0].params, { quote_id: 'q143', operator: 'telkomsel' }); assert.equal(row(a.id).server, 'premium');
  const b = await make(u, { server: 'premium', product_id: 'p142', price: 20700 }); calls = []; await pay(b, u); assert.deepEqual(orders()[0].params, { quote_id: 'q142', operator: 'any' });
});
test('REFUND saat memproses: produk hilang / stok habis / harga penyedia naik melebihi bayaran / katalog gangguan -> refund_needed TANPA order', async () => {
  for (const [name, h] of [['hilang', () => ({ success: true, data: [] })], ['habis', () => ({ success: true, data: [{ id: 'p143', quote_id: 'x', price: 1500, stock: 0 }] })], ['naik', () => ({ success: true, data: [{ id: 'p143', quote_id: 'x', price: 5000, stock: 3 }] })]]) {
    const u = mkUser(), o = await make(u); handler = base({ products: h }); nokos._reset(); const v = await pay(o, u); assert.equal(v.status, 'refund_needed', name); handler = base(); nokos._reset();
  }
  assert.equal(orders().length, 0, 'tidak pernah memesan');
  const u = mkUser(), o = await make(u); handler = (path, p) => { if (path === '/api/nokos/products') throw E(502, 'down'); return base()(path, p); }; const v = await pay(o, u); assert.equal(v.status, 'refund_needed'); assert.match(v.note, /Katalog/); assert.equal(orders().length, 0);
});
test('harga penyedia turun/tetap tetap diproses selama <= yang dibayar pelanggan (margin aman)', async () => {
  const u = mkUser(), o = await make(u); handler = base({ products: () => ({ success: true, data: [{ id: 'p143', quote_id: 'qq', price: 1700, stock: 3 }] }) }); nokos._reset(); assert.equal((await pay(o, u)).status, 'waiting_otp'); assert.equal(orders()[0].params.quote_id, 'qq');
});
test('OTP: status COMPLETED + otpCode -> done; kode & pesan tersimpan TERENKRIPSI, tampil ke pemilik', async () => {
  const u = mkUser(), o = await make(u); await pay(o, u);
  handler = base({ status: () => ({ success: true, data: { _id: 'NOKOSa1b2', phoneNumber: '+6281234567890', status: 'COMPLETED', otpCode: '123456', otpMessage: 'Kode verifikasi WhatsApp kamu: 123456' } }) });
  nokos._reset(); const v = await nokos.view(u.id, o.id);
  assert.equal(v.status, 'done'); assert.equal(v.otp, '123456'); assert.match(v.otp_text, /123456/); const r = row(o.id); assert.ok(r.otp_code && r.otp_code !== '123456' && dec(r.otp_code) === '123456', 'terenkripsi di database');
  assert.equal((await nokos.listOwn(u.id))[0].otp, undefined, 'daftar riwayat tidak membawa OTP');
});
test('polling status dibatasi 1x per 4 detik per pesanan (aturan polling Averpay)', async () => {
  const u = mkUser(), o = await make(u); await pay(o, u); const n0 = calls.filter((c) => c.path === '/api/nokos/status').length;
  await nokos.view(u.id, o.id); await nokos.view(u.id, o.id); await nokos.view(u.id, o.id);
  assert.equal(calls.filter((c) => c.path === '/api/nokos/status').length - n0, 1);
});
test('REFUND: nomor EXPIRED/CANCELED tanpa OTP -> refund_needed (dana pembeli dikembalikan admin), bukan done', async () => {
  const u = mkUser(), o = await make(u); await pay(o, u);
  handler = base({ status: () => ({ success: true, data: { _id: 'NOKOSa1b2', status: 'EXPIRED' } }) }); nokos._reset();
  const v = await nokos.view(u.id, o.id); assert.equal(v.status, 'refund_needed'); assert.match(v.note, /OTP/); assert.equal(orders().length, 1);
});
test('REFUND: Averpay menolak order dengan jelas (4xx, mis. stok habis) -> refund_needed tanpa retry; sirkuit terbuka juga', async () => {
  const u = mkUser(), o = await make(u); handler = base({ order: () => { throw E(400, 'x', { public: 'Stok nomor habis' }); } });
  const v = await pay(o, u); assert.equal(v.status, 'refund_needed'); assert.equal(v.note, 'Stok nomor habis'); assert.equal(orders().length, 1);
});
test('saldo Averpay belum masuk setelah deposit -> dicoba ulang sampai berhasil (tanpa membeli ganda)', async () => {
  const u = mkUser(), o = await make(u); let k = 0; handler = base({ order: () => { if (++k < 3) throw E(400, 'x', { public: 'Saldo tidak cukup' }); return { success: true, data: { _id: 'N9', phoneNumber: '+62811', status: 'ACTIVE' } }; } });
  const v = await pay(o, u); assert.equal(v.status, 'waiting_otp'); assert.equal(orders().length, 3); assert.equal(row(o.id).provider_id, 'N9');
});
test('HASIL TAK PASTI: timeout/5xx -> review, TIDAK diulang (bisa terbeli ganda), tidak ada OTP palsu', async () => {
  const u = mkUser(), o = await make(u); handler = base({ order: () => { throw E(500, 'boom'); } });
  const v = await pay(o, u); assert.equal(v.status, 'review'); assert.equal(orders().length, 1);
  handler = base(); await nokos.view(u.id, o.id); await nokos.pollPending(); assert.equal(orders().length, 1, 'tidak dikirim ulang otomatis');
  const w = await nokos.view(u.id, (await make(u)).id); assert.equal(w.status, 'awaiting_payment');
});
test('respons tanpa ID pesanan -> review (saldo mungkin terpotong), bukan waiting_otp', async () => {
  const u = mkUser(), o = await make(u); handler = base({ order: () => ({ success: true, data: { status: 'ACTIVE' } }) });
  assert.equal((await pay(o, u)).status, 'review');
});
test('klaim atomik: webhook + polling bersamaan hanya membeli SATU nomor', async () => {
  const u = mkUser(), o = await make(u); gw[row(o.id).invoice_id] = 'paid'; const rows = [row(o.id), row(o.id), row(o.id)];
  await Promise.all(rows.map((r) => nokos.refresh(r))); assert.equal(orders().length, 1);
});
test('pembayaran terlambat (QRIS sudah kedaluwarsa tapi uang masuk) tetap diproses', async () => {
  const u = mkUser(), o = await make(u); R("UPDATE nokos_orders SET status='expired' WHERE id=?", [o.id]); gw[row(o.id).invoice_id] = 'paid';
  await nokos.late(row(o.id)); assert.equal(row(o.id).status, 'waiting_otp'); assert.equal(orders().length, 1);
});
test('keamanan: pesanan milik user lain tidak bisa dilihat/dibatalkan/dihapus', async () => {
  const a = mkUser(), b = mkUser(), o = await make(a);
  assert.equal(await nokos.view(b.id, o.id), null); assert.equal((await nokos.cancel(b.id, o.id)).code, 404); assert.equal(await nokos.hide(b.id, o.id), false);
});
test('batal sebelum bayar -> cancelled; setelah bayar tidak bisa dibatalkan', async () => {
  const u = mkUser(), o = await make(u); assert.equal((await nokos.cancel(u.id, o.id)).code, 200); assert.equal(row(o.id).status, 'cancelled');
  const p = await make(u), v = await pay(p, u); assert.equal(v.status, 'waiting_otp'); assert.equal((await nokos.cancel(u.id, p.id)).code, 409);
});
test('RIWAYAT: hapus per pesanan & massal hanya status akhir; pesanan berjalan tidak ikut; data tetap tersimpan', async () => {
  const u = mkUser(), a = await make(u); handler = base({ status: () => ({ success: true, data: { status: 'COMPLETED', otpCode: '5555' } }) }); await pay(a, u); await nokos.view(u.id, a.id); assert.equal(row(a.id).status, 'done');
  const b = await make(u, { product_id: 'p142', price: 20700 }); assert.equal(await nokos.hide(u.id, b.id), false, 'menunggu bayar tidak bisa dihapus');
  assert.equal(await nokos.hideAll(u.id + 99), 0); assert.equal(await nokos.hideAll(u.id), 1); assert.equal(row(a.id).hidden, 1); assert.ok(row(a.id).otp_code); assert.equal(row(b.id).hidden, 0);
});
test('ADMIN: ganti nomor (retry) hanya dari refund_needed; refunded/done manual; aksi lain ditolak', async () => {
  const u = mkUser(), o = await make(u); handler = base({ status: () => ({ success: true, data: { status: 'EXPIRED' } }) }); await pay(o, u); nokos._reset(); await nokos.view(u.id, o.id); assert.equal(row(o.id).status, 'refund_needed');
  handler = base({ order: () => ({ success: true, data: { _id: 'NOKOSbaru', phoneNumber: '+62899', status: 'ACTIVE' } }) });
  const r = await nokos.resolve(o.id, 'retry'); assert.equal(r.ok, true); assert.equal(r.status, 'waiting_otp'); assert.equal(row(o.id).provider_id, 'NOKOSbaru'); assert.equal(row(o.id).phone, '+62899');
  assert.equal((await nokos.resolve(o.id, 'retry')).ok, false, 'tidak dari status lain'); assert.equal((await nokos.resolve(o.id, 'refunded')).ok, false);
  R("UPDATE nokos_orders SET status='refund_needed' WHERE id=?", [o.id]); assert.equal((await nokos.resolve(o.id, 'refunded', 'transfer dana')).ok, true); assert.equal(row(o.id).status, 'refunded');
});
test('sweep: pesanan menunggu OTP > 45 menit & proses macet -> review (tidak menggantung selamanya)', async () => {
  const u = mkUser(), o = await make(u); await pay(o, u); R("UPDATE nokos_orders SET created_at='2020-01-01 00:00:00' WHERE id=?", [o.id]); await nokos.sweepStuck(); assert.equal(row(o.id).status, 'review');
});
test('ping kesehatan: sehat bila server, aplikasi, dan negara terbaca', async () => {
  assert.equal((await nokos.ping()).ok, true); nokos._reset(); handler = (p, q) => (p === '/api/nokos/services' ? { data: [] } : base()(p, q)); assert.equal((await nokos.ping()).ok, false);
});
test('OTP KEDUA: hanya setelah OTP pertama, maksimal sekali (POST /resend), otpCode2 tampil & terenkripsi', async () => {
  const u = mkUser(), o = await make(u); await pay(o, u);
  assert.equal((await nokos.resend(u.id, o.id)).code, 409, 'belum ada OTP pertama');
  handler = base({ status: () => ({ success: true, data: { _id: 'NOKOSa1b2', status: 'COMPLETED', otpCode: '111111' } }) }); nokos._reset(); const d = await nokos.view(u.id, o.id); assert.equal(d.status, 'done'); assert.equal(d.can_resend, true); assert.equal(d.otp2, undefined);
  assert.equal((await nokos.resend(u.id, o.id)).code, 200); const rs = calls.filter((c) => c.path === '/api/nokos/resend'); assert.equal(rs.length, 1); assert.equal(rs[0].method, 'POST'); assert.deepEqual(rs[0].params, { id: 'NOKOSa1b2' });
  assert.equal((await nokos.resend(u.id, o.id)).code, 409, 'maksimal sekali'); assert.equal(rs.length, 1);
  const w = await nokos.view(u.id, o.id); assert.equal(w.waiting_otp2, true); assert.equal(w.can_resend, false);
  handler = base({ status: () => ({ success: true, data: { _id: 'NOKOSa1b2', status: 'COMPLETED', otpCode: '111111', otpCode2: '222222' } }) }); nokos._reset(); const x = await nokos.view(u.id, o.id); assert.equal(x.otp2, '222222'); assert.equal(x.otp, '111111'); assert.ok(row(o.id).otp_code2 !== '222222' && dec(row(o.id).otp_code2) === '222222');
});
test('OTP kedua ditolak penyedia (4xx) -> boleh dicoba lagi; milik user lain -> 404', async () => {
  const u = mkUser(), o = await make(u); handler = base({ status: () => ({ success: true, data: { _id: 'N1', status: 'COMPLETED', otpCode: '1' } }) }); await pay(o, u); nokos._reset(); await nokos.view(u.id, o.id);
  handler = base({ status: () => ({ success: true, data: { _id: 'N1', status: 'COMPLETED', otpCode: '1' } }), resend: () => { throw E(400, 'x', { public: 'Belum bisa' }); } }); const r = await nokos.resend(u.id, o.id); assert.equal(r.code, 502); assert.equal(r.error, 'Belum bisa'); assert.equal(row(o.id).resend_at, null);
  handler = base(); assert.equal((await nokos.resend(u.id, o.id)).code, 200); assert.equal((await nokos.resend(mkUser().id, o.id)).code, 404);
});
test('ADMIN: batalkan nomor di penyedia (POST /cancel) hanya untuk nomor aktif -> refund_needed; ditolak penyedia -> status tidak berubah', async () => {
  const u = mkUser(), o = await make(u); await pay(o, u); assert.equal(row(o.id).status, 'waiting_otp');
  handler = base({ cancel: () => { throw E(400, 'x', { public: 'Minimal 120 detik' }); } }); const bad = await nokos.resolve(o.id, 'cancel_number'); assert.equal(bad.ok, false); assert.match(bad.error, /120/); assert.equal(row(o.id).status, 'waiting_otp');
  handler = base(); const ok = await nokos.resolve(o.id, 'cancel_number'); assert.equal(ok.ok, true); assert.equal(row(o.id).status, 'refund_needed'); const c = calls.filter((x) => x.path === '/api/nokos/cancel').pop(); assert.equal(c.method, 'POST'); assert.deepEqual(c.params, { id: 'NOKOSa1b2' });
  assert.equal((await nokos.resolve(o.id, 'cancel_number')).ok, false, 'tidak untuk status lain');
});
