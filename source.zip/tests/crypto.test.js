const test = require('node:test'), assert = require('node:assert/strict');
const fresh = () => { delete require.cache[require.resolve('../lib/crypto')]; return require('../lib/crypto'); };
const env = (o) => { for (const k of ['ENC_KEY', 'ENC_KEY_OLD', 'JWT_SECRET']) delete process.env[k]; Object.assign(process.env, o); };
test('enkripsi bolak-balik; ciphertext acak & tidak memuat teks asli', () => {
  env({ JWT_SECRET: 'j'.repeat(40) }); const { enc, dec } = fresh(); const a = enc('rahasia'), b = enc('rahasia');
  assert.equal(dec(a), 'rahasia'); assert.notEqual(a, b); assert.ok(!a.includes('rahasia'));
});
test('data lama (dienkripsi dengan JWT_SECRET) tetap terbaca setelah ENC_KEY baru diisi', () => {
  env({ JWT_SECRET: 'j'.repeat(40) }); const old = fresh().enc('data lama'); env({ JWT_SECRET: 'j'.repeat(40), ENC_KEY: 'k'.repeat(40) });
  const c = fresh(); assert.equal(c.dec(old), 'data lama'); assert.equal(c.dec(c.enc('data baru')), 'data baru');
});
test('mengganti JWT_SECRET TIDAK merusak data yang dienkripsi dengan ENC_KEY', () => {
  env({ JWT_SECRET: 'a'.repeat(40), ENC_KEY: 'k'.repeat(40) }); const x = fresh().enc('akun premium'); env({ JWT_SECRET: 'z'.repeat(40), ENC_KEY: 'k'.repeat(40) });
  assert.equal(fresh().dec(x), 'akun premium');
});
test('rotasi ENC_KEY: kunci lama lewat ENC_KEY_OLD masih bisa membuka data', () => {
  env({ JWT_SECRET: 'a'.repeat(40), ENC_KEY: 'old'.repeat(15) }); const x = fresh().enc('data'); env({ JWT_SECRET: 'z'.repeat(40), ENC_KEY: 'new'.repeat(15), ENC_KEY_OLD: 'old'.repeat(15) });
  assert.equal(fresh().dec(x), 'data');
});
test('kunci salah / data rusak / diubah-ubah -> null (bukan crash, bukan data palsu)', () => {
  env({ JWT_SECRET: 'a'.repeat(40) }); const { enc, dec } = fresh(); const x = enc('data'); const [iv, tag, b] = x.split('.');
  assert.equal(dec(`${iv}.${tag}.${Buffer.from('xxxx').toString('base64')}`), null); assert.equal(dec('bukan.format'), null); assert.equal(dec(''), null); assert.equal(dec(null), null);
  env({ JWT_SECRET: 'q'.repeat(40) }); assert.equal(fresh().dec(x), null);
});
