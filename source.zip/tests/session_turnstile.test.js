const test = require('node:test'), assert = require('node:assert/strict');
const { mockModules } = require('./helpers');
Object.assign(process.env, { JWT_SECRET: 's'.repeat(40), NODE_ENV: 'production' });
let signed, verified; // library jsonwebtoken tidak ter-install di sandbox: dimock untuk memeriksa PARAMETER yang dikirim lib/session.js (kebenaran library sendiri dipercaya)
mockModules({ jsonwebtoken: { sign: (payload, secret, opts) => { signed = { payload, secret, opts }; return 'TOKEN.JWT.X'; }, verify: (tok, secret, opts) => { verified = { tok, secret, opts }; if (tok === 'bad') throw new Error('invalid'); return { uid: 7, pv: 3, iat: 1 }; } } });
const session = require('../lib/session'), turnstile = require('../lib/turnstile');
test('sesi: cookie httpOnly, secure di produksi, sameSite lax, berlaku 30 hari; clearOpt tanpa maxAge', () => {
  const o = session.cookieOpt(); assert.equal(o.httpOnly, true); assert.equal(o.secure, true); assert.equal(o.sameSite, 'lax'); assert.equal(o.maxAge, 30 * 864e5); assert.equal(o.path, '/'); assert.ok(!('maxAge' in session.clearOpt()));
});
test('sesi: JWT ditandatangani HS256 dengan JWT_SECRET, berisi uid & pv saja, kedaluwarsa 30 hari', () => {
  session.sign(7, 3); assert.deepEqual(signed.payload, { uid: 7, pv: 3 }); assert.equal(signed.secret, process.env.JWT_SECRET); assert.equal(signed.opts.algorithm, 'HS256'); assert.equal(signed.opts.expiresIn, '30d');
  session.sign(9); assert.equal(signed.payload.pv, 0);
});
test('sesi: verifikasi hanya menerima algoritma HS256 (anti alg-confusion); token buruk melempar error', () => {
  assert.equal(session.verify('abc').uid, 7); assert.deepEqual(verified.opts.algorithms, ['HS256']); assert.equal(verified.secret, process.env.JWT_SECRET);
  assert.throws(() => session.verify('bad')); session.verify(undefined); assert.equal(verified.tok, '');
});
test('sesi geser: diperpanjang hanya bila sudah >24 jam sejak diterbitkan (tidak menulis cookie di tiap request)', () => {
  const now = 2_000_000_000; assert.equal(session.shouldRenew({ iat: now - 3600 }, now), false); assert.equal(session.shouldRenew({ iat: now - 86400 - 5 }, now), true); assert.equal(session.shouldRenew({ iat: now - 20 * 86400 }, now), true); assert.equal(session.shouldRenew(null, now), false); assert.equal(session.shouldRenew({}, now), true);
  let set; session.issue({ cookie: (n, v, o) => { set = { n, v, o }; } }, 5, 2); assert.equal(set.n, 'sid'); assert.equal(set.v, 'TOKEN.JWT.X'); assert.equal(set.o.maxAge, 30 * 864e5); assert.equal(signed.payload.pv, 2);
});
const env = (o) => { delete process.env.TURNSTILE_SITE; delete process.env.TURNSTILE_SECRET; Object.assign(process.env, o); };
const fakeFetch = (resp, spy) => async (url, o) => { if (spy) spy.push({ url, body: String(o.body) }); if (resp === 'down') throw new Error('net'); return { json: async () => resp }; };
test('turnstile: nonaktif bila salah satu kunci kosong (tidak memblokir login)', async () => {
  env({}); assert.equal(turnstile.enabled(), false); assert.equal((await turnstile.verify('', '1.1.1.1')).ok, true);
  env({ TURNSTILE_SITE: 's' }); assert.equal(turnstile.enabled(), false); assert.equal(turnstile.siteKey(), null);
});
test('turnstile aktif: token kosong/terlalu panjang ditolak tanpa menghubungi Cloudflare; token valid lolos', async () => {
  env({ TURNSTILE_SITE: 'site', TURNSTILE_SECRET: 'sec' }); const spy = []; assert.equal(turnstile.siteKey(), 'site');
  for (const t of [undefined, '', null, 123, 'a'.repeat(3000)]) assert.deepEqual(await turnstile.verify(t, '1.1.1.1', { fetchFn: fakeFetch({ success: true }, spy) }), { ok: false, reason: 'missing' });
  assert.equal(spy.length, 0);
  const r = await turnstile.verify('tok123', '9.9.9.9', { fetchFn: fakeFetch({ success: true }, spy) }); assert.equal(r.ok, true);
  assert.match(spy[0].url, /challenges\.cloudflare\.com\/turnstile\/v0\/siteverify/); assert.match(spy[0].body, /secret=sec/); assert.match(spy[0].body, /response=tok123/); assert.match(spy[0].body, /remoteip=9\.9\.9\.9/);
});
test('turnstile aktif: ditolak Cloudflare -> gagal; Cloudflare tidak terjangkau -> gagal (fail-closed)', async () => {
  env({ TURNSTILE_SITE: 'site', TURNSTILE_SECRET: 'sec' });
  const a = await turnstile.verify('t', '1.1.1.1', { fetchFn: fakeFetch({ success: false, 'error-codes': ['invalid-input-response'] }) }); assert.equal(a.ok, false); assert.equal(a.reason, 'rejected');
  assert.equal((await turnstile.verify('t', '1.1.1.1', { fetchFn: fakeFetch('down') })).reason, 'unreachable'); assert.equal((await turnstile.verify('t', '1.1.1.1', { fetchFn: fakeFetch({}) })).ok, false);
});

test('cookie sesi: produksi+HTTPS memakai awalan __Host-, nama lama tetap terbaca saat transisi dan dihapus saat login ulang', () => {
  const old = { n: process.env.NODE_ENV, a: process.env.APP_URL };
  try {
    process.env.NODE_ENV = 'production'; process.env.APP_URL = 'https://toko.example';
    assert.equal(session.name(), '__Host-sid'); assert.equal(session.cookieOpt().secure, true); assert.equal(session.cookieOpt().path, '/'); assert.equal('domain' in session.cookieOpt(), false, '__Host- dilarang memakai Domain');
    assert.equal(session.read({ cookies: { '__Host-sid': 'baru', sid: 'lama' } }), 'baru'); assert.equal(session.read({ cookies: { sid: 'lama' } }), 'lama'); assert.equal(session.read({}), undefined);
    const sets = [], clears = []; session.issue({ cookie: (n) => sets.push(n), clearCookie: (n) => clears.push(n) }, 1, 0); assert.deepEqual(sets, ['__Host-sid']); assert.deepEqual(clears, ['sid']);
    const c2 = []; session.clear({ clearCookie: (n) => c2.push(n) }); assert.deepEqual(c2.sort(), ['__Host-sid', 'sid']);
    process.env.APP_URL = 'http://lokal'; assert.equal(session.name(), 'sid', 'tanpa HTTPS: awalan __Host- tidak dipakai (browser akan menolaknya)');
  } finally { process.env.NODE_ENV = old.n; process.env.APP_URL = old.a; }
});
