const test = require('node:test'), assert = require('node:assert/strict'), fs = require('fs'), os = require('os'), path = require('path');
const { removeStale, STALE } = require('../lib/cleanup');
test('removeStale: hapus file lama yang bentrok/tak terpakai, file lain tidak disentuh, aman dijalankan berulang', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'sn-')); for (const d of ['pages', 'public', 'components']) fs.mkdirSync(path.join(root, d));
  for (const f of STALE) { const q = path.join(root, f); if (f === 'deploy') { fs.mkdirSync(path.join(q, 'sub'), { recursive: true }); fs.writeFileSync(path.join(q, 'sub/a.txt'), 'x'); } else fs.writeFileSync(q, 'x'); } fs.writeFileSync(path.join(root, 'pages/robots-txt.js'), 'keep'); fs.writeFileSync(path.join(root, 'public/manifest.webmanifest'), 'keep');
  assert.deepEqual(removeStale(root).sort(), [...STALE].sort());
  for (const f of STALE) assert.equal(fs.existsSync(path.join(root, f)), false);
  assert.ok(fs.existsSync(path.join(root, 'pages/robots-txt.js')) && fs.existsSync(path.join(root, 'public/manifest.webmanifest')));
  assert.deepEqual(removeStale(root), []);
});
