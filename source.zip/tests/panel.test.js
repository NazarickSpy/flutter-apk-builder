// Panel Hosting Averpay: parsing katalog, filter 1-10 GB, harga jual, order & status (format respons mengikuti docs resmi Averpay)
const test = require('node:test'), assert = require('node:assert/strict'), { mockModules } = require('./helpers');
let calls = [], handler = () => ({ success: true, data: [] }), cfgMap = {};
const restore = mockModules({ './averpay': { get: async (path, params) => { calls.push({ path, params }); const r = handler(path, params); if (r instanceof Error) throw r; return r; }, flat: (j) => (j && j.data && typeof j.data === 'object' && !Array.isArray(j.data) ? { ...j, ...j.data } : j || {}) }, './settings': { get: async (k, d = '') => (k in cfgMap ? cfgMap[k] : d) } });
const panel = require('../lib/panel'); restore();
const PANELS = { success: true, data: [{ id: 'P1', name: 'Panel Node 1', domain: 'panel.contoh.com' }, { id: 'P2', name: 'Cadangan', domain: 'p2.contoh.com' }] };
const PKGS = { success: true, data: [
  { id: 'K1', name: 'Paket Bronze', ram: 1024, disk: 2048, cpu: 50, price: 15000 }, { id: 'K10', name: 'Paket Max', ram: 10240, disk: 20480, cpu: 150, price: 90000 },
  { id: 'KU', name: 'Unlimited', ram: 0, disk: 0, cpu: 0, price: 120000 }, { id: 'K11', name: 'Terlalu besar', ram: 11264, disk: 1, cpu: 1, price: 99000 }, { id: 'K0', name: 'Gratis', ram: 2048, disk: 1, cpu: 1, price: 0 }, { id: 'KM', name: 'Tengah', ram: 4096, disk: 8192, cpu: 100, price: 40000, days: 30 }] };
test.beforeEach(() => { calls = []; cfgMap = {}; panel._reset(); handler = (p) => (p === '/api/pterodactyl/panels' ? PANELS : PKGS); });

test('katalog: hanya RAM 1-10 GB (unlimited/0/di atas 10 GB/harga 0 dibuang), urut RAM, modal TIDAK ikut ke pelanggan', async () => {
  const l = await panel.list(); assert.deepEqual(l.map((p) => p.key), ['K1', 'KM', 'K10']);
  assert.ok(l.every((p) => !('cost' in p) && p.price > 0)); assert.equal(l[1].days, 30); assert.equal(l[0].memory, 1024);
  assert.equal(calls.find((c) => c.path === '/api/pterodactyl/packages').params.panel_id, 'P1', 'memakai server panel pertama');
});
test('harga jual = modal + margin (min Rp1000 / 15%), selalu > modal, kelipatan Rp100; pengaturan admin berlaku', async () => {
  let l = await panel.list(); assert.equal(l[0].price, 17300); assert.ok(l.every((p, i) => p.price > [15000, 40000, 90000][i] && p.price % 100 === 0));
  panel._reset(); cfgMap = { panel_margin_pct: '0', panel_margin_min: '2000' }; l = await panel.list(); assert.equal(l[0].price, 17000);
});
test('AVERPAY_PANEL_ID / pengaturan memilih server panel tertentu; tidak ketemu -> galat jelas', async () => {
  cfgMap = { panel_id: 'P2' }; await panel.list(); assert.equal(calls.find((c) => c.path === '/api/pterodactyl/packages').params.panel_id, 'P2');
  panel._reset(); cfgMap = { panel_id: 'NOPE' }; assert.deepEqual(await panel.list(), []); await assert.rejects(panel.catalog(), (e) => /tidak ditemukan/.test(e.message) && /tidak tersedia/.test(e.public));
});
test('Averpay gangguan: katalog terakhir dipakai (stale) maks 30 menit, bukan kosong', async () => {
  await panel.catalog(); handler = () => new Error('down'); const c = await panel.catalog({ maxAge: 0 }); assert.equal(c.stale, true); assert.equal(c.items.length, 3);
});
test('order: parameter sesuai docs (panel_id, package_id, username, email, password) dan respons resmi terbaca', async () => {
  handler = (p) => (p === '/api/pterodactyl/panels' ? PANELS : { success: true, data: { _id: 'PTEROa1b2', panelName: 'Panel Node 1', packageName: 'Paket Bronze', ram: 1024, disk: 2048, cpu: 50, price: 15000, panelUsername: 'budi123ab12', panelPassword: 'Xy7dK2pqAa1!', panelEmail: 'budi@gmail.com', status: 'ACTIVE', expiresAt: '2026-11-01T10:00:00.000Z' } });
  const r = await panel.order({ package_id: 'K1', username: 'budi123', email: 'budi@gmail.com', password: 'RahasiaAman1' });
  const c = calls.find((x) => x.path === '/api/pterodactyl/order'); assert.deepEqual(c.params, { panel_id: 'P1', package_id: 'K1', username: 'budi123', email: 'budi@gmail.com', password: 'RahasiaAman1' });
  assert.equal(r.id, 'PTEROa1b2'); assert.equal(r.username, 'budi123ab12'); assert.equal(r.password, 'Xy7dK2pqAa1!'); assert.equal(r.cost, 15000); assert.equal(r.panel_domain, 'https://panel.contoh.com'); assert.equal(panel.verdict(r.status), 'ok'); assert.equal(r.expires_at, '2026-11-01T10:00:00.000Z');
});
test('status panel & verdict: ACTIVE ok; FAILED/CANCELED/EXPIRED gagal; selain itu menunggu', async () => {
  assert.deepEqual(['ACTIVE', 'SUCCESS', 'PENDING', 'FAILED', 'CANCELED', 'XYZ', ''].map(panel.verdict), ['ok', 'ok', 'wait', 'bad', 'bad', 'wait', 'wait']);
  handler = () => ({ success: true, data: { _id: 'PTERO1', status: 'ACTIVE', panelUsername: 'u1' } }); const s = await panel.status('PTERO1'); assert.equal(s.username, 'u1'); assert.equal(calls[0].params.id, 'PTERO1');
});
test('username panel: dibersihkan ke huruf/angka/underscore, 3-14 karakter', () => {
  assert.equal(panel.cleanUser('Budi.Santoso-123 x'), 'BudiSantoso123'); assert.equal(panel.cleanUser('a'), 'asnowy'); assert.equal(panel.validUser('abc_123'), true); assert.equal(panel.validUser('ab'), false); assert.equal(panel.validUser('a'.repeat(15)), false); assert.equal(panel.validUser('ab c'), false);
});
test('health: ping sehat bila ada paket; kosong -> tidak ok', async () => {
  assert.equal((await panel.ping()).ok, true); panel._reset(); handler = (p) => (p === '/api/pterodactyl/panels' ? PANELS : { success: true, data: [] }); assert.equal((await panel.ping()).ok, false);
});
