const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), os = require('node:os');
const { mockModules } = require('./helpers'), { makePool } = require('./dbshim');
process.env.JWT_SECRET = 'x'.repeat(40);
const pool = makePool(); mockModules({ './db': { pool } });
const health = require('../lib/health'), backup = require('../lib/backup'), settings = require('../lib/settings'), premium = require('../lib/premium');
const R = (s, p) => pool._run(s, p)[0];
const put = (key, arr) => health._hist.set(key, arr.map(([ok, ms, d], i) => ({ t: Date.now() - (arr.length - i) * 20e3, ok, ms, d: !!d })));
test.beforeEach(() => { health._hist.clear(); R('DELETE FROM settings'); settings._clear(); for (const c of health.COMPONENTS) put(c.key, [[true, 30], [true, 40], [true, 35]]); });

test('STATUS: semua komponen sehat -> operational; uptime & rata-rata latensi dihitung dari riwayat', async () => {
  const s = await health.snapshot(); assert.equal(s.overall, 'operational'); const db = s.components.find((c) => c.key === 'db'); assert.equal(db.state, 'operational'); assert.equal(db.uptime, 100); assert.equal(db.avg_ms, 35); assert.equal(db.ticks.length, 3);
  assert.equal(s.services.panel.state, 'operational'); assert.equal(s.services.premium.state, 'operational');
});
test('STATUS: komponen gagal -> outage; lambat atau katalog usang -> degraded; uptime turun; insiden terakhir tercatat', async () => {
  put('gateway', [[true, 50], [false, 6000], [false, 6000]]); put('db', [[true, 6000]]); put('catalog', [[true, 100, true]]);
  const s = await health.snapshot(), by = Object.fromEntries(s.components.map((c) => [c.key, c]));
  assert.equal(by.gateway.state, 'outage'); assert.equal(by.gateway.uptime, 33.3); assert.ok(by.gateway.last_issue); assert.equal(by.db.state, 'degraded'); assert.equal(by.catalog.state, 'degraded'); assert.equal(s.overall, 'outage');
  put('gateway', [[false, 1], [true, 50]]); assert.equal(by.gateway.state, 'outage', 'snapshot lama tidak berubah'); assert.equal((await health.snapshot()).components.find((c) => c.key === 'gateway').state, 'operational', 'pulih otomatis begitu sampel terbaru sehat');
});
test('STATUS: ketersediaan LAYANAN = saklar admin + kesehatan komponen yang dibutuhkan masing-masing', async () => {
  put('ptero', [[false, 6000]]); let s = await health.snapshot(); assert.equal(s.services.panel.state, 'outage'); assert.equal(s.services.premium.state, 'operational', 'premium tidak bergantung pada server panel'); assert.equal(s.services.garansi.state, 'operational', 'portal garansi tidak lagi bergantung pada panel eksternal');
  put('ptero', [[true, 30]]); put('catalog', [[false, 6000]]); s = await health.snapshot(); assert.equal(s.services.premium.state, 'outage'); assert.equal(s.services.panel.state, 'operational');
  put('catalog', [[true, 30]]); R("INSERT INTO settings(k,v) VALUES('svc_premium','0')"); R("INSERT INTO settings(k,v) VALUES('svc_premium_msg','Stok sedang diisi')"); settings._clear();
  s = await health.snapshot(); assert.deepEqual(s.services.premium, { state: 'off', msg: 'Stok sedang diisi' }); assert.equal(s.services.panel.state, 'operational');
  R("INSERT INTO settings(k,v) VALUES('maintenance','1')"); settings._clear(); s = await health.snapshot(); assert.equal(s.overall, 'maintenance'); assert.equal(s.services.panel.state, 'maintenance');
});
test('STATUS: antrean pesanan dihitung; belum ada data -> unknown (bukan "normal" palsu)', async () => {
  R("INSERT INTO users(username) VALUES('q')"); R("INSERT INTO orders(user_id,package_key,price,server_name,pay_status,status) VALUES(1,'1gb',1,'a','paid','failed')"); R("INSERT INTO premium_orders(user_id,ref,product_id,product_name,cost,price,status) VALUES(1,'Q1','4','x',1,1,'processing')");
  let s = await health.snapshot(); assert.equal(s.queue.panel, 1); assert.equal(s.queue.premium, 1);
  health._hist.clear(); s = await health.snapshot(); assert.equal(s.overall, 'unknown'); assert.ok(s.components.every((c) => c.state === 'unknown' && c.uptime === null));
});
test('CADANGAN: berkas terenkripsi (tanpa data polos), izin 0600, bisa dibaca kembali utuh dengan kunci yang sama, data akun premium ikut tersimpan', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk-')); const { run, decode, DIR } = backup; assert.ok(DIR.endsWith('backups'));
  const u = R('INSERT INTO users(username,email) VALUES(?,?)', ['rahasiauser', 'rahasia@mail.com']).insertId; const enc = require('../lib/crypto').enc;
  R("INSERT INTO premium_orders(user_id,ref,product_id,product_name,cost,price,status,result) VALUES(?,?,?,?,?,?,?,?)", [u, 'BK1', '4', 'Capcut', 1, 1, 'done', enc('[["email","akun@x.y"]]')]);
  const fsReal = fs.mkdirSync; const r = await run(); try {
    const raw = fs.readFileSync(r.file, 'utf8'); assert.ok(!raw.includes('rahasiauser') && !raw.includes('rahasia@mail.com') && !raw.includes('Capcut'), 'cadangan tidak boleh berisi data polos');
    assert.equal(fs.statSync(r.file).mode & 0o777, 0o600); const d = decode(r.file); assert.equal(d.version, 1);
    assert.ok(d.tables.users.some((x) => x.username === 'rahasiauser')); const po = d.tables.premium_orders.find((x) => x.ref === 'BK1'); assert.equal(po.product_name, 'Capcut'); assert.ok(po.result && !po.result.includes('akun@x.y'), 'data akun tetap terenkripsi di dalam cadangan');
    assert.ok(backup.latestAge() < 5000); assert.ok(!('qr_image' in (d.tables.orders[0] || {})), 'kolom QR tidak ikut dicadangkan');
  } finally { fs.rmSync(r.file, { force: true }); void fsReal; void dir; }
});
