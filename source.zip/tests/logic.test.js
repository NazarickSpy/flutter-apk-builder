const test = require('node:test'), assert = require('node:assert/strict'), { mockModules } = require('./helpers');
const restore = mockModules({ './db': { pool: {} }, './ptero': {}, './packages': {}, './artan': {}, './averpay': {} });
const order = require('../lib/order'), warranty = require('../lib/warranty'); restore();
test('state() memetakan status pembayaran + server ke status yang tampil di UI', () => {
  const s = (pay_status, status) => order.state({ pay_status, status });
  assert.equal(s('pending', 'pending'), 'unpaid'); assert.equal(s('expired', 'pending'), 'expired'); assert.equal(s('cancelled', 'pending'), 'cancelled');
  assert.equal(s('paid', 'pending'), 'processing'); assert.equal(s('paid', 'processing'), 'processing'); assert.equal(s('paid', 'active'), 'active'); assert.equal(s('paid', 'failed'), 'failed');
});
test('maksimal percobaan provisioning = 8', () => assert.equal(order.MAXTRY, 8));
test('garansi: kelayakan sesuai masa, kuota, dan klaim berjalan', () => {
  process.env.WARRANTY_DAYS = '30'; const D = 864e5, now = Date.now();
  const o = { status: 'active', pay_status: 'paid', claims_used: 0, created_at: new Date(now - 10 * D), activated_at: new Date(now - 10 * D) };
  assert.equal(warranty.info(o, false).eligible, true);
  assert.equal(warranty.info({ ...o, activated_at: new Date(now - 31 * D) }, false).eligible, false);
  assert.equal(warranty.info({ ...o, claims_used: 1 }, false).eligible, false);
  assert.equal(warranty.info(o, true).eligible, false);
  assert.equal(warranty.info({ ...o, status: 'failed' }, false).eligible, false);
});
test('normalisasi nomor WhatsApp untuk verifikasi garansi', () => {
  assert.equal(warranty.normWa('+62 812-3456-7890'), '081234567890'); assert.equal(warranty.normWa('81234567890'), '081234567890'); assert.equal(warranty.normWa('081234567890'), '081234567890');
});

// ---------- kompensasi waktu panel ----------
test('garansi + waktu tambahan: masa garansi = dasar + bonus; kedaluwarsa bergeser; tampil di ringkasan', () => {
  process.env.WARRANTY_DAYS = '30'; const D = 864e5, now = Date.now();
  const o = { status: 'active', pay_status: 'paid', claims_used: 0, created_at: new Date(now - 35 * D), activated_at: new Date(now - 35 * D) };
  assert.equal(warranty.info(o, false).eligible, false, 'tanpa bonus: sudah lewat 30 hari');
  const w = warranty.info({ ...o, bonus_days: 10 }, false); assert.equal(w.eligible, true); assert.equal(w.bonus, 10); assert.equal(w.base_days, 30); assert.equal(w.days, 40); assert.ok(w.days_left >= 4 && w.days_left <= 5);
  assert.equal(warranty.info({ ...o, bonus_days: -5 }, false).bonus, 0, 'bonus negatif diabaikan'); assert.equal(warranty.info({ ...o, bonus_days: 'abc' }, false).bonus, 0);
});
test('ADD_BONUS (SQL): menambah, dibatasi 730 hari, hanya panel aktif & terbayar', async () => {
  const { makePool } = require('./dbshim'); const pool = makePool(); const R = (s, p) => pool._run(s, p)[0];
  R("INSERT INTO users(username) VALUES('u')"); const mk = (pay, st, b) => R('INSERT INTO orders(user_id,package_key,price,server_name,pay_status,status,bonus_days) VALUES(1,?,?,?,?,?,?)', ['1gb', 1, 'a', pay, st, b]).insertId;
  const a = mk('paid', 'active', 0), b = mk('paid', 'active', 725), c = mk('pending', 'pending', 0), d = mk('paid', 'failed', 0);
  const r = R(`UPDATE orders SET ${warranty.ADD_BONUS} WHERE pay_status='paid' AND status='active'`, [10, 10]); assert.equal(r.affectedRows, 2);
  const g = (id) => R('SELECT bonus_days b FROM orders WHERE id=?', [id])[0].b; assert.equal(g(a), 10); assert.equal(g(b), 730, 'dibatasi 730'); assert.equal(g(c), 0); assert.equal(g(d), 0);
});

test('paket: hanya 1-10 GB yang dijual; unlimited tidak ada di daftar & tidak bisa dibeli, tapi data lama tetap terbaca', () => {
  const pk = require('../lib/packages');
  assert.deepEqual(pk.list.map((p) => p.key), ['1gb', '2gb', '3gb', '4gb', '5gb', '6gb', '7gb', '8gb', '9gb', '10gb']);
  assert.ok(pk.list.every((p) => p.memory > 0 && p.price === p.memory / 1024 * 1000));
  assert.equal(pk.sellable('unli'), undefined); assert.equal(pk.sellable('5gb').price, 5000); assert.equal(pk.get('unli').key, 'unli');
});
