const test = require('node:test'), assert = require('node:assert/strict');
const { mockModules } = require('./helpers'), { makePool } = require('./dbshim');
process.env.JWT_SECRET = 'x'.repeat(40);
const pool = makePool(); mockModules({ './db': { pool } });
const idem = require('../lib/idem')('panel'), averpay = require('../lib/averpay');
const mk = (key, body, uid = 1) => { const res = { statusCode: 200, headers: {}, sent: null, writableEnded: false, set(k, v) { this.headers[k] = v; }, status(c) { this.statusCode = c; return this; }, json(b) { this.sent = b; this.writableEnded = true; return this; }, on() {} }; return { req: { user: { id: uid }, body, get: (h) => (h.toLowerCase() === 'idempotency-key' ? key : undefined) }, res }; };
const run = async (key, body, handler, uid) => { const { req, res } = mk(key, body, uid); let ran = false; await idem(req, res, () => { ran = true; handler && handler(res); }); await new Promise((r) => setTimeout(r, 20)); return { ran, res }; };
const K = (n) => 'key-' + String(n).padStart(20, '0');
test.beforeEach(() => pool._run('DELETE FROM idem_keys'));
test('tanpa header: lewat normal; key rusak ditolak 400', async () => {
  assert.equal((await run(undefined, {}, null)).ran, true);
  const r = await run('pendek', {}, null); assert.equal(r.ran, false); assert.equal(r.res.statusCode, 400);
});
test('permintaan ulang dengan key sama memutar respons pertama (handler tidak jalan lagi)', async () => {
  const a = await run(K(1), { p: 1 }, (res) => res.status(200).json({ id: 7 })); assert.equal(a.ran, true);
  const b = await run(K(1), { p: 1 }, (res) => res.json({ id: 8 })); assert.equal(b.ran, false); assert.deepEqual(b.res.sent, { id: 7 }); assert.equal(b.res.headers['Idempotent-Replay'], 'true');
});
test('key sama tapi isi beda = 422; key sedang diproses = 409; kegagalan melepas key', async () => {
  await run(K(2), { p: 1 }, (res) => res.status(200).json({ ok: 1 }));
  assert.equal((await run(K(2), { p: 2 }, null)).res.statusCode, 422);
  const pending = await run(K(3), { p: 1 }, null); assert.equal(pending.ran, true); // belum merespons
  assert.equal((await run(K(3), { p: 1 }, null)).res.statusCode, 409);
  await run(K(4), { p: 1 }, (res) => res.status(400).json({ error: 'x' }));
  assert.equal((await run(K(4), { p: 1 }, (res) => res.status(200).json({ ok: 1 }))).ran, true); // boleh dicoba lagi
});
test('key dipisah per pengguna', async () => {
  await run(K(5), { p: 1 }, (res) => res.status(200).json({ u: 1 }), 1);
  const r = await run(K(5), { p: 1 }, (res) => res.status(200).json({ u: 2 }), 2); assert.equal(r.ran, true);
});
test('paidFor: lunas sah hanya bila nominal >= tagihan; tanpa total percaya status', () => {
  assert.equal(averpay.paidFor({ paid: true, total: 10500 }, 10500), true);
  assert.equal(averpay.paidFor({ paid: true, total: 10000 }, 10500), false);
  assert.equal(averpay.paidFor({ paid: true, total: null }, 10500), true);
  assert.equal(averpay.paidFor({ paid: false, total: 10500 }, 10500), false);
});
test('create menolak nominal di atas batas Averpay (Rp 1.000.000) atau tidak valid', async () => {
  await assert.rejects(averpay.create(1000001), (e) => /1\.000\.000/.test(e.public));
  await assert.rejects(averpay.create(0), (e) => !!e.public);
});
