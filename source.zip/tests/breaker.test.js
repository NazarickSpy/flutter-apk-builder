const test = require('node:test'), assert = require('node:assert/strict');
const { breaker } = require('../lib/breaker');
const boom = (status) => () => { const e = new Error('x'); if (status) e.status = status; return Promise.reject(e); };
test('sirkuit terbuka setelah 3 kegagalan beruntun lalu menolak cepat', async () => {
  let t = 0; const b = breaker('t', { threshold: 3, cooldown: 1000, now: () => t });
  for (let i = 0; i < 3; i++) await assert.rejects(b.run(boom(500)));
  assert.equal(b.state().open, true);
  let called = false; await assert.rejects(b.run(async () => { called = true; }), (e) => e.circuit === true && e.status === 503 && !!e.public);
  assert.equal(called, false, 'fungsi asli tidak boleh dipanggil saat sirkuit terbuka');
});
test('timeout/putus (tanpa status) dihitung gangguan; 4xx tidak', async () => {
  const b = breaker('t', { threshold: 2, cooldown: 1000 });
  await assert.rejects(b.run(boom(400))); await assert.rejects(b.run(boom(404))); await assert.rejects(b.run(boom(422)));
  assert.equal(b.state().open, false, '4xx tidak membuka sirkuit');
  await assert.rejects(b.run(boom())); await assert.rejects(b.run(boom()));
  assert.equal(b.state().open, true);
});
test('setelah cooldown 1 percobaan dilepas: sukses -> normal, gagal -> terbuka lagi', async () => {
  let t = 0; const b = breaker('t', { threshold: 2, cooldown: 1000, now: () => t });
  await assert.rejects(b.run(boom(500))); await assert.rejects(b.run(boom(500)));
  t = 1001; await assert.rejects(b.run(boom(500))); assert.equal(b.state().open, true, 'gagal saat half-open -> langsung terbuka lagi');
  t = 3000; assert.equal(await b.run(async () => 'ok'), 'ok'); assert.equal(b.state().open, false); assert.equal(b.state().fails, 0);
});
test('keberhasilan di tengah mereset hitungan', async () => {
  const b = breaker('t', { threshold: 3 });
  await assert.rejects(b.run(boom(500))); await assert.rejects(b.run(boom(500))); await b.run(async () => 1); await assert.rejects(b.run(boom(500)));
  assert.equal(b.state().open, false);
});
