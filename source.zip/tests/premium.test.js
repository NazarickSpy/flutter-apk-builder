const test = require('node:test'), assert = require('node:assert/strict'), { mockModules } = require('./helpers'), { makePool } = require('./dbshim');
process.env.JWT_SECRET = 'x'.repeat(40);
const pool = makePool();
let handler, calls = [], circuit = false, gw = {}, invN = 0, createFail = null;
// Contoh respons ASLI katalog Averpay (dari admin): array langsung, id integer, ada image & stock
const SAMPLE = [
  { id: 3, name: 'Canva Pro EDU Invite', description: 'CANVA EDU INVITE PAKAI EMAIL KAMU, AKTIF RANDOM TIDAK ADA BATAS WAKTU, GARANSI 1 BULAN.', image: 'https://cdn.premku.com/img/canva.png', stock: 34, price: 1150 },
  { id: 4, name: 'Capcut Pro 1 Minggu Private', description: 'PRO PLAN, 1 MINGGU RANDOM 4-7 HARI YA! NO GARANSI. LOGIN JANGAN BANYAK DEV CUKUP 1 AJA MAKSIMAL.', image: 'https://cdn.premku.com/img/capcut.png', stock: 8, price: 4370 }];
const fake = {
  get: async (path, params) => { calls.push({ path, params }); return handler(path, params || {}); },
  create: async (amount) => { calls.push({ path: 'create', amount }); if (createFail) throw createFail; const id = 'INV' + ++invN; return { transaction_id: id, total: amount + 500, qr_image: `https://qr.example/${id}.png`, expires_at: new Date(Date.now() + 15 * 60e3) }; },
  status: async (tx) => { if (gw[tx] === 'err') throw new Error('gateway down'); return { paid: gw[tx] === 'paid', expired: gw[tx] === 'expired' }; },
  breaker: () => ({ open: circuit, name: 'averpay' }), flat: (j) => j };
mockModules({ './db': { pool }, './averpay': fake });
const premium = require('../lib/premium'), settings = require('../lib/settings');
const CAPCUT = 4900, CANVA = 1700; // modal 4.370 / 1.150 + margin 10% (min Rp500), dibulatkan ke atas per Rp100
const E = (status, msg, extra) => Object.assign(new Error(msg || 'x'), { status, ...extra });
const R = (sql, p) => pool._run(sql, p)[0];
const mkUser = () => ({ id: R('INSERT INTO users(username,email) VALUES(?,?)', ['u' + Math.random(), 'a@b.c']).insertId });
const row = (id) => R('SELECT * FROM premium_orders WHERE id=?', [id])[0];
const base = (over = {}) => (path, p) => {
  if (path === '/api/premium/products') return over.products || SAMPLE;
  if (path === '/api/premium/stock') return { success: true, data: { stock: 5 } };
  if (path === '/api/balance') return { balance: 1e6 };
  if (path === '/api/premium/order') return over.order ? over.order(p) : { success: true, data: { id: 'TRX1', status: 'success', email: 'akun@mail.com', password: 'rahasia123' } };
  if (path === '/api/premium/status') return over.status ? over.status(p) : { success: true, data: { status: 'success', email: 'a@b.c', password: 'pw' } };
};
test.beforeEach(() => { calls = []; circuit = false; gw = {}; createFail = null; premium._reset(); handler = base(); R('DELETE FROM settings'); settings._clear(); });
const providerOrders = () => calls.filter((c) => c.path === '/api/premium/order');
const invoices = () => calls.filter((c) => c.path === 'create');
const make = (u, over = {}) => premium.create(u, { product_id: '4', qty: 1, price: CAPCUT, ...over });
const pay = async (o, u) => { gw[row(o.id).invoice_id] = 'paid'; return premium.view(u.id, o.id); };

test('katalog ASLI Averpay: array langsung, id integer -> string, gambar https, harga modal; produk "PAKAI EMAIL KAMU" ditandai', () => {
  const items = premium.listFrom(SAMPLE).map(premium.normProduct);
  assert.equal(items.length, 2); assert.deepEqual(items.map((x) => x.id), ['3', '4']); assert.equal(items[0].cost, 1150); assert.equal(items[0].stock, 34); assert.equal(items[0].image, 'https://cdn.premku.com/img/canva.png');
  assert.equal(items[0].needs_input, true, 'Canva invite butuh email pembeli'); assert.equal(items[1].needs_input, false);
  assert.equal(premium.normProduct({ id: 1, name: 'x', price: 100, image: 'http://insecure/x.png' }).image, null, 'hanya https'); assert.equal(premium.normProduct({ id: 1, name: 'x', price: 100, image: 'javascript:1' }).image, null);
});
test('normalisasi lain: bungkus data, harga format Indonesia, status penyedia', () => {
  assert.deepEqual(premium.listFrom({ data: { products: [{ a: 1 }] } }), [{ a: 1 }]); assert.equal(premium.normProduct({ _id: 'x', title: 'Spotify', harga: '15.000', stok: '3' }).cost, 15000);
  assert.equal(premium.normProduct({ id: 'a', name: 'n', price: 0 }), null); assert.equal(premium.parseStock({ data: 12 }), 12); assert.equal(premium.parseStock({}), null);
  assert.equal(premium.provStatus('SUCCESS'), 'ok'); assert.equal(premium.provStatus('Gagal'), 'bad'); assert.equal(premium.provStatus('pending'), 'wait'); assert.equal(premium.provStatus('xyz'), 'unknown'); assert.equal(premium.provStatus(''), 'none');
});
test('harga jual selalu di atas modal, dibulatkan ke atas per Rp100', () => {
  const c = { pct: 10, min: 500 }; assert.equal(premium.priceFor(4370, c), CAPCUT); assert.equal(premium.priceFor(1150, c), CANVA); assert.equal(premium.priceFor(10000, c), 11000);
  for (const cost of [1, 99, 1000, 54321]) assert.ok(premium.priceFor(cost, c) > cost);
});
test('entries(): data akun diratakan; kunci status/biaya/rahasia disaring', () => {
  const m = Object.fromEntries(premium.entries({ success: true, status: 'ok', price: 1, email: 'a@b.c', apikey: 'zzz', accounts: [{ user: 'u1', pass: 'p1' }] }));
  assert.equal(m.email, 'a@b.c'); assert.equal(m['accounts[1].user'], 'u1'); assert.ok(!('success' in m) && !('status' in m) && !('price' in m) && !('apikey' in m));
});

test('CREATE: QRIS dibuat sekali dengan nominal = harga jual; pesanan tercatat menunggu bayar; tidak ada panggilan order ke penyedia', async () => {
  const u = mkUser(), o = await make(u); assert.equal(o.status, 'awaiting_payment'); assert.equal(invoices().length, 1); assert.equal(invoices()[0].amount, CAPCUT);
  const r = row(o.id); assert.equal(r.price, CAPCUT); assert.equal(r.total, CAPCUT + 500); assert.equal(r.cost, 4370); assert.ok(r.qr_image.startsWith('https://qr.example/')); assert.equal(providerOrders().length, 0);
});
test('CREATE: klik ganda / refresh memakai pesanan yang sama (tidak ada QRIS dobel)', async () => {
  const u = mkUser(), a = await make(u), b = await make(u); assert.equal(a.id, b.id); assert.equal(invoices().length, 1);
});
test('CREATE: ditolak SEBELUM QRIS dibuat: produk tak dikenal, harga berubah, stok habis/kurang, saldo penyedia kurang, sirkuit terbuka, total > Rp1.000.000', async () => {
  const u = mkUser(); const h0 = handler;
  await assert.rejects(make(u, { product_id: '999' }), (e) => e.http === 404);
  await assert.rejects(make(u, { price: 1 }), (e) => e.http === 409 && e.price === CAPCUT);
  handler = (p, q) => (p === '/api/premium/stock' ? { stock: 0 } : h0(p, q)); await assert.rejects(make(u), (e) => e.http === 409);
  handler = (p, q) => (p === '/api/premium/stock' ? { stock: 1 } : h0(p, q)); await assert.rejects(make(u, { qty: 2, price: CAPCUT }), (e) => e.http === 409 && /Stok tersisa 1/.test(e.message));
  premium._reset(); handler = (p, q) => (p === '/api/balance' ? { balance: 100 } : h0(p, q)); const before = invoices().length; const lowBal = await make(u); assert.ok(lowBal.id, 'saldo Averpay rendah TIDAK memblokir: QRIS pelanggan itulah yang mengisi saldo sebelum order dikirim'); assert.equal(invoices().length, before + 1);
  premium._reset(); handler = h0; circuit = true; await assert.rejects(make(u), (e) => e.http === 503); circuit = false; premium._reset();
  handler = base({ products: [{ id: 9, name: 'Mahal', price: 400000, stock: 9 }] }); await assert.rejects(premium.create(u, { product_id: '9', qty: 5 }), (e) => e.http === 400 && /maksimal/i.test(e.message));
  assert.equal(invoices().length, 1, 'QRIS hanya dibuat untuk pesanan sah (kasus saldo rendah); semua penolakan lain tidak membuat QRIS');
});
test('CREATE: kegagalan gateway -> pesan jelas, tidak ada pesanan tersimpan; pesan validasi gateway diteruskan', async () => {
  const u = mkUser(); createFail = E(400, 'x', { public: 'Minimal deposit Rp 5.000' }); await assert.rejects(make(u), (e) => e.http === 400 && /Minimal deposit/.test(e.message));
  createFail = E(503, 'x', { circuit: true }); await assert.rejects(make(u), (e) => e.http === 503); createFail = new Error('boom'); await assert.rejects(make(u), (e) => e.http === 502);
  assert.equal(R('SELECT COUNT(*) n FROM premium_orders WHERE user_id=?', [u.id])[0].n, 0);
});
test('CREATE: produk butuh email pembeli disembunyikan sampai admin mengizinkan; setelah itu WAJIB email valid dan ikut dikirim ke penyedia', async () => {
  const u = mkUser(); await assert.rejects(make(u, { product_id: '3', price: CANVA }), (e) => e.http === 404, 'default: tidak dijual otomatis');
  R("INSERT INTO settings(k,v) VALUES('premium_allow','3')"); settings._clear();
  await assert.rejects(make(u, { product_id: '3', price: CANVA }), (e) => e.http === 400 && /email/i.test(e.message)); await assert.rejects(make(u, { product_id: '3', price: CANVA, email: 'bukan-email' }), (e) => e.http === 400);
  const o = await make(u, { product_id: '3', price: CANVA, email: 'Pembeli@Mail.com' }); assert.equal(row(o.id).buyer_input, 'pembeli@mail.com'); await pay(o, u);
  assert.equal(providerOrders()[0].params.email, 'pembeli@mail.com'); assert.equal(providerOrders()[0].params.product_id, '3');
});
test('CREATE: produk disembunyikan admin tidak bisa dibeli; margin pengaturan dipakai; qty dibatasi maks 5', async () => {
  const u = mkUser(); R("INSERT INTO settings(k,v) VALUES('premium_hidden','4')"); settings._clear(); await assert.rejects(make(u), (e) => e.http === 404);
  R('DELETE FROM settings'); R("INSERT INTO settings(k,v) VALUES('premium_margin_pct','20')"); settings._clear();
  await assert.rejects(make(u, { price: CAPCUT }), (e) => e.http === 409 && e.price === 5300); const o = await make(u, { price: 5300, qty: 99 }); assert.equal(o.qty, 5); assert.equal(o.price, 5300 * 5);
});
test('CREATE: maksimal 3 pesanan berjalan per user', async () => {
  const u = mkUser(); for (let i = 0; i < 3; i++) R("INSERT INTO premium_orders(user_id,ref,product_id,product_name,cost,price,status) VALUES(?,?,?,?,?,?,'review')", [u.id, 'A' + Math.random(), '4', 'x', 1, 1]);
  await assert.rejects(make(u), (e) => e.http === 429); assert.equal(invoices().length, 0);
});

test('BAYAR: lunas -> dikirim ke penyedia SEKALI -> selesai; data akun tersimpan TERENKRIPSI & terbaca pemilik; QR dibersihkan', async () => {
  const u = mkUser(), o = await make(u), v = await pay(o, u);
  assert.equal(v.status, 'done'); assert.deepEqual(Object.fromEntries(v.result), { email: 'akun@mail.com', password: 'rahasia123' }); assert.equal(providerOrders().length, 1); assert.deepEqual(providerOrders()[0].params, { product_id: '4' });
  const r = row(o.id); assert.ok(!String(r.result).includes('rahasia123'), 'kredensial tidak boleh polos di DB'); assert.equal(r.qr_image, null);
  await premium.view(u.id, o.id); assert.equal(providerOrders().length, 1, 'dilihat ulang tidak boleh membeli lagi');
});
test('BAYAR: webhook + polling + worker bersamaan -> penyedia dipanggil tepat SATU kali', async () => {
  const u = mkUser(), o = await make(u); gw[row(o.id).invoice_id] = 'paid'; await Promise.all([premium.view(u.id, o.id), premium.view(u.id, o.id), premium.refresh(row(o.id)), premium.refresh(row(o.id))]);
  assert.equal(providerOrders().length, 1); assert.equal(row(o.id).status, 'done');
});
test('BAYAR: qty>1 dikirim sebagai qty; gateway error saat cek -> status tidak berubah', async () => {
  const u = mkUser(), o = await make(u, { qty: 3, price: CAPCUT }); gw[row(o.id).invoice_id] = 'err'; assert.equal((await premium.view(u.id, o.id)).status, 'awaiting_payment');
  gw[row(o.id).invoice_id] = 'paid'; await premium.view(u.id, o.id); assert.equal(providerOrders()[0].params.qty, '3');
});
test('SETELAH BAYAR: penyedia menolak jelas (4xx / sirkuit / status gagal) -> refund_needed (uang sudah masuk), BUKAN hilang', async () => {
  for (const order of [() => { throw E(400, 'x', { public: 'Stok habis di penyedia' }); }, () => { throw E(503, 'x', { circuit: true }); }, () => ({ data: { id: 'T', status: 'failed' } })]) {
    handler = base({ order }); const u = mkUser(), o = await make(u); const v = await pay(o, u); assert.equal(v.status, 'refund_needed'); assert.ok(v.note || order.toString().includes('circuit') || true); calls = []; premium._reset();
  }
});
test('SETELAH BAYAR: timeout / 5xx (tidak pasti) -> review, TIDAK ada retry otomatis', async () => {
  for (const err of [new Error('timeout'), E(502, 'bad gateway')]) { handler = base({ order: () => { throw err; } }); const u = mkUser(), o = await make(u); assert.equal((await pay(o, u)).status, 'review'); assert.equal(providerOrders().length, 1); await premium.view(u.id, o.id); assert.equal(providerOrders().length, 1); calls = []; premium._reset(); }
});
test('SETELAH BAYAR: diterima belum selesai -> pending_provider -> polling sukses -> selesai + data akun; polling gagal -> refund_needed', async () => {
  let n = 0; handler = base({ order: () => ({ data: { id: 'TRX9', status: 'pending' } }), status: () => (++n < 2 ? { data: { status: 'processing' } } : { data: { status: 'completed', email: 'p@q.r', password: 'zz' } }) });
  const u = mkUser(), o = await make(u); assert.equal((await pay(o, u)).status, 'pending_provider'); assert.equal(row(o.id).provider_id, 'TRX9');
  assert.equal((await premium.view(u.id, o.id)).status, 'pending_provider', 'polling pertama: penyedia masih memproses');
  const v = await premium.view(u.id, o.id); assert.equal(v.status, 'done'); assert.equal(Object.fromEntries(v.result).email, 'p@q.r');
  handler = base({ order: () => ({ data: { id: 'T8', status: 'pending' } }), status: () => ({ data: { status: 'failed' } }) }); const u2 = mkUser(), o2 = await make(u2); await pay(o2, u2); assert.equal((await premium.view(u2.id, o2.id)).status, 'refund_needed');
});
test('SETELAH BAYAR: sukses tanpa data akun & tanpa ID -> review (tidak pernah "selesai" kosong)', async () => {
  handler = base({ order: () => ({ success: true, data: { status: 'success' } }) }); const u = mkUser(), o = await make(u); assert.equal((await pay(o, u)).status, 'review');
});

test('ADMIN resolve: refund_needed -> refunded; sudah refunded tidak bisa diulang; review -> done manual', async () => {
  handler = base({ order: () => { throw E(400, 'x', { public: 'Stok habis' }); } }); const u = mkUser(), o = await make(u); await pay(o, u);
  assert.equal((await premium.resolve(o.id, 'refunded', 'Dikembalikan via DANA')).ok, true); assert.equal(row(o.id).status, 'refunded'); assert.equal((await premium.resolve(o.id, 'refunded')).ok, false); assert.equal((await premium.resolve(o.id, 'done')).ok, false);
  handler = base({ order: () => { throw new Error('timeout'); } }); const o2 = await make(u); await pay(o2, u); assert.equal(row(o2.id).status, 'review'); assert.equal((await premium.resolve(o2.id, 'done', 'dikirim manual')).ok, true); assert.equal(row(o2.id).status, 'done');
});
test('ADMIN retry: hanya dari refund_needed (penolakan pasti); dari review TIDAK boleh (bisa beli ganda)', async () => {
  let fail = true; handler = base({ order: () => { if (fail) throw E(400, 'x', { public: 'Stok habis' }); return { data: { id: 'T', status: 'success', email: 'baru@mail.com' } }; } });
  const u = mkUser(), o = await make(u); await pay(o, u); assert.equal(row(o.id).status, 'refund_needed'); fail = false;
  const r = await premium.resolve(o.id, 'retry'); assert.equal(r.ok, true); assert.equal(r.status, 'done'); assert.equal(providerOrders().length, 2);
  handler = base({ order: () => { throw new Error('timeout'); } }); const o2 = await make(u); await pay(o2, u); assert.equal(row(o2.id).status, 'review'); calls = []; assert.equal((await premium.resolve(o2.id, 'retry')).ok, false); assert.equal(providerOrders().length, 0);
});
test('KEDALUWARSA & BATAL: belum dibayar lewat batas -> expired; batal; dibayar saat batal -> 409 & lanjut; telat bayar tetap diproses', async () => {
  const u = mkUser(), a = await make(u), b = await make(u, { qty: 2, price: CAPCUT }), c = await make(u, { qty: 3, price: CAPCUT });
  R("UPDATE premium_orders SET expires_at=? WHERE id=?", ['2020-01-01 00:00:00', a.id]); gw[row(a.id).invoice_id] = 'pending'; assert.equal((await premium.view(u.id, a.id)).status, 'expired');
  assert.equal((await premium.cancel(u.id, b.id)).code, 200); assert.equal(row(b.id).status, 'cancelled'); assert.equal(row(b.id).qr_image, null);
  gw[row(c.id).invoice_id] = 'paid'; const cc = await premium.cancel(u.id, c.id); assert.equal(cc.code, 409); assert.equal(row(c.id).status, 'done');
  assert.equal((await premium.cancel(u.id + 999, b.id)).code, 404);
  gw[row(a.id).invoice_id] = 'paid'; await premium.late(row(a.id)); assert.equal(row(a.id).status, 'done'); gw[row(b.id).invoice_id] = 'paid'; await premium.late(row(b.id)); assert.equal(row(b.id).status, 'done');
});
test('sweepStuck: processing menggantung >3 mnt -> review; pending_provider >60 mnt -> review; QRIS lama -> expired', async () => {
  const u = mkUser(), ins = (ref, st, extra) => R(`INSERT INTO premium_orders(user_id,ref,product_id,product_name,cost,price,status,${extra[0]}) VALUES(?,?,?,?,?,?,?,?)`, [u.id, ref, '4', 'x', 1, 1, st, extra[1]]).insertId;
  const a = ins('S1', 'processing', ['updated_at', '2020-01-01 00:00:00']), b = ins('S2', 'processing', ['updated_at', new Date().toISOString().slice(0, 19).replace('T', ' ')]), c = ins('S3', 'pending_provider', ['created_at', '2020-01-01 00:00:00']), d = ins('S4', 'awaiting_payment', ['expires_at', '2020-01-01 00:00:00']);
  await premium.sweepStuck(); assert.equal(row(a).status, 'review'); assert.equal(row(b).status, 'processing'); assert.equal(row(c).status, 'review'); assert.equal(row(d).status, 'expired');
});
test('RIWAYAT: hide hanya menyembunyikan (data TETAP ada) dan hanya status akhir; milik orang lain tidak bisa', async () => {
  const u = mkUser(), o = await make(u); assert.equal(await premium.hide(u.id, o.id), false); const v = await pay(o, u); assert.equal(v.status, 'done');
  assert.equal(await premium.hide(u.id + 1, o.id), false); assert.equal(await premium.hide(u.id, o.id), true); const r = row(o.id); assert.equal(r.hidden, 1); assert.ok(r.result, 'data akun tetap tersimpan'); assert.equal((await premium.listOwn(u.id)).length, 0);
});
test('ADMIN katalog: bendera dijual/disembunyikan/butuh input per produk', async () => {
  R("INSERT INTO settings(k,v) VALUES('premium_hidden','4')"); settings._clear(); const c = await premium.adminCatalog(); const by = Object.fromEntries(c.items.map((x) => [x.id, x]));
  assert.equal(by['3'].needs_input, true); assert.equal(by['3'].sellable, false); assert.equal(by['4'].hidden, true); assert.equal(by['4'].sellable, false); assert.equal(by['4'].price, CAPCUT); assert.equal(by['4'].image, true);
});

test('format resmi Averpay: hanya data.accounts yang dikirim ke pelanggan, sellPrice (modal) & premkuInvoice tidak bocor', () => {
  const m = premium.entriesOf({ success: true, data: { _id: 'PREM1', premkuInvoice: 'API-2026-x', productName: 'Capcut', qty: 1, sellPrice: 9500, status: 'success', accounts: [{ username: 'a@b.c', password: 'pw1' }] } });
  const txt = JSON.stringify(m); assert.ok(txt.includes('a@b.c') && txt.includes('pw1')); assert.ok(!/9500|API-2026|PREM1/.test(txt));
  const fresh = premium.entriesOf({ success: true, data: { _id: 'PREM1', premkuInvoice: 'API-2026-x', productName: 'Capcut', qty: 1, sellPrice: 9500, status: 'pending' } });
  assert.ok(!/9500|API-2026/.test(JSON.stringify(fresh)), 'respons order baru tidak membocorkan modal');
});
test('hapus massal riwayat premium: hanya status akhir milik sendiri; pesanan berjalan tidak ikut; data tetap tersimpan', async () => {
  const u = mkUser(), a = await make(u), b = await make(u, { qty: 2 }); const v = await pay(a, u); assert.equal(v.status, 'done');
  assert.equal(await premium.hideAll(u.id + 1), 0); assert.equal(await premium.hideAll(u.id), 1);
  assert.equal(row(a.id).hidden, 1); assert.ok(row(a.id).result, 'data akun tetap tersimpan'); assert.equal(row(b.id).hidden || 0, 0, 'pesanan menunggu bayar tidak ikut');
});
