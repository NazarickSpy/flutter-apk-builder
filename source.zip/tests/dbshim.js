// Simulasi pool mysql2 di atas node:sqlite (memori) supaya kode saldo/pesanan bisa DIJALANKAN di test tanpa MySQL.
// Hanya untuk SQL portabel yang dipakai order.js & premium.js; dua kunci (UNIQUE) dipetakan ke ER_DUP_ENTRY seperti MySQL.
const { DatabaseSync } = require('node:sqlite');
function makePool() {
  const db = new DatabaseSync(':memory:');
  db.exec(`CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, email TEXT, whatsapp TEXT, pass_hash TEXT, balance INTEGER NOT NULL DEFAULT 0, role TEXT DEFAULT 'member', ptero_user_id INTEGER, panel_pass_enc TEXT, banned INTEGER DEFAULT 0, pv INTEGER DEFAULT 0, fails INTEGER DEFAULT 0, locked_until TEXT, created_at TEXT DEFAULT (datetime('now')), notif_seen_at TEXT);
    CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, package_key TEXT NOT NULL, price INTEGER NOT NULL, server_name TEXT NOT NULL, ptero_server_id INTEGER, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT DEFAULT (datetime('now')), order_ref TEXT UNIQUE, transaction_id TEXT UNIQUE, total INTEGER, qr_image TEXT, badge TEXT, pay_method TEXT NOT NULL DEFAULT 'qris', pay_status TEXT NOT NULL DEFAULT 'pending', expires_at TEXT, attempts INTEGER NOT NULL DEFAULT 0, hidden INTEGER NOT NULL DEFAULT 0, activated_at TEXT, claims_used INTEGER NOT NULL DEFAULT 0, bonus_days INTEGER NOT NULL DEFAULT 0, cancelled_at TEXT, updated_at TEXT DEFAULT (datetime('now')), provider_id TEXT, panel_user TEXT, panel_email TEXT, panel_pass_enc TEXT, panel_domain TEXT, panel_expires_at TEXT, pkg_name TEXT, pkg_ram INTEGER, pkg_disk INTEGER, pkg_cpu INTEGER, cost INTEGER);
    CREATE TRIGGER trg_orders_upd AFTER UPDATE ON orders WHEN NEW.updated_at IS OLD.updated_at BEGIN UPDATE orders SET updated_at=datetime('now') WHERE id=NEW.id; END;
    CREATE TABLE premium_orders(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, ref TEXT NOT NULL UNIQUE, product_id TEXT NOT NULL, product_name TEXT NOT NULL, qty INTEGER NOT NULL DEFAULT 1, cost INTEGER NOT NULL, price INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'awaiting_payment', invoice_id TEXT UNIQUE, total INTEGER, qr_image TEXT, expires_at TEXT, buyer_input TEXT, provider_id TEXT, provider_status TEXT, result TEXT, error TEXT, hidden INTEGER NOT NULL DEFAULT 0, polls INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')));
    CREATE TRIGGER trg_prm_upd AFTER UPDATE ON premium_orders WHEN NEW.updated_at IS OLD.updated_at BEGIN UPDATE premium_orders SET updated_at=datetime('now') WHERE id=NEW.id; END;
    CREATE TABLE nokos_orders(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, ref TEXT NOT NULL UNIQUE, server TEXT NOT NULL DEFAULT 'ekonomi', operator TEXT, platform_id TEXT NOT NULL, platform_name TEXT NOT NULL, country_id TEXT NOT NULL, country_name TEXT NOT NULL, product_id TEXT NOT NULL, product_name TEXT NOT NULL, cost INTEGER NOT NULL, price INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'awaiting_payment', invoice_id TEXT UNIQUE, total INTEGER, qr_image TEXT, expires_at TEXT, provider_id TEXT, provider_status TEXT, phone TEXT, otp_expires_at TEXT, otp_code TEXT, otp_text TEXT, otp_code2 TEXT, resend_at TEXT, error TEXT, hidden INTEGER NOT NULL DEFAULT 0, polls INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')));
    CREATE TRIGGER trg_nok_upd AFTER UPDATE ON nokos_orders WHEN NEW.updated_at IS OLD.updated_at BEGIN UPDATE nokos_orders SET updated_at=datetime('now') WHERE id=NEW.id; END;
    CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT NOT NULL);
    CREATE TABLE idem_keys(user_id INTEGER NOT NULL, k TEXT NOT NULL, scope TEXT NOT NULL, fp TEXT NOT NULL, code INTEGER, body TEXT, created_ms INTEGER NOT NULL, PRIMARY KEY(user_id,k,scope));
    CREATE TABLE orphan_invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id TEXT NOT NULL UNIQUE, kind TEXT NOT NULL, user_id INTEGER, amount INTEGER, err TEXT, created_at TEXT DEFAULT (datetime('now')));
    CREATE TABLE claims(id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, user_id INTEGER, category TEXT, reason TEXT, status TEXT, created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')));
    CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, type TEXT NOT NULL, ip TEXT, ua TEXT, created_at TEXT DEFAULT (datetime('now')));
    CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER, action TEXT, target INTEGER, detail TEXT, created_at TEXT DEFAULT (datetime('now')));`);
  const toSql = (v) => (v instanceof Date ? v.toISOString().slice(0, 19).replace('T', ' ') : v);
  const fixRow = (r) => { for (const k of Object.keys(r)) if (/_at$/.test(k) && typeof r[k] === 'string' && /^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/.test(r[k])) r[k] = new Date(r[k].replace(' ', 'T') + 'Z'); return r; }; // mysql2 (timezone 'Z') mengembalikan DATETIME sebagai Date UTC
  const run = (sql, params = []) => {
    if (params.some((p) => p === undefined)) throw new Error('Bind parameters must not contain undefined. To pass SQL NULL specify JS null'); // perilaku mysql2.execute
    params = params.map(toSql);
    sql = sql.replace(/ FOR UPDATE/gi, '').replace(/ORDER BY FIELD\([^)]*\),\s*/i, 'ORDER BY ')
      .replace(/DATE_SUB\(\s*UTC_TIMESTAMP\(\)\s*,\s*INTERVAL\s+(\d+)\s+(MINUTE|HOUR|DAY|SECOND)\s*\)/gi, (_m, n, u) => `datetime('now','-${n} ${u.toLowerCase()}s')`).replace(/UTC_TIMESTAMP\(\)/gi, "datetime('now')");
    try {
      if (/^\s*select/i.test(sql)) return [db.prepare(sql).all(...params).map(fixRow)];
      const r = db.prepare(sql).run(...params); return [{ affectedRows: Number(r.changes), insertId: Number(r.lastInsertRowid) }];
    } catch (e) { if (/UNIQUE constraint failed/.test(e.message)) { const x = new Error(e.message); x.code = 'ER_DUP_ENTRY'; throw x; } throw e; }
  };
  // Satu koneksi sqlite: transaksi dijalankan BERGANTIAN (meniru efek SELECT ... FOR UPDATE di MySQL: transaksi kedua menunggu yang pertama selesai & melihat hasil commit-nya)
  let tail = Promise.resolve();
  const conn = () => { let release = null; const done = () => { if (release) { release(); release = null; } };
    return { execute: async (s, p) => run(s, p), query: async (s, p) => run(s, p),
      beginTransaction: async () => { const prev = tail; let r; tail = new Promise((x) => { r = x; }); release = r; await prev; db.exec('BEGIN'); },
      commit: async () => { try { db.exec('COMMIT'); } finally { done(); } }, rollback: async () => { try { db.exec('ROLLBACK'); } finally { done(); } }, release() { done(); } }; };
  return { execute: async (s, p) => run(s, p), query: async (s, p) => run(s, p), getConnection: async () => conn(), _db: db, _run: run };
}
module.exports = { makePool };
