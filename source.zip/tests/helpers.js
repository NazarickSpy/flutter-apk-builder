// Helper test: mock modul yang butuh DB/jaringan supaya test berjalan offline tanpa npm install
const Module = require('module');
exports.mockModules = (map) => { const orig = Module._load; Module._load = function (r, ...a) { return r in map ? map[r] : orig.call(this, r, ...a); }; return () => { Module._load = orig; }; };
exports.json = (status, body) => ({ ok: status >= 200 && status < 300, status, json: async () => body, headers: { get: () => 'application/json' } });
