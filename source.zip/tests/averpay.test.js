const test = require('node:test'), assert = require('node:assert/strict'), { json } = require('./helpers');
process.env.AVERPAY_API_KEY = 'avp_secret'; process.env.AVERPAY_BASE = 'https://gw.example/'; process.env.AVERPAY_GAP_MS = '0';
let calls = [], handler;
global.fetch = async (url, o) => { calls.push({ url, h: o.headers, m: o.method }); return handler(url); };
const a = require('../lib/averpay');
const wib = (d) => new Date(d.getTime() + 7 * 3600e3).toISOString().slice(0, 19).replace('T', ' ');
const okInvoice = (extra = {}) => json(200, { success: true, invoice_id: 'INV1', amount: 10000, fee: 500, total: 10500, qris_image: 'https://cdn.example/q.png', payment_link: 'https://gw.example/pay/INV1', expired_at: wib(new Date(Date.now() + 15 * 60e3)), ...extra });
test.beforeEach(() => { calls = []; a._reset(); });
test('create: GET + header x-api-key (key tidak di URL), total dari gateway, payment_link TIDAK diteruskan', async () => {
  handler = () => okInvoice(); const q = await a.create(10000);
  assert.equal(calls[0].m, 'GET'); assert.equal(calls[0].url, 'https://gw.example/api/invoice?amount=10000');
  assert.equal(calls[0].h['x-api-key'], 'avp_secret'); assert.ok(!calls[0].url.includes('avp_secret'));
  assert.equal(q.total, 10500); assert.equal(q.transaction_id, 'INV1'); assert.ok(!('pay_link' in q) && !('payment_link' in q));
});
test('expired_at WIB & UTC terbaca benar; ngaco -> fallback TTL', () => {
  const near = (d, min) => Math.abs(d.getTime() - Date.now() - min * 60e3) < 5000;
  assert.ok(near(a.parseExpiry(wib(new Date(Date.now() + 15 * 60e3))), 15));
  assert.ok(near(a.parseExpiry(new Date(Date.now() + 15 * 60e3).toISOString().slice(0, 19).replace('T', ' ')), 15));
  assert.ok(near(a.parseExpiry('2020-01-01 00:00:00'), 15)); assert.ok(near(a.parseExpiry(undefined), 15));
});
test('respons tidak valid ditolak (gambar bukan https/data, total 0, tanpa invoice_id)', async () => {
  for (const bad of [{ qris_image: 'javascript:alert(1)' }, { total: 0, amount: 0 }, { invoice_id: '' }]) { handler = () => okInvoice(bad); await assert.rejects(a.create(1000), /tidak valid/); a._reset(); }
});
test('pesan validasi gateway diteruskan tapi URL & nama penyedia disamarkan; 401/5xx tidak dibocorkan', async () => {
  handler = () => json(400, { error: 'Minimal deposit Rp 5.000 di Averpay https://averpay.my.id/x' });
  await assert.rejects(a.create(1000), (e) => e.public === 'Minimal deposit Rp 5.000 di gateway' && !/averpay|http/i.test(e.public));
  handler = () => json(401, { error: 'API key tidak valid' }); await assert.rejects(a.create(1000), (e) => e.public === undefined);
  handler = () => json(500, { error: 'boom' }); await assert.rejects(a.create(1000), (e) => e.public === undefined);
});
test('5xx di-retry 1x; timeout TIDAK di-retry', async () => {
  handler = () => json(500, {}); await assert.rejects(a.create(1000)); assert.equal(calls.length, 2); a._reset(); calls = [];
  handler = () => { const e = new Error('t'); e.name = 'TimeoutError'; throw e; }; await assert.rejects(a.create(1000)); assert.equal(calls.length, 1);
});
test('gateway down: setelah 5 kegagalan sirkuit terbuka & panggilan berikutnya gagal cepat tanpa menyentuh gateway', async () => {
  handler = () => { const e = new Error('t'); e.name = 'TimeoutError'; throw e; };
  for (let i = 0; i < 5; i++) await assert.rejects(a.create(1000));
  calls = []; await assert.rejects(a.create(1000), (e) => e.circuit === true && e.status === 503); assert.equal(calls.length, 0); assert.equal(a.breaker().open, true);
});
test('status: dedupe polling bersamaan, normalisasi paid/expired/pending', async () => {
  let s = 'pending'; handler = () => json(200, { status: s });
  await Promise.all([a.status('T1'), a.status('T1'), a.status('T1')]); assert.equal(calls.length, 1);
  s = 'PAID'; const p = await a.status('T2'); assert.equal(p.paid, true);
  s = 'expired'; const e = await a.status('T3'); assert.equal(e.expired, true);
  s = 'sesuatu-baru'; const u = await a.status('T4'); assert.deepEqual([u.paid, u.expired], [false, false]);
});

test('batas laju Averpay (\"Tunggu 1 detik\"): ditahan lalu diulang otomatis, invoice tidak ganda, sirkuit tidak terbuka', async () => {
  let n = 0; handler = () => (++n === 1 ? json(400, { error: 'Terlalu banyak request. Tunggu 1 detik lalu coba lagi.' }) : okInvoice());
  const t0 = Date.now(), q = await a.create(10000);
  assert.equal(q.transaction_id, 'INV1'); assert.equal(calls.length, 2); assert.ok(Date.now() - t0 >= 1200, 'menunggu sesuai permintaan gateway'); assert.equal(a.breaker().open, false);
});
test('batas laju terus-menerus: gagal dengan pesan ramah (bukan refund/error mentah) setelah 2x ulang', async () => {
  handler = () => json(429, { error: 'Terlalu banyak request. Tunggu 1 detik.' });
  await assert.rejects(a.create(1000), (e) => e.rate === true && /padat/.test(e.public) && !/averpay/i.test(e.public)); assert.equal(calls.length, 3); assert.equal(a.breaker().open, false);
});
test('post(): metode POST, parameter di query string, API key tetap di header, 5xx TIDAK diulang (tanpa idempotency key)', async () => {
  handler = () => json(200, { success: true, data: { _id: 'N1' } }); const j = await a.post('/api/nokos/order', { quote_id: 'abc123' });
  assert.equal(calls[0].m, 'POST'); assert.equal(calls[0].url, 'https://gw.example/api/nokos/order?quote_id=abc123'); assert.equal(calls[0].h['x-api-key'], 'avp_secret'); assert.ok(!calls[0].url.includes('avp_secret')); assert.equal(j.data._id, 'N1');
  calls = []; a._reset(); handler = () => json(500, { error: 'boom' }); await assert.rejects(a.post('/api/nokos/order', { quote_id: 'x' })); assert.equal(calls.length, 1, 'POST tidak diulang');
});
