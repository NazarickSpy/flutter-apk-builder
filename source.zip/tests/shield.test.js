const test = require('node:test'), assert = require('node:assert/strict');
const { create, TRAP } = require('../lib/shield');
const mk = (sh, { ip = '5.6.7.8', path = '/', method = 'GET', url, ua = 'Mozilla/5.0 Chrome/126' } = {}) => { const o = { code: null, ended: false, done: {} }; const res = { statusCode: 200, set() {}, status(c) { this.statusCode = c; o.code = c; return this; }, type() { return this; }, send() { o.ended = true; return this; }, json() { o.ended = true; return this; }, on(e, f) { o.done[e] = f; } }; let passed = false; sh.middleware({ ip, path, method, url: url || path, get: (h) => (h.toLowerCase() === 'user-agent' ? ua : undefined) }, res, () => { passed = true; }); return { o, res, passed }; };
test('jalur jebakan (.env, .git, .htaccess, /uploads) dijawab 404 dan memberi poin; 3x = diblokir', () => {
  const logs = []; const sh = create({ log: (m) => logs.push(m) });
  for (const p of ['/.env', '/.git/config', '/.htaccess']) { const r = mk(sh, { path: p }); assert.equal(r.o.code, 404); assert.equal(r.passed, false); }
  assert.equal(sh.banned('5.6.7.8'), true); assert.match(logs[0], /BLOKIR 5\.6\.7\.8 selama 30 mnt/);
  assert.equal(mk(sh, { path: '/' }).o.code, 403); // IP terblokir ditolak di semua jalur
  assert.equal(mk(sh, { ip: '9.9.9.9', path: '/' }).passed, true); // IP lain aman
});
test('rute sah tidak terkena: halaman, /api/admin/backup, aset', () => {
  const sh = create({ log() {} });
  for (const p of ['/', '/dashboard', '/profile', '/api/admin/backup', '/api/orders', '/_next/static/a.js', '/img/logo.webp']) assert.equal(mk(sh, { path: p }).passed, true, p);
  assert.equal(TRAP.test('/uploads'), true);
});
test('scanner UA diblokir seketika; curl/okhttp pada login & daftar ditolak, tetapi GET biasa boleh', () => {
  const sh = create({ log() {} });
  assert.equal(mk(sh, { ip: '1.1.1.1', ua: 'python-urllib/3.11' }).o.code, 403); assert.equal(sh.banned('1.1.1.1'), true);
  const r = mk(sh, { ip: '2.2.2.2', method: 'POST', path: '/api/login', ua: 'curl/8.5.0' }); assert.equal(r.o.code, 403);
  assert.equal(mk(sh, { ip: '3.3.3.3', method: 'POST', path: '/api/login', ua: 'okhttp/4.9.3' }).o.code, 403);
  assert.equal(mk(sh, { ip: '4.4.4.4', method: 'POST', path: '/api/login', ua: 'Mozilla/5.0 (Linux; Android 14) Chrome/126' }).passed, true);
  assert.equal(mk(sh, { ip: '4.4.4.4', method: 'GET', path: '/status', ua: 'curl/8.5.0' }).passed, true);
});
test('404 beruntun pada /api/ (enumerasi) memblokir IP; webhook & daftar putih tidak terkena', () => {
  let t = 1e6; const sh = create({ now: () => t, allow: ['7.7.7.7'], log() {} });
  for (let i = 0; i < 40; i++) { const r = mk(sh, { ip: '6.6.6.6', path: '/api/x' + i }); if (r.passed) { r.res.statusCode = 404; r.o.done.finish(); } }
  assert.equal(sh.banned('6.6.6.6'), true);
  assert.equal(mk(sh, { ip: '6.6.6.6', path: '/webhook/averpay', method: 'POST' }).passed, true); // webhook Averpay tetap lolos
  for (let i = 0; i < 100; i++) sh.strike('7.7.7.7', 50, 'x'); assert.equal(sh.banned('7.7.7.7'), false);
});
test('blokir berulang makin lama; skor kadaluarsa di luar jendela; unban', () => {
  let t = 1e6; const logs = []; const sh = create({ now: () => t, log: (m) => logs.push(m) });
  sh.strike('8.8.8.8', 100, 'a'); assert.match(logs[0], /30 mnt/); t += 31 * 60e3; assert.equal(sh.banned('8.8.8.8'), false);
  sh.strike('8.8.8.8', 100, 'b'); assert.match(logs[1], /6 jam/); t += 7 * 3600e3; sh.strike('8.8.8.8', 100, 'c'); assert.match(logs[2], /24 jam/);
  sh.unban('8.8.8.8'); assert.equal(sh.banned('8.8.8.8'), false);
  sh.strike('9.1.1.1', 60, 'p'); t += 11 * 60e3; sh.strike('9.1.1.1', 60, 'p'); assert.equal(sh.banned('9.1.1.1'), false); // 60 + 60 tidak akumulasi lewat jendela
});
test('request berlebihan (429) memberi poin sampai IP diblokir; aset statis & webhook tidak ikut', () => {
  const sh = create({ log() {} });
  for (let i = 0; i < 14; i++) { const r = mk(sh, { ip: '10.1.1.1', path: '/api/orders' }); if (r.passed) { r.res.statusCode = 429; r.o.done.finish(); } }
  assert.equal(sh.banned('10.1.1.1'), true);
  assert.equal(mk(sh, { ip: '10.1.1.1', path: '/webhook/averpay', method: 'POST' }).passed, true);
});
test('metode HTTP aneh -> 405 + poin; URL terlalu panjang -> 414; /api tanpa User-Agent -> 403, tetapi halaman & webhook tanpa UA boleh', () => {
  const sh = create({ log() {} });
  assert.equal(mk(sh, { ip: '10.2.2.2', method: 'TRACE', path: '/' }).o.code, 405);
  assert.equal(mk(sh, { ip: '10.2.2.3', path: '/', url: '/?q=' + 'a'.repeat(3000) }).o.code, 414);
  assert.equal(mk(sh, { ip: '10.2.2.4', path: '/api/orders', ua: '' }).o.code, 403);
  assert.equal(mk(sh, { ip: '10.2.2.5', path: '/', ua: '' }).passed, true);
  assert.equal(mk(sh, { ip: '10.2.2.6', method: 'POST', path: '/webhook/averpay', ua: '' }).passed, true);
  assert.equal(mk(sh, { ip: '10.2.2.7', method: 'PATCH', path: '/api/x' }).passed, true);
});
test('IP yang terus mengirim request saat diblokir diputus soketnya (tanpa balasan); unban memulihkan', () => {
  const sh = create({ log() {} }); sh.strike('10.3.3.3', 100, 'x'); assert.equal(sh.banned('10.3.3.3'), true);
  let destroyed = 0; const sock = { destroy() { destroyed++; } };
  const send = () => { const o = { code: null }; const res = { statusCode: 200, set() {}, status(c) { o.code = c; return this; }, type() { return this; }, send() { return this; }, json() { return this; }, on() {} }; sh.middleware({ ip: '10.3.3.3', path: '/', method: 'GET', url: '/', get: () => 'Mozilla/5.0 Chrome/126', socket: sock }, res, () => {}); return o.code; };
  for (let i = 0; i < 20; i++) assert.equal(send(), 403); assert.equal(destroyed, 0);
  send(); assert.equal(destroyed, 1, 'request ke-21 saat diblokir: soket diputus');
  assert.equal(sh.unban('10.3.3.3'), true); assert.equal(sh.banned('10.3.3.3'), false);
});
