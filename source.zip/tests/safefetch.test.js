const test = require('node:test'), assert = require('node:assert/strict'), { EventEmitter } = require('node:events');
const { fetchImage, isPrivateIp } = require('../lib/safefetch');
test('isPrivateIp: alamat internal/metadata ditolak, publik diterima', () => {
  for (const ip of ['127.0.0.1', '10.0.0.5', '172.16.0.1', '172.31.255.1', '192.168.1.1', '169.254.169.254', '100.64.0.1', '0.0.0.0', '224.0.0.1', '::1', '::', 'fd00::1', 'fe80::1', '::ffff:127.0.0.1', 'bukan-ip']) assert.equal(isPrivateIp(ip), true, ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '172.32.0.1', '203.0.113.9', '2606:4700:4700::1111']) assert.equal(isPrivateIp(ip), false, ip);
});
const ok = (over = {}) => ({ lookup: async () => [{ address: '93.184.216.34', family: 4 }], request: (opts, cb) => { const req = new EventEmitter(); req.opts = opts; req.end = () => process.nextTick(() => { const res = new EventEmitter(); Object.assign(res, { statusCode: 200, headers: { 'content-type': 'image/png' }, resume() {}, destroy() {} }); cb(res); res.emit('data', Buffer.from('PNG')); res.emit('end'); }); req.destroy = () => {}; (over.onReq || (() => {}))(req); return req; }, ...over });
test('URL berbahaya ditolak SEBELUM ada koneksi: http, port aneh, user:pass, IP internal, DNS menunjuk IP internal', async () => {
  let touched = false; const d = ok({ request: () => { touched = true; throw new Error('tidak boleh'); } });
  for (const u of ['http://x.com/q.png', 'https://x.com:8443/q.png', 'https://u:p@x.com/q.png', 'https://127.0.0.1/q.png', 'https://169.254.169.254/latest/meta-data', 'https://[::1]/q.png', 'ftp://x.com/a', 'bukan url']) await assert.rejects(fetchImage(u, d), (e) => e.blocked === true, u);
  await assert.rejects(fetchImage('https://evil.example/q.png', { ...d, lookup: async () => [{ address: '10.0.0.1', family: 4 }] }), (e) => e.blocked);
  await assert.rejects(fetchImage('https://evil.example/q.png', { ...d, lookup: async () => [{ address: '8.8.8.8', family: 4 }, { address: '192.168.0.1', family: 4 }] }), (e) => e.blocked, 'satu saja IP privat -> tolak semua (DNS rebinding)');
  assert.equal(touched, false);
});
test('sukses: alamat DIKUNCI ke IP yang sudah divalidasi (lookup custom), hanya gambar', async () => {
  let opts; const r = await fetchImage('https://cdn.example/q.png?x=1', ok({ onReq: (q) => { opts = q.opts; } }));
  assert.equal(r.type, 'image/png'); assert.equal(r.body.toString(), 'PNG'); assert.equal(opts.host, 'cdn.example'); assert.equal(opts.path, '/q.png?x=1');
  await new Promise((res) => opts.lookup('cdn.example', { all: true }, (e, a) => { assert.deepEqual(a, [{ address: '93.184.216.34', family: 4 }]); res(); }));
  await new Promise((res) => opts.lookup('cdn.example', {}, (e, a, f) => { assert.equal(a, '93.184.216.34'); assert.equal(f, 4); res(); }));
});
test('respons bukan gambar / status bukan 200 / redirect / terlalu besar -> ditolak', async () => {
  const mk = (statusCode, ct, chunks = []) => ok({ request: (o, cb) => { const q = new EventEmitter(); q.end = () => process.nextTick(() => { const res = new EventEmitter(); Object.assign(res, { statusCode, headers: { 'content-type': ct }, resume() {}, destroy() {} }); cb(res); for (const c of chunks) res.emit('data', c); res.emit('end'); }); q.destroy = () => {}; return q; } });
  await assert.rejects(fetchImage('https://c.example/a', mk(200, 'text/html')), /bukan gambar/); await assert.rejects(fetchImage('https://c.example/a', mk(200, 'image/svg+xml')), /bukan gambar/);
  await assert.rejects(fetchImage('https://c.example/a', mk(302, 'image/png')), /status 302/); await assert.rejects(fetchImage('https://c.example/a', mk(404, 'image/png')), /status 404/);
  await assert.rejects(fetchImage('https://c.example/a', { ...mk(200, 'image/png', [Buffer.alloc(1500), Buffer.alloc(1500)]), max: 2000 }), /terlalu besar/);
});
