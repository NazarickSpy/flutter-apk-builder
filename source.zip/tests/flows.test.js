// Alur pesanan panel memakai SQL ASLI order.js di atas simulasi database (tanpa saldo/dompet: uang hanya lewat QRIS -> saldo Averpay)
const test = require('node:test'), assert = require('node:assert/strict'), { mockModules } = require('./helpers'), { makePool } = require('./dbshim');
process.env.JWT_SECRET = 'x'.repeat(40);
const pool = makePool(); let gw = {}, ptCalls = [], ptFail = false, ptErr = null, ptStatus = 'ACTIVE', sid = 100;
const fakeAverpay = { status: async (tx) => { if (gw[tx] === 'err') throw new Error('gateway down'); return { paid: gw[tx] === 'paid', expired: gw[tx] === 'expired' }; }, breaker: () => ({ open: false }) };
const fakePanel = { // meniru lib/panel.js (Averpay Panel Hosting)
  find: async (key) => ({ key, name: 'Paket 1GB', memory: 1024, disk: 2048, cpu: 50, cost: 800, price: 1000 }), validUser: (s) => /^[A-Za-z0-9_]{3,14}$/.test(String(s || '')), cleanUser: (s) => String(s).replace(/[^A-Za-z0-9_]/g, '').slice(0, 14),
  verdict: (st) => (/^(ACTIVE|SUCCESS)$/.test(st) ? 'ok' : /^(FAILED|CANCELED|EXPIRED)$/.test(st) ? 'bad' : 'wait'),
  order: async (p) => { ptCalls.push(p); if (ptErr) throw ptErr; if (ptFail) throw Object.assign(new Error('panel down'), { status: 400 }); return { id: 'PTERO' + ++sid, status: ptStatus, username: p.username + 'ab12', password: p.password, email: p.email, panel_domain: 'https://panel.test', cost: 800, expires_at: '2030-01-01T00:00:00.000Z' }; },
  status: async () => ({ status: ptStatus, username: null, expires_at: null }) };
mockModules({ './db': { pool }, './averpay': fakeAverpay, './panel': fakePanel });
const order = require('../lib/order'), { dec } = require('../lib/crypto');
const R = (sql, p) => pool._run(sql, p)[0];
let n = 0;
const user = async () => { const id = R('INSERT INTO users(username,email) VALUES(?,?)', ['u' + ++n, `u${n}@m.m`]).insertId; return id; };
const iso = (ms) => new Date(Date.now() + ms).toISOString().slice(0, 19).replace('T', ' ');
const mkOrder = (uid, o = {}) => { const ref = 'SNW' + ++n; const r = R('INSERT INTO orders(user_id,package_key,price,server_name,order_ref,transaction_id,total,expires_at,pay_method,pay_status,status,qr_image) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', [uid, o.pkg || '1gb', o.price ?? 1000, 'bot', o.ref || ref, o.pay_method === 'saldo' ? null : 'TX' + n, 1500, o.exp || iso(15 * 60e3), o.pay_method || 'qris', o.pay_status || 'pending', o.status || 'pending', 'https://qr/x.png']); return { id: r.insertId, tx: 'TX' + n, ref: o.ref || ref }; };
const row = (id) => R('SELECT * FROM orders WHERE id=?', [id])[0];
const load = (id) => R(`SELECT ${order.LIGHT} FROM orders WHERE id=?`, [id])[0];
test.beforeEach(() => { gw = {}; ptCalls = []; ptFail = false; ptErr = null; ptStatus = 'ACTIVE'; process.env.PANEL_RETRY_MS = '0'; });

test('PANEL: dibayar -> server dibuat otomatis (aktif), akun panel tersimpan terenkripsi, QR dibersihkan, sekali saja', async () => {
  const u = await user(), o = mkOrder(u); gw[o.tx] = 'paid';
  const r = await order.refresh(load(o.id)); assert.equal(r.status, 'active'); assert.equal(r.pay_status, 'paid');
  assert.equal(ptCalls.length, 1); assert.equal(ptCalls[0].package_id, '1gb'); assert.equal(ptCalls[0].username, 'bot'); assert.equal(ptCalls[0].email, R('SELECT email FROM users WHERE id=?', [u])[0].email);
  const f = row(o.id); assert.ok(/^PTERO/.test(f.provider_id)); assert.equal(f.qr_image, null); assert.ok(f.activated_at); assert.equal(f.panel_user, 'botab12'); assert.equal(f.panel_domain, 'https://panel.test'); assert.equal(f.cost, 800); assert.equal(f.pkg_ram, 1024);
  assert.equal(dec(f.panel_pass_enc), ptCalls[0].password, 'password yang dikirim = yang tersimpan terenkripsi'); assert.ok(ptCalls[0].password.length >= 8 && !/\s/.test(ptCalls[0].password));
  await order.refresh(load(o.id)); assert.equal(ptCalls.length, 1, 'refresh ulang tidak boleh membeli panel lagi');
});
test('PANEL: refresh bersamaan (webhook + polling + worker) -> server dibuat tepat SATU kali', async () => {
  const u = await user(), o = mkOrder(u); gw[o.tx] = 'paid';
  await Promise.all([order.refresh(load(o.id)), order.refresh(load(o.id)), order.refresh(load(o.id))]);
  assert.equal(ptCalls.length, 1); assert.equal(row(o.id).status, 'active');
});
test('PANEL: panel gagal -> failed; TIDAK retry sebelum jeda backoff; setelah jeda sukses', async () => {
  const u = await user(), o = mkOrder(u); gw[o.tx] = 'paid'; ptFail = true;
  assert.equal((await order.refresh(load(o.id))).status, 'failed'); assert.equal(row(o.id).attempts, 1);
  ptFail = false; await order.refresh(load(o.id)); assert.equal(ptCalls.length, 1, 'masih dalam jeda 30 dtk: jangan dicoba lagi'); assert.equal(row(o.id).status, 'failed');
  R("UPDATE orders SET updated_at=? WHERE id=?", ['2020-01-01 00:00:00', o.id]);
  assert.equal((await order.refresh(load(o.id))).status, 'active'); assert.equal(ptCalls.length, 2);
});
test('PANEL: percobaan habis (8x) berhenti otomatis; admin bisa mengulang (attempts direset)', async () => {
  const u = await user(), o = mkOrder(u, { pay_status: 'paid', status: 'failed' }); R('UPDATE orders SET attempts=8, updated_at=? WHERE id=?', ['2020-01-01 00:00:00', o.id]);
  await order.refresh(load(o.id)); assert.equal(ptCalls.length, 0); assert.equal(row(o.id).status, 'failed');
  R("UPDATE orders SET status='failed', attempts=0 WHERE id=?", [o.id]); await order.fulfill(o.id); assert.equal(row(o.id).status, 'active');
});
test('PANEL: proses macet (processing >3 menit) dipulihkan jadi failed lalu bisa diulang', async () => {
  const u = await user(), o = mkOrder(u, { pay_status: 'paid', status: 'processing' }); R('UPDATE orders SET updated_at=? WHERE id=?', ['2020-01-01 00:00:00', o.id]);
  assert.equal((await order.refresh(load(o.id))).status, 'failed');
});
test('PANEL: belum dibayar & lewat masa berlaku (+toleransi) & gateway bilang pending -> expired; gateway "paid" menang atas jam', async () => {
  const u = await user(), a = mkOrder(u, { exp: iso(-10 * 60e3) }), b = mkOrder(u, { exp: iso(-10 * 60e3) }); gw[a.tx] = 'pending'; gw[b.tx] = 'paid';
  assert.equal((await order.refresh(load(a.id))).pay_status, 'expired'); assert.equal((await order.refresh(load(b.id))).status, 'active');
});
test('PANEL: gateway error saat cek -> status TIDAK berubah (tidak salah menandai)', async () => {
  const u = await user(), o = mkOrder(u); gw[o.tx] = 'err'; const r = await order.refresh(load(o.id)); assert.equal(r.pay_status, 'pending');
});
test('PANEL: telat bayar (sudah kedaluwarsa/dibatalkan tapi uang masuk) tetap diproses', async () => {
  const u = await user(), a = mkOrder(u, { pay_status: 'expired' }), b = mkOrder(u, { pay_status: 'cancelled' }); gw[a.tx] = 'paid'; gw[b.tx] = 'paid';
  await order.late(load(a.id)); await order.late(load(b.id)); assert.equal(row(a.id).status, 'active'); assert.equal(row(b.id).status, 'active'); assert.equal(ptCalls.length, 2);
  const c = mkOrder(u, { pay_status: 'expired' }); gw[c.tx] = 'pending'; await order.late(load(c.id)); assert.equal(row(c.id).pay_status, 'expired');
});
test('PANEL: batal hanya untuk belum dibayar; jika ternyata sudah dibayar -> 409 & pesanan jalan terus', async () => {
  const u = await user(), a = mkOrder(u), b = mkOrder(u); gw[a.tx] = 'pending'; gw[b.tx] = 'paid';
  assert.equal((await order.cancel(u, a.id)).code, 200); assert.equal(row(a.id).pay_status, 'cancelled'); assert.equal(row(a.id).qr_image, null);
  const r = await order.cancel(u, b.id); assert.equal(r.code, 409); assert.equal(row(b.id).status, 'active');
  assert.equal((await order.cancel(u + 999, a.id)).code, 404, 'tidak bisa membatalkan pesanan orang lain');
});
test('PANEL: hasil order TAK PASTI (timeout/5xx) -> tidak dibeli ulang, tidak di-refund otomatis, masuk antrean admin', async () => {
  const u = await user(), o = mkOrder(u); gw[o.tx] = 'paid'; ptErr = new Error('timeout');
  assert.equal((await order.refresh(load(o.id))).status, 'failed'); assert.equal(row(o.id).attempts, 99, 'tidak ada retry otomatis');
  ptErr = null; R('UPDATE orders SET updated_at=? WHERE id=?', ['2020-01-01 00:00:00', o.id]); await order.refresh(load(o.id)); assert.equal(ptCalls.length, 1, 'tidak membeli ulang');
});
test('PANEL: sudah punya ID Averpay -> tidak pernah dipesan ulang walau fulfill dipanggil lagi; status ACTIVE menyelesaikan', async () => {
  const u = await user(), o = mkOrder(u); gw[o.tx] = 'paid'; ptStatus = 'PENDING';
  let r = await order.refresh(load(o.id)); assert.equal(r.status, 'processing'); assert.ok(r.provider_id); assert.equal(ptCalls.length, 1);
  await order.fulfill(o.id); await order.fulfill(o.id); assert.equal(ptCalls.length, 1, 'ID Averpay ada: tidak dipesan ulang');
  ptStatus = 'ACTIVE'; r = await order.refresh(load(o.id)); assert.equal(r.status, 'active'); assert.ok(row(o.id).activated_at); assert.equal(ptCalls.length, 1);
});
test('PANEL: Averpay menolak (FAILED) setelah ID dibuat -> failed tanpa retry otomatis', async () => {
  const u = await user(), o = mkOrder(u); gw[o.tx] = 'paid'; ptStatus = 'FAILED';
  assert.equal((await order.refresh(load(o.id))).status, 'failed'); assert.equal(row(o.id).attempts, 99);
});
test('PANEL: saldo Averpay belum masuk ("saldo tidak cukup") dicoba ulang sampai berhasil; email sudah dipakai -> alias unik', async () => {
  const u = await user(), o = mkOrder(u); gw[o.tx] = 'paid'; let k = 0; const orig = fakePanel.order;
  fakePanel.order = async (p) => { if (++k === 1) { ptCalls.push(p); throw Object.assign(new Error('x'), { status: 400, public: 'Saldo tidak cukup' }); } if (k === 2) { ptCalls.push(p); throw Object.assign(new Error('x'), { status: 400, public: 'Email sudah digunakan' }); } return orig(p); };
  try { assert.equal((await order.refresh(load(o.id))).status, 'active'); } finally { fakePanel.order = orig; }
  assert.equal(ptCalls.length, 3); assert.ok(/\+snw\d+@/.test(ptCalls[2].email), 'percobaan ke-3 memakai alias email'); assert.equal(row(o.id).attempts, 1);
});
test('RIWAYAT: hanya status akhir yang bisa disembunyikan; pesanan orang lain tidak bisa', async () => {
  const u = await user(), p = mkOrder(u), e = mkOrder(u, { pay_status: 'expired' }), a = mkOrder(u, { pay_status: 'paid', status: 'active' }), f = mkOrder(u, { pay_status: 'paid', status: 'failed' });
  assert.equal(await order.hide(u, p.id), false); assert.equal(await order.hide(u, f.id), false); assert.equal(await order.hide(u, e.id), true); assert.equal(await order.hide(u + 1, a.id), false); assert.equal(await order.hide(u, a.id), true);
  assert.equal(await order.hideAll(u, false), 0);
});

