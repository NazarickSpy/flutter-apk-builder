const test = require('node:test'), assert = require('node:assert/strict'), { json } = require('./helpers');
Object.assign(process.env, { PTERO_DOMAIN: 'https://panel.example', PTERO_PLTA: 'k', PTERO_NODE: '1', PTERO_NEST: '5', PTERO_EGG: '15' });
let log = [], routes;
global.fetch = async (url, o) => { const path = url.replace('https://panel.example/api/application', ''); log.push({ path, method: o.method || 'GET', body: o.body ? JSON.parse(o.body) : null }); return routes(path, o.method || 'GET'); };
const p = require('../lib/ptero');
const egg = { attributes: { docker_image: 'img', startup: 'node', relationships: { variables: { data: [{ attributes: { env_variable: 'A', default_value: 'x' } }] } } } };
const pkg = { memory: 1024, disk: 1024, cpu: 100 };
test.beforeEach(() => { log = []; p._reset(); });
test('server dengan external_id yang SUDAH ada dipakai ulang — tidak ada POST /servers (anti server dobel)', async () => {
  routes = (path) => path.startsWith('/servers/external/snw-o7') ? json(200, { attributes: { id: 321 } }) : json(500, {});
  assert.equal(await p.createServer(1, pkg, 'bot-user', 'snw-o7'), 321);
  assert.ok(!log.some((l) => l.method === 'POST'));
});
test('external_id belum ada (404) -> server dibuat dengan external_id', async () => {
  routes = (path, m) => path.startsWith('/servers/external/') ? json(404, { errors: [{ detail: 'nf' }] }) : path.startsWith('/nests/') ? json(200, egg) : path.includes('/allocations') ? json(200, { data: [{ attributes: { id: 9, assigned: false } }], meta: { pagination: { total_pages: 1 } } }) : m === 'POST' ? json(201, { attributes: { id: 555 } }) : json(500, {});
  assert.equal(await p.createServer(1, pkg, 'bot-user', 'snw-o8'), 555);
  const post = log.find((l) => l.method === 'POST'); assert.equal(post.body.external_id, 'snw-o8'); assert.equal(post.body.allocation.default, 9);
});
test('allocation kosong dicari di halaman berikutnya (bukan hanya 500 pertama)', async () => {
  routes = (path, m) => path.startsWith('/nests/') ? json(200, egg) : path.includes('page=1') ? json(200, { data: [{ attributes: { id: 1, assigned: true } }], meta: { pagination: { total_pages: 2 } } }) : path.includes('page=2') ? json(200, { data: [{ attributes: { id: 2, assigned: false } }], meta: { pagination: { total_pages: 2 } } }) : m === 'POST' ? json(201, { attributes: { id: 1 } }) : json(404, {});
  await p.createServer(1, pkg, 'n'); assert.equal(log.find((l) => l.method === 'POST').body.allocation.default, 2);
});
test('tidak ada allocation kosong -> error jelas', async () => {
  routes = (path) => path.startsWith('/nests/') ? json(200, egg) : json(200, { data: [{ attributes: { id: 1, assigned: true } }], meta: { pagination: { total_pages: 1 } } });
  await assert.rejects(p.createServer(1, pkg, 'n'), /allocation/i);
});
test('deleteServer: 404 dianggap sudah terhapus; error lain dilempar', async () => {
  routes = () => json(404, {}); await p.deleteServer(5);
  routes = () => json(500, {}); await assert.rejects(p.deleteServer(5));
});

// ---------- keamanan akun panel: tidak boleh menautkan/mereset akun milik orang lain ----------
test('ensureUser: email yang SUDAH ada di panel (milik orang lain / cocok sebagian) TIDAK ditautkan; dibuat akun baru dengan alias', async () => {
  routes = (path, m) => {
    if (path.startsWith('/users/external/')) return json(404, {});
    if (path.startsWith('/users?filter')) return json(200, { data: [{ attributes: { id: 77, email: 'korban@mail.com', username: 'korban' } }, { attributes: { id: 78, email: 'xkorban@mail.com', username: 'x' } }] });
    if (path === '/users' && m === 'POST') return json(201, { attributes: { id: 900 } });
    return json(500, {});
  };
  const r = await p.ensureUser({ id: 5, email: 'Korban@Mail.com', username: 'penyerang' });
  assert.equal(r.id, 900, 'harus akun BARU, bukan 77'); assert.ok(r.password);
  const post = log.find((l) => l.method === 'POST' && l.path === '/users');
  assert.equal(post.body.external_id, 'snw-u5'); assert.notEqual(post.body.email.toLowerCase(), 'korban@mail.com'); assert.match(post.body.email, /@snowystore\.local$/);
});
test('ensureUser: email bebas dipakai apa adanya; hasil pencarian sebagian (substring) tidak dianggap sama', async () => {
  routes = (path, m) => path.startsWith('/users/external/') ? json(404, {}) : path.startsWith('/users?filter') ? json(200, { data: [{ attributes: { id: 78, email: 'xbudi@mail.com' } }] }) : m === 'POST' ? json(201, { attributes: { id: 901 } }) : json(500, {});
  assert.equal((await p.ensureUser({ id: 6, email: 'budi@mail.com', username: 'budi' })).id, 901);
  assert.equal(log.find((l) => l.method === 'POST').body.email, 'budi@mail.com');
});
test('ensureUser: idempotent via external_id (request sebelumnya timeout padahal akun sudah dibuat) -> tidak membuat akun dobel', async () => {
  routes = (path) => path.startsWith('/users/external/snw-u9') ? json(200, { attributes: { id: 555 } }) : json(500, {});
  assert.equal((await p.ensureUser({ id: 9, email: 'a@b.c', username: 'a' })).id, 555); assert.ok(!log.some((l) => l.method === 'POST'));
});
test('ensureUser: username bentrok di panel (422) -> dicoba lagi dengan akhiran acak', async () => {
  let n = 0; routes = (path, m) => path.startsWith('/users/external/') ? json(404, {}) : path.startsWith('/users?filter') ? json(200, { data: [] }) : m === 'POST' ? (++n === 1 ? json(422, { errors: [{ detail: 'username taken' }] }) : json(201, { attributes: { id: 902 } })) : json(500, {});
  assert.equal((await p.ensureUser({ id: 7, email: 'z@z.z', username: 'zed' })).id, 902); assert.notEqual(log.filter((l) => l.method === 'POST')[1].body.username, 'zed');
});
test('resetPassword: akun panel BUKAN milik user ditolak (403) dan tidak diubah', async () => {
  routes = (path) => path === '/users/77' ? json(200, { attributes: { id: 77, email: 'korban@mail.com', username: 'korban', first_name: 'k', last_name: 'k', external_id: 'snw-u1' } }) : json(500, {});
  await assert.rejects(p.resetPassword(77, { id: 5, username: 'penyerang', email: 'korban@mail.com' }), (e) => e.status === 403);
  assert.ok(!log.some((l) => l.method === 'PATCH'), 'tidak boleh ada perubahan password');
});
test('resetPassword: akun milik sendiri (external_id cocok, atau akun lama username+email sama) boleh direset', async () => {
  routes = (path, m) => path === '/users/80' ? (m === 'PATCH' ? json(200, {}) : json(200, { attributes: { id: 80, email: 'me@m.m', username: 'me', first_name: 'me', last_name: 'S', external_id: 'snw-u3' } })) : path === '/users/81' ? (m === 'PATCH' ? json(200, {}) : json(200, { attributes: { id: 81, email: 'Old@M.m', username: 'old', first_name: 'o', last_name: 'S', external_id: null } })) : json(500, {});
  assert.ok((await p.resetPassword(80, { id: 3, username: 'me', email: 'me@m.m' })).length >= 8);
  assert.ok((await p.resetPassword(81, { id: 4, username: 'old', email: 'old@m.m' })).length >= 8);
});
