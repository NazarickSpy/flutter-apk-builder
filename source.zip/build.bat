@echo off
rem Build APK SnowyStore (Windows). Pemakaian: build.bat https://domainmu.com [APP_KEY]
setlocal
cd /d "%~dp0"
if "%~1"=="" ( echo Pemakaian: build.bat https://domainmu.com [APP_KEY] & exit /b 1 )
where flutter >nul 2>nul || ( echo Flutter SDK tidak ditemukan. & exit /b 1 )
if not exist android (
  echo ==^> Membuat platform android
  if exist .lib_backup rmdir /s /q .lib_backup
  xcopy /e /i /q lib .lib_backup >nul
  call flutter create --platforms=android --org id.snowystore --project-name snowystore_app . || exit /b 1
  rmdir /s /q lib
  move .lib_backup lib >nul
  if exist test\widget_test.dart del test\widget_test.dart
)
set FLAG=
echo %~1| findstr /b /i "http://" >nul && set FLAG=--cleartext
call dart run tool/patch_android.dart %FLAG% || exit /b 1
call flutter pub get || exit /b 1
set DEFS=--dart-define=API_BASE=%~1
if not "%~2"=="" set DEFS=%DEFS% --dart-define=APP_KEY=%~2
call flutter build apk --release %DEFS% || exit /b 1
echo.
echo Selesai: build\app\outputs\flutter-apk\app-release.apk
