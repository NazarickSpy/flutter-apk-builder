module.exports = { env: { SITE_URL: process.env.APP_URL || 'https://snowystore.my.id', CONTACT_WA: process.env.CONTACT_WA || '', CONTACT_EMAIL: process.env.CONTACT_EMAIL || '', CONTACT_ADDRESS: process.env.CONTACT_ADDRESS || '' }, // dibaca saat build dari .env
  reactStrictMode: true, poweredByHeader: false, productionBrowserSourceMaps: false, compiler: { removeConsole: { exclude: ['error'] } }, // tanpa sourcemap & tanpa console.log di bundle klien
 
  // robots.txt dinamis lewat rewrite (BUKAN pages/robots.txt.js): bila file lama public/robots.txt masih ada di server (upload zip tidak menghapus file lama),
  // Next.js tidak lagi error 'Conflicting public and page file', dan rewrite beforeFiles mengalahkan file statis lama itu.
  async rewrites() { return { beforeFiles: [{ source: '/robots.txt', destination: '/robots-txt' }], afterFiles: [], fallback: [] }; },
  async headers() { return [{ source: '/img/:path*', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] }]; } };
