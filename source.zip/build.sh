#!/usr/bin/env bash
# Build APK SnowyStore. Pemakaian:
#   ./build.sh https://domainmu.com [APP_KEY]
# Butuh Flutter SDK >= 3.22 (flutter doctor harus OK untuk Android). Hasil: build/app/outputs/flutter-apk/app-release.apk
set -euo pipefail
cd "$(dirname "$0")"
BASE="${1:-}"; KEY="${2:-}"
[ -z "$BASE" ] && { echo "Pemakaian: ./build.sh https://domainmu.com [APP_KEY]"; exit 1; }
case "$BASE" in http://*|https://*) ;; *) echo "Alamat harus diawali http:// atau https://"; exit 1;; esac

command -v flutter >/dev/null || { echo "Flutter SDK tidak ditemukan. Pasang dari https://docs.flutter.dev/get-started/install"; exit 1; }

if [ ! -d android ]; then
  echo "==> Membuat platform android (flutter create)"
  rm -rf .lib_backup && cp -r lib .lib_backup          # jaga kode app dari timpaan template
  flutter create --platforms=android --org id.snowystore --project-name snowystore_app .
  rm -rf lib && mv .lib_backup lib
  rm -f test/widget_test.dart                          # template bawaan merujuk MyApp yang tidak ada
fi

FLAG=""; case "$BASE" in http://*) FLAG="--cleartext"; echo "PERINGATAN: http:// tidak terenkripsi, hanya untuk uji coba.";; esac
dart run tool/patch_android.dart $FLAG

flutter pub get
DEFS=(--dart-define="API_BASE=$BASE"); [ -n "$KEY" ] && DEFS+=(--dart-define="APP_KEY=$KEY")
flutter build apk --release "${DEFS[@]}"
echo; echo "Selesai: build/app/outputs/flutter-apk/app-release.apk"
