import { useState, useMemo } from 'react';
import { Cpu, MemoryStick, Layers, Boxes, Clock, Hexagon, MonitorCog } from 'lucide-react';
import { api, compact, ago, upfmt } from './api';
import { usePoll, useCountUp } from './hooks';

export function useLive(ms = 10000) {
  const [d, setD] = useState(null), [err, setErr] = useState(false);
  usePoll(async () => { try { setD(await api('/live', 'GET', null, { timeout: 8000 })); setErr(false); } catch { setErr(true); } }, ms);
  return { d, err };
}
export const Num = ({ v, fmt = (x) => x.toLocaleString('id-ID') }) => { const n = useCountUp(Number.isFinite(v) ? v : 0); return <>{Number.isFinite(v) ? fmt(n) : '-'}</>; };

// Kurva halus (Catmull-Rom -> bezier) dari 24 titik; viewBox tetap, garis digambar bertahap (stroke-dashoffset)
function Sparkline({ data }) {
  const W = 300, H = 90, P = 6, max = Math.max(3, ...data);
  const pts = useMemo(() => data.map((v, i) => [P + (i * (W - P * 2)) / (data.length - 1), H - P - (v / max) * (H - P * 2 - 4)]), [data, max]);
  const path = useMemo(() => { let d = `M${pts[0][0]},${pts[0][1]}`; for (let i = 0; i < pts.length - 1; i++) { const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2; d += ` C${(p1[0] + (p2[0] - p0[0]) / 6).toFixed(1)},${Math.min(H - P, Math.max(P, p1[1] + (p2[1] - p0[1]) / 6)).toFixed(1)} ${(p2[0] - (p3[0] - p1[0]) / 6).toFixed(1)},${Math.min(H - P, Math.max(P, p2[1] - (p3[1] - p1[1]) / 6)).toFixed(1)} ${p2[0]},${p2[1]}`; } return d; }, [pts]);
  const last = pts[pts.length - 1];
  return (<svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label="Grafik jumlah pesanan per jam dalam 24 jam terakhir">
    <defs><linearGradient id="spg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style={{ stopColor: 'var(--primary)' }} stopOpacity=".28" /><stop offset="1" style={{ stopColor: 'var(--primary)' }} stopOpacity="0" /></linearGradient></defs>
    <path className="ar" d={`${path} L${last[0]},${H} L${pts[0][0]},${H}Z`} /><path className="ln" d={path} pathLength="1" vectorEffect="non-scaling-stroke" /><circle className="pt" cx={last[0]} cy={last[1]} r="3.4" /></svg>);
}
const KLBL = { panel: 'PANEL', premium: 'PREMIUM', nokos: 'OTP' };
export function LivePanel({ d, err }) {
  const hourly = d ? d.hourly : Array(24).fill(0), now = hourly[23], load = d ? d.system.cpu : 0;
  return (<div className="card live" aria-busy={!d}>
    <div className="live-h"><b><i className={'live-dot' + (err ? ' off' : '')} />Aktivitas Server</b><span className="live-tag">{err ? 'OFFLINE' : 'LIVE'}</span></div>
    <div className="live-main"><span className="cap">Pesanan / 24 jam</span>
      <div className="live-big"><strong><Num v={d ? d.orders_24h : NaN} /></strong></div>
      <div className="live-sub"><span>Jam ini {d ? now : '-'}</span><span>Puncak {d ? d.peak_hour : '-'}/jam</span></div>
      <div className="spark"><div className="sp-h"><b><Num v={d ? now : NaN} /></b>pesanan / jam ini · puncak {d ? d.peak_hour : '-'}</div><Sparkline data={hourly} /><div className="ax"><span>24 jam lalu</span><span>sekarang</span></div></div></div>
    <div className="kpis">
      <div className="kpi"><span className="cap">Total Pesanan</span><strong><Num v={d ? d.orders_total : NaN} fmt={compact} /></strong></div>
      <div className="kpi"><span className="cap">Server Aktif</span><strong><Num v={d ? d.panels_active : NaN} fmt={compact} /></strong></div>
      <div className="kpi"><span className="cap">Member</span><strong><Num v={d ? d.members : NaN} fmt={compact} /></strong></div>
      <div className="kpi"><span className="cap">Layanan Teratas</span><strong className="txt">{d && d.top ? d.top.label : '-'}</strong>{d && d.top ? <small className="mut">{d.top.n}× / 24 jam</small> : null}</div></div>
    <div className="feed"><div className="feed-h cap">Terakhir diproses</div>
      {d && d.recent.length ? d.recent.map((x, i) => <div className="feed-i" key={i} style={{ animationDelay: i * 60 + 'ms' }}><span className="feed-k">{KLBL[x.kind] || 'CMD'}</span><b>{x.name}</b><small className="mut">{ago(x.at)}</small></div>) : <div className="feed-i"><small className="mut">{d ? 'Belum ada pesanan selesai.' : 'Memuat aktivitas…'}</small></div>}</div>
    <div className="live-f"><span className="pill-s"><i className={'live-dot' + (err ? ' off' : '')} />Server</span><b><Num v={d ? d.orders_total : NaN} fmt={compact} /> pesanan</b>
      <div className="load">LOAD <div className={'bar' + (load > 85 ? ' bad' : load > 65 ? ' warn' : '')} style={{ '--w': load / 100 }}><i /></div><b>{d ? load : '-'}%</b></div></div>
  </div>);
}
const Bar = ({ pct }) => <div className={'bar' + (pct > 90 ? ' bad' : pct > 75 ? ' warn' : '')} style={{ '--w': Math.min(1, pct / 100) }}><i /></div>;
export function SystemInfo({ d }) {
  const y = d && d.system, hp = y ? (y.heap_used / y.heap_limit) * 100 : 0;
  const C = ({ I, t, children, c = '' }) => <div className={'card sysc ' + c}><div className="sh2"><I size={22} /><b>{t}</b></div>{children}</div>;
  return (<div className="sysgrid" aria-busy={!d}>
    <C I={Cpu} t="Penggunaan CPU" c="wide"><Bar pct={y ? y.cpu : 0} /><small className="mut" style={{ display: 'block', marginTop: 10 }}>{y ? `${y.cores} Core` : 'Memuat…'}</small><div className="v"><Num v={y ? y.cpu : NaN} fmt={(x) => x + '%'} /></div></C>
    <C I={MemoryStick} t="Memori Heap" c="wide"><Bar pct={hp} /><small className="mut" style={{ display: 'block', marginTop: 10 }}>{y ? `Total Memori Sistem : ${y.mem_total_gb} GB` : 'Memuat…'}</small><div className="v">{y ? `${y.heap_used} MB / ${y.heap_limit} MB` : '-'}</div></C>
    <C I={Layers} t="Memori Proses (RSS)" c="two"><div className="v">{y ? `${y.rss} MB` : '-'}</div></C>
    <C I={Boxes} t="Array Buffer" c="two"><div className="v">{y ? `${y.array_buffers} MB` : '-'}</div></C>
    <C I={Clock} t="Waktu Aktif Server" c="two"><div className="v">{y ? upfmt(y.uptime) : '-'}</div></C>
    <C I={Hexagon} t="Mesin Node.js" c="two"><div className="v">{y ? y.node : '-'}</div></C>
    <C I={MonitorCog} t="Sistem Operasi" c="wide two"><div className="v">{y ? y.os : '-'}</div></C>
  </div>);
}
