import Link from 'next/link';
import { useEffect, useRef, useState, useCallback } from 'react';
import { Bell, Smartphone, MapPin, Globe, ShieldAlert, ShieldCheck, Server, Gem, LifeBuoy, LogIn, BellOff, CheckCheck } from 'lucide-react';
import { api, ago } from './api';
import { usePoll } from './hooks';
import { toast } from './Toast';

// Penyimpanan modul: perpindahan halaman tidak mengosongkan lonceng (tidak berkedip), dan toast tidak diulang untuk item yang sama.
const store = { items: [], unread: 0, loaded: false, toasted: new Set(), subs: new Set() };
const emit = () => store.subs.forEach((f) => f({ items: store.items, unread: store.unread, loaded: store.loaded }));
export async function refreshNotifs(silent) {
  const d = await api('/notifications'); const fresh = d.items.filter((n) => n.unread && !store.toasted.has(n.id));
  if (store.loaded && !silent) fresh.filter((n) => n.level === 'warn' || n.level === 'bad').slice(0, 2).forEach((n) => toast(n.level === 'bad' ? 'error' : 'warning', n.title, n.text, { key: n.id }));
  d.items.forEach((n) => store.toasted.add(n.id)); const grew = d.unread > store.unread;
  store.items = d.items; store.unread = d.unread; store.loaded = true; emit(); return { grew };
}
export function useNotifs(poll = true) {
  const [s, setS] = useState({ items: store.items, unread: store.unread, loaded: store.loaded }), [ring, setRing] = useState(false);
  useEffect(() => { store.subs.add(setS); setS({ items: store.items, unread: store.unread, loaded: store.loaded }); return () => store.subs.delete(setS); }, []);
  usePoll(async () => { if (!poll) return; const { grew } = await refreshNotifs(); if (grew) { setRing(true); setTimeout(() => setRing(false), 900); } }, poll ? 45000 : 86400e3, [poll]);
  const readAll = useCallback(async () => { store.items = store.items.map((n) => ({ ...n, unread: false })); store.unread = 0; emit(); try { await api('/notifications/read', 'POST'); } catch {} }, []);
  return { ...s, ring, readAll, reload: () => refreshNotifs(true) };
}
const KIND = { login: LogIn, login_fail: ShieldAlert, security: ShieldCheck, order: Server, premium: Gem, nokos: Smartphone, claim: LifeBuoy };
const TAG = { device: Smartphone, ip: MapPin, browser: Globe };
export function NotifItem({ n, onClick }) {
  const I = KIND[n.kind] || Bell;
  return (<Link href={n.href || '/notifikasi'} className={`nt l-${n.level}${n.unread ? ' un' : ''}`} onClick={onClick}>
    <span className="nt-i"><I size={19} /></span>
    <div className="nt-b"><div className="nt-t"><b>{n.title}</b><time dateTime={n.at}>{ago(n.at)}</time></div><p className="nt-x">{n.text}</p>
      {n.tags && n.tags.length ? <div className="ntags">{n.tags.map((t) => { const T = TAG[t.k] || Globe; return <span className="ntag" key={t.k}><T size={12} />{t.label}</span>; })}</div> : null}</div></Link>);
}
export const NotifEmpty = () => <div className="nt-empty"><BellOff size={30} /><b>Belum ada notifikasi</b><small>Aktivitas login dan status pesanan akan muncul di sini.</small></div>;

export default function Bell_({ open, setOpen }) {
  const { items, unread, loaded, ring, readAll } = useNotifs(true), btn = useRef(null);
  useEffect(() => { if (!open) return undefined; const k = (e) => { if (e.key === 'Escape') { setOpen(false); btn.current && btn.current.focus(); } }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [open, setOpen]);
  return (<>
    <button ref={btn} className={'bell' + (ring ? ' ring' : '')} onClick={() => setOpen(!open)} aria-haspopup="dialog" aria-expanded={open} aria-label={unread ? `Notifikasi, ${unread} belum dibaca` : 'Notifikasi'}><Bell size={19} />{unread > 0 && <span className="dot" aria-hidden="true" />}</button>
    {open && <><div className="pop-ov" onClick={() => setOpen(false)} /><div className="pop" role="dialog" aria-label="Notifikasi">
      <div className="pop-h"><b>Notifikasi</b><button onClick={readAll} disabled={!unread}><CheckCheck size={14} className="vm" /> Tandai semua dibaca</button></div>
      <div className="pop-b">{!loaded ? <div style={{ padding: 16, display: 'grid', gap: 10 }}><div className="sk l2" /><div className="sk l1" /><div className="sk l2" /></div> : items.length === 0 ? <NotifEmpty /> : items.slice(0, 8).map((n) => <NotifItem key={n.id} n={n} onClick={() => setOpen(false)} />)}</div>
      <Link href="/notifikasi" className="pop-f" onClick={() => setOpen(false)}>Lihat semua notifikasi</Link></div></>}
  </>);
}
