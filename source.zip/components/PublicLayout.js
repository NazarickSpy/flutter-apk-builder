import Link from 'next/link';
import Head from 'next/head';
import Brand from './Brand';
import PublicNav from './PublicNav';
import JsonLd from './JsonLd';
import FooterContact from './FooterContact';
import { crumbSchema } from './site';
const LINKS = [['/cara-order', 'Cara Order'], ['/garansi', 'Garansi'], ['/status', 'Status'], ['/bantuan', 'Bantuan'], ['/produk', 'Katalog'], ['/panduan', 'Panduan'], ['/tentang', 'Tentang'], ['/kontak', 'Kontak'], ['/terms', 'Ketentuan']];
// Kerangka halaman publik (tanpa login): navbar + konten + footer
export default function PublicLayout({ title, sub, desc, children, crumbs, og }) {
  const full = `${title} | SnowyStore`;
  return (<div className="pubpage">
    <Head><title>{full}</title>{desc && <meta name="description" content={desc} />}
      <meta property="og:title" content={full} />{desc && <meta property="og:description" content={desc} />}<meta property="og:type" content={og || 'website'} /><meta property="og:site_name" content="SnowyStore" /><meta property="og:locale" content="id_ID" /><meta name="twitter:card" content="summary" /></Head>
    {crumbs ? <JsonLd id="ld-crumbs" data={crumbSchema(crumbs)} /> : null}
    <PublicNav sub={sub} />
    <main className="pub pg-in" id="konten">{children}</main>
    <footer className="ftr"><Brand /><p className="mut">Toko digital untuk aplikasi premium, nomor virtual OTP, dan hosting server panel. Pembayaran QRIS dan pemrosesan otomatis.</p>
      <div className="flinks">{LINKS.map(([h, l]) => <Link key={h} href={h}>{l}</Link>)}</div>
      <FooterContact />
      <p className="mut center fine">© 2026 SnowyStore Platform. Seluruh hak cipta dilindungi.</p></footer></div>);
}
