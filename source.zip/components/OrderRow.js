import Link from 'next/link';
import { Copy, Check, Trash2, Ban, ShieldCheck, QrCode, Info } from 'lucide-react';
import { rp, fdate, STATE, CLAIM, HINT } from './api';
// Satu baris pesanan (dipakai di Dashboard & halaman Riwayat). Aksi menyesuaikan status.
export default function OrderRow({ o, copied, onCopy, onPay, onCancel, onDelete }) {
  const w = o.warranty, open = o.claim && ['pending', 'processing'].includes(o.claim.status);
  return (<div className="ord2">
    <div className="ordtop"><div className="ordn"><b>{o.server_name}</b><small className="mut">{(o.pkg && o.pkg.name) || `Paket ${o.package_key.toUpperCase()}`} - {rp(o.price)}</small>{o.pkg && o.pkg.ram ? <small className="mut">RAM {o.pkg.ram / 1024} GB - Disk {Math.round((o.pkg.disk || o.pkg.ram) / 1024)} GB{o.pkg.cpu ? ` - CPU ${o.pkg.cpu}%` : ''}</small> : null}</div><span className={'stt ' + o.state}>{STATE[o.state]}</span></div>
    <div className="ordmeta">
      <button className="trx mono" onClick={() => onCopy(o.trx)} aria-label="Salin TRX ID">{copied === o.trx ? <Check size={13} /> : <Copy size={13} />}{o.trx}</button>
      <small className="mut">{fdate(o.created_at)}</small>
      {o.legacy && o.server_id ? <small className="mut">Server ID #{o.server_id}</small> : null}
      {o.panel_user ? <small className="mut">Panel: {o.panel_user}</small> : null}
    </div>
    {HINT[o.state] && <small className="hint"><Info size={14} />{HINT[o.state]}</small>}
    {o.state === 'active' && !o.legacy && !w && <small className="wty"><Info size={14} />{o.panel_expires_at ? `Aktif sampai ${fdate(o.panel_expires_at)} - non-garansi` : 'Non-garansi - dihapus otomatis saat masa aktif berakhir'}</small>}
    {o.state === 'active' && w && <small className={'wty' + (w.eligible ? ' ok' : '')}><ShieldCheck size={14} />{open ? `Klaim garansi: ${CLAIM[o.claim.status]}` : w.eligible ? `Garansi aktif - ${w.days_left} hari lagi${w.bonus ? ` (+${w.bonus} hari kompensasi)` : ''}` : w.reason}</small>}
    {o.claim && !open && o.claim.status !== 'done' && o.state === 'active' && <small className="mut"><Info size={13} className="vm" /> Klaim terakhir: {CLAIM[o.claim.status]}{o.claim.admin_note ? ` - ${o.claim.admin_note}` : ''}</small>}
    <div className="ordact">
      {o.state === 'unpaid' && <><button className="chip pri" onClick={() => onPay(o.id)}><QrCode size={15} />Bayar</button><button className="chip danger" onClick={() => onCancel(o)}><Ban size={15} />Batalkan</button></>}
      {['processing', 'failed'].includes(o.state) && <button className="chip" onClick={() => onPay(o.id)}>Detail</button>}
      {o.state === 'active' && o.legacy && <Link href={`/garansi?trx=${o.trx}`} className="chip"><ShieldCheck size={15} />Garansi</Link>}
      {['active', 'expired', 'cancelled'].includes(o.state) && <button className="chip danger" onClick={() => onDelete(o)}><Trash2 size={15} />Hapus</button>}
    </div>
  </div>);
}
