import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
// Bottom-sheet: kunci scroll halaman di belakang, Esc untuk tutup, isi bisa scroll sendiri (aman di layar kecil / zoom besar)
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
export default function Modal({ onClose, children, label, locked }) {
  const box = useRef(null), [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);
  useEffect(() => { // fokus masuk ke dialog dan kembali ke pemicu saat ditutup (OpenWA modalA11y)
    if (!mounted) return undefined;
    const opener = document.activeElement, el = box.current; if (el) { const f = el.querySelector(FOCUSABLE); (f || el).focus({ preventScroll: true }); }
    return () => { if (opener && opener.focus && document.contains(opener)) opener.focus({ preventScroll: true }); };
  }, [mounted]);
  useEffect(() => {
    const prev = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const k = (e) => {
      if (e.key === 'Escape' && !locked && onClose) { onClose(); return; }
      if (e.key !== 'Tab' || !box.current) return; // focus trap
      const f = [...box.current.querySelectorAll(FOCUSABLE)].filter((x) => x.offsetParent !== null); if (!f.length) { e.preventDefault(); return; }
      const a = f[0], z = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === a || !box.current.contains(document.activeElement))) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
    };
    window.addEventListener('keydown', k);
    return () => { document.body.style.overflow = prev; window.removeEventListener('keydown', k); };
  }, [onClose, locked]);
  if (!mounted) return null;
  return createPortal(<div className="modal" onClick={() => { if (!locked && onClose) onClose(); }}>
    <div className="sheet" ref={box} tabIndex={-1} role="dialog" aria-modal="true" aria-label={label} onClick={(e) => e.stopPropagation()}><div className="grab" />{children}</div></div>, document.body);
}
