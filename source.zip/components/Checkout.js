import { useCallback, useEffect, useRef, useState } from 'react';
import { CircleCheck, CircleX, LoaderCircle, Ban } from 'lucide-react';
import { api, rp, fmt, copyText } from './api';
import Modal from './Modal';
import QR from './QR';

// Polling berantai (bukan setInterval) -> tidak pernah ada request numpuk. QR diambil sekali saja, polling berikutnya ringan.
export default function Checkout({ id, initial, onClose, onChange }) {
  const [o, setO] = useState(initial || null), [err, setErr] = useState(''), [left, setLeft] = useState(0), [ask, setAsk] = useState(false), [busy, setBusy] = useState(false), [cp, setCp] = useState(false);
  const qr = useRef(initial?.qr_image ? { img: initial.qr_image } : null), last = useRef(initial ? initial.state : null), alive = useRef(true), timer = useRef(null), cb = useRef(onChange);
  cb.current = onChange;

  const poll = useCallback(async () => {
    clearTimeout(timer.current);
    let next = 3500;
    try {
      const d = await api(`/orders/${id}${qr.current ? '' : '?qr=1'}`);
      if (!alive.current) return;
      if (d.qr_image) qr.current = { img: d.qr_image };
      setErr(''); setO(d);
      if (last.current && last.current !== d.state && cb.current) cb.current();
      last.current = d.state;
      if (!['unpaid', 'processing'].includes(d.state)) return; // status akhir: berhenti polling
    } catch (e) {
      if (!alive.current) return;
      setErr(e.message);
      if (e.status === 401 || e.status === 404) return;
      next = 6000; // gangguan sementara: tetap coba lagi otomatis
    }
    if (typeof document !== 'undefined' && document.hidden) next = Math.max(next, 15000); // tab tidak terlihat: kurangi beban server & gateway
    timer.current = setTimeout(poll, next);
  }, [id]);
  useEffect(() => { alive.current = true; if (initial) timer.current = setTimeout(poll, 2500); else poll(); return () => { alive.current = false; clearTimeout(timer.current); }; }, [poll]); // eslint-disable-line
  useEffect(() => {
    if (!o?.expires_at) return;
    const tick = () => setLeft(Math.max(0, Math.floor((new Date(o.expires_at) - Date.now()) / 1000))); tick();
    const c = setInterval(tick, 1000); return () => clearInterval(c);
  }, [o?.expires_at]);

  const cancel = async () => {
    setBusy(true);
    try { await api(`/orders/${id}/cancel`, 'POST'); setErr(''); } catch (e) { setErr(e.message); }
    setAsk(false); await poll(); setBusy(false);
  };
  const copy = async () => { if (o?.trx && (await copyText(o.trx))) { setCp(true); setTimeout(() => setCp(false), 1500); } };
  const st = o?.state;
  return (<Modal onClose={onClose} label="Pembayaran Pesanan" locked={busy}>
    <h3 className="center">Pembayaran Pesanan</h3>
    {o && <p className="mut center meta">{o.server_name} - Paket {o.package_key.toUpperCase()}<br /><button className="linkbtn mono" onClick={copy}>{cp ? 'TRX ID disalin ✓' : 'TRX: ' + o.trx}</button></p>}
    {err && <div className="msg e">{err} {!['expired', 'cancelled'].includes(st) && <button className="linkbtn" onClick={() => { setErr(''); poll(); }}>Coba lagi</button>}</div>}
    {!o && !err && <div className="center loading"><LoaderCircle size={20} className="spin" /> Memuat pesanan…</div>}

    {st === 'unpaid' && <>
      {qr.current ? <QR src={qr.current.img} name={o.trx} /> : <div className="center loading"><LoaderCircle size={20} className="spin" /> Menyiapkan QRIS…</div>}
      <div className="big">{rp(o.total)}</div>
      <p className="mut center small">Bayar <b>sesuai nominal persis</b> (sudah termasuk biaya layanan).<br />{left > 0 ? <>Berlaku <b className="mono">{fmt(left)}</b> - pembayaran terdeteksi otomatis</> : 'Waktu habis - memeriksa pembayaran terakhir…'}</p>
      {!ask ? <button className="btn full ghost dangertxt" onClick={() => setAsk(true)}><Ban size={18} />Batalkan pesanan</button>
        : <div className="askrow"><span>Batalkan pesanan ini?</span><div className="two"><button className="btn ghost" disabled={busy} onClick={() => setAsk(false)}>Tidak</button><button className="btn red" disabled={busy} onClick={cancel}>{busy ? 'Membatalkan…' : 'Ya, Batalkan'}</button></div></div>}</>}
    {st === 'processing' && <div className="msg s center"><LoaderCircle size={20} className="spin" /> Pembayaran diterima. Server sedang dibuat…</div>}
    {st === 'active' && <div className="msg s center"><CircleCheck size={20} className="vm" /> Server aktif! Login panel ada di menu <b>Akun Panel</b> pada dashboard.</div>}
    {st === 'failed' && <div className="msg e center">Pembayaran diterima, namun server belum berhasil dibuat. Sistem mencoba ulang otomatis; bila belum aktif, hubungi bantuan dengan nomor <b>{o.trx}</b>.</div>}
    {st === 'expired' && <div className="msg e center"><CircleX size={20} className="vm" /> QRIS kedaluwarsa. Silakan buat pesanan baru.</div>}
    {st === 'cancelled' && <div className="msg e center"><Ban size={20} className="vm" /> Pesanan dibatalkan. Jangan bayar QRIS ini lagi.</div>}
    <button className="btn full ghost" disabled={busy} onClick={onClose}>{st === 'active' ? 'Selesai' : 'Tutup'}</button>
  </Modal>);
}
