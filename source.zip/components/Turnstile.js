import { useEffect, useRef } from 'react';
// Widget Cloudflare Turnstile (mode managed: biasanya tercentang otomatis; hanya menampilkan tantangan bila perlu).
// Token sekali pakai: setelah percobaan gagal, naikkan `resetNonce` agar widget memuat token baru.
let loading = null;
const load = () => loading || (loading = new Promise((res, rej) => {
  if (typeof window === 'undefined') return rej(new Error('ssr'));
  if (window.turnstile) return res(window.turnstile);
  const s = document.createElement('script'); s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit'; s.async = true; s.defer = true;
  s.onload = () => res(window.turnstile); s.onerror = () => { loading = null; rej(new Error('load')); }; document.head.appendChild(s);
}));
export default function Turnstile({ siteKey, onToken, onError, resetNonce = 0 }) {
  const box = useRef(null), wid = useRef(null);
  useEffect(() => {
    if (!siteKey) return undefined; let dead = false;
    load().then((t) => { if (dead || !box.current) return; wid.current = t.render(box.current, { sitekey: siteKey, language: 'id', size: 'flexible', callback: (tok) => onToken(tok), 'expired-callback': () => onToken(''), 'error-callback': () => { onToken(''); if (onError) onError(); } }); }).catch(() => { if (onError) onError(); });
    return () => { dead = true; try { if (wid.current != null && window.turnstile) window.turnstile.remove(wid.current); } catch {} wid.current = null; };
  }, [siteKey]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (resetNonce && wid.current != null && window.turnstile) { try { window.turnstile.reset(wid.current); } catch {} onToken(''); } }, [resetNonce]); // eslint-disable-line react-hooks/exhaustive-deps
  return siteKey ? <div className="cfbox" ref={box} /> : null;
}
