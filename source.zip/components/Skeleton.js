// Kerangka loading (shimmer): menggantikan teks "Memuat…" supaya layout tidak melompat
export const Sk = ({ c = 'l1', style }) => <div className={'sk ' + c} style={style} aria-hidden="true" />;
export function SkCard({ rows = 3 }) { return (<div className="card skcard" aria-hidden="true"><Sk c="h" />{Array.from({ length: rows }).map((_, i) => <Sk key={i} c={i % 2 ? 'l1' : 'l2'} />)}</div>); }
export default function PageSkeleton({ cards = 3 }) {
  return (<div className="wrap" role="status" aria-label="Memuat halaman"><div className="card hdc" aria-hidden="true"><Sk c="circ" /><div style={{ flex: 1 }}><Sk c="h" /><Sk c="l2" style={{ marginTop: 8 }} /></div></div>{Array.from({ length: cards }).map((_, i) => <SkCard key={i} rows={i === 0 ? 4 : 3} />)}<span className="sr">Memuat…</span></div>);
}
