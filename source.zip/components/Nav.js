import Link from 'next/link';
import { LayoutGrid, ShoppingBag, User, History, ShieldCheck } from 'lucide-react';
export default function Nav({ on }) {
  const L = (h, k, I, l) => <Link href={h} className={on === k ? 'on' : ''} aria-label={l} title={l}><I size={24} /></Link>;
  return (<nav className="nav" aria-label="Navigasi utama">
    {L('/dashboard', 'dashboard', LayoutGrid, 'Dashboard')}{L('/orders', 'orders', History, 'Riwayat')}
    <Link href="/dashboard#paket" className="mid" aria-label="Beli panel" title="Beli panel"><ShoppingBag size={24} /></Link>
    {L('/garansi', 'garansi', ShieldCheck, 'Garansi')}{L('/profile', 'profile', User, 'Profil')}
  </nav>);
}
