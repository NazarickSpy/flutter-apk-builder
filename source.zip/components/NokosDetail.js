import { useCallback, useEffect, useRef, useState } from 'react';
import { CircleCheck, LoaderCircle, Ban, Copy, Check, TriangleAlert, Clock, Smartphone } from 'lucide-react';
import { api, rp, fmt, copyText, NOK, nokClass } from './api';
import Modal from './Modal';
import QR from './QR';
const ACTIVE = ['awaiting_payment', 'processing', 'waiting_otp'];
function CopyBtn({ value, label = 'Salin' }) {
  const [ok, setOk] = useState(false);
  return <button className="sqbtn sm" aria-label={label} onClick={async () => { if (await copyText(value)) { setOk(true); setTimeout(() => setOk(false), 1500); } }}>{ok ? <Check size={17} /> : <Copy size={17} />}</button>;
}
// Pembayaran QRIS -> nomor virtual -> kode OTP. Polling status 5 detik saat menunggu OTP (aturan Averpay), lebih jarang bila tab tidak terlihat.
export default function NokosDetail({ id, initial, onClose, onChange }) {
  const [o, setO] = useState(initial || null), [err, setErr] = useState(''), [left, setLeft] = useState(0), [otpLeft, setOtpLeft] = useState(null), [ask, setAsk] = useState(false), [busy, setBusy] = useState(false);
  const alive = useRef(true), timer = useRef(null), last = useRef(initial ? initial.status : null), cb = useRef(onChange); cb.current = onChange;
  const poll = useCallback(async () => {
    clearTimeout(timer.current); let next = 3500;
    try { const d = await api(`/nokos/orders/${id}`); if (!alive.current) return; setErr(''); setO(d); if (last.current !== d.status && cb.current) cb.current(); last.current = d.status; if (!ACTIVE.includes(d.status) && !d.waiting_otp2) return; if (d.status === 'waiting_otp' || d.waiting_otp2) next = 5000; }
    catch (e) { if (!alive.current) return; setErr(e.message); if (e.status === 401 || e.status === 404) return; next = 8000; }
    if (typeof document !== 'undefined' && document.hidden) next = Math.max(next, 15000);
    timer.current = setTimeout(poll, next);
  }, [id]);
  useEffect(() => { alive.current = true; if (initial && ACTIVE.includes(initial.status)) timer.current = setTimeout(poll, 2500); else if (!initial) poll(); return () => { alive.current = false; clearTimeout(timer.current); }; }, [poll]); // eslint-disable-line
  useEffect(() => {
    if (!o) return undefined;
    const target = o.status === 'awaiting_payment' ? o.expires_at : o.status === 'waiting_otp' ? o.otp_expires_at : null;
    if (!target) { setLeft(0); setOtpLeft(null); return undefined; }
    const tick = () => { const s = Math.max(0, Math.floor((new Date(target) - Date.now()) / 1000)); if (o.status === 'awaiting_payment') setLeft(s); else setOtpLeft(s); };
    tick(); const c = setInterval(tick, 1000); return () => clearInterval(c);
  }, [o && o.expires_at, o && o.otp_expires_at, o && o.status]); // eslint-disable-line
  const cancel = async () => { setBusy(true); try { await api(`/nokos/orders/${id}/cancel`, 'POST'); setErr(''); } catch (e) { setErr(e.message); } setAsk(false); await poll(); setBusy(false); };
  const resend = async () => { setBusy(true); try { await api(`/nokos/orders/${id}/resend`, 'POST'); setErr(''); } catch (e) { setErr(e.message); } await poll(); setBusy(false); };
  const st = o && o.status;
  return (<Modal onClose={onClose} label="Detail pesanan nokos" locked={busy}>
    <h3 className="center">{st === 'awaiting_payment' ? 'Pembayaran Pesanan' : st === 'waiting_otp' ? 'Nomor Anda' : 'Detail Pesanan'}</h3>
    {o && <p className="mut center meta">{o.platform_name} - {o.country_name}<br /><span className="mono">{o.ref}</span> - <span className={'stt ' + nokClass(st)}>{NOK[st]}</span></p>}
    {err && <div className="msg e">{err} <button className="linkbtn" onClick={() => { setErr(''); poll(); }}>Coba lagi</button></div>}
    {!o && !err && <div className="center loading"><LoaderCircle size={18} className="spin" /> Memuat…</div>}
    {st === 'awaiting_payment' && <>
      {o.qr_image ? <QR src={o.qr_image} name={o.ref} /> : <div className="center loading"><LoaderCircle size={18} className="spin" /> Menyiapkan QRIS…</div>}
      <div className="big">{rp(o.total || o.price)}</div>
      <p className="mut center small">Bayar <b>sesuai nominal persis</b> (sudah termasuk biaya layanan).<br />{left > 0 ? <><Clock size={13} className="vm" /> Berlaku <b className="mono">{fmt(left)}</b> - pembayaran terdeteksi otomatis</> : 'Waktu habis, memeriksa pembayaran terakhir…'}</p>
      <small className="mut center" style={{ display: 'block' }}>Nomor diberikan setelah pembayaran terverifikasi, lalu OTP tampil otomatis di sini.</small>
      {!ask ? <button className="btn full ghost dangertxt" onClick={() => setAsk(true)}><Ban size={16} />Batalkan pesanan</button>
        : <div className="askrow"><span>Batalkan pesanan ini?</span><div className="two"><button className="btn ghost" disabled={busy} onClick={() => setAsk(false)}>Tidak</button><button className="btn red" disabled={busy} onClick={cancel}>{busy ? 'Membatalkan…' : 'Ya, Batalkan'}</button></div></div>}</>}
    {st === 'processing' && <div className="msg warnm center"><LoaderCircle size={18} className="spin vm" /> Pembayaran diterima. Nomor sedang dipesan, tampil otomatis di sini.</div>}
    {st === 'waiting_otp' && <>
      <div className="ib2"><div style={{ minWidth: 0 }}><small className="cap">NOMOR VIRTUAL</small><div className="mono val" style={{ fontSize: 17 }}>{o.phone || 'Menyiapkan nomor…'}</div></div>{o.phone && <CopyBtn value={o.phone} label="Salin nomor" />}</div>
      <div className="msg warnm center" style={{ marginTop: 10 }}><LoaderCircle size={18} className="spin vm" /> Menunggu kode OTP…<br /><small>Masukkan nomor di aplikasi tujuan lalu minta kode. {otpLeft != null ? (otpLeft > 0 ? <>Sisa waktu <b className="mono">{fmt(otpLeft)}</b>.</> : 'Waktu hampir habis, memeriksa terakhir kali…') : ''}</small></div>
      <small className="mut" style={{ display: 'block', marginTop: 8 }}>Jangan tutup halaman ini bila ingin langsung melihat kode. Jika Anda menutupnya, kode tetap tersimpan di Riwayat Nokos.</small></>}
    {st === 'done' && <><div className="msg s center"><CircleCheck size={18} className="vm" /> Kode OTP diterima dan tersimpan di akun Anda.</div>
      {o.result_error ? <div className="msg e">Kode OTP tidak dapat dibaca saat ini. Hubungi bantuan dengan kode pesanan di atas.</div> : <>
        {o.phone && <div className="ib2"><div style={{ minWidth: 0 }}><small className="cap">NOMOR</small><div className="mono val">{o.phone}</div></div><CopyBtn value={o.phone} label="Salin nomor" /></div>}
        {o.otp ? <div className="ib2"><div style={{ minWidth: 0 }}><small className="cap">KODE OTP</small><div className="mono val" style={{ fontSize: 24, letterSpacing: 2 }}>{o.otp}</div></div><CopyBtn value={o.otp} label="Salin kode" /></div> : <div className="msg warnm">{o.note || 'Pesanan ditandai selesai.'} Kode OTP tidak tersedia; hubungi bantuan dengan kode pesanan di atas.</div>}
        {o.otp_text && <small className="mut" style={{ display: 'block', marginTop: 8 }}>Pesan: {o.otp_text}</small>}
        {o.otp2 && <div className="ib2" style={{ marginTop: 10 }}><div style={{ minWidth: 0 }}><small className="cap">KODE OTP KEDUA</small><div className="mono val" style={{ fontSize: 24, letterSpacing: 2 }}>{o.otp2}</div></div><CopyBtn value={o.otp2} label="Salin kode kedua" /></div>}
        {o.waiting_otp2 && <div className="msg warnm center" style={{ marginTop: 10 }}><LoaderCircle size={18} className="spin vm" /> Menunggu kode OTP kedua. Minta kode lagi di aplikasi tujuan bila perlu.</div>}
        {o.can_resend && <><button className="btn full ghost" style={{ marginTop: 10 }} disabled={busy} onClick={resend}>{busy ? 'Meminta…' : 'Minta OTP kedua'}</button><small className="mut center" style={{ display: 'block' }}>Gratis dan hanya bisa sekali, setelah OTP pertama masuk.</small></>}</>}</>}
    {st === 'refund_needed' && <div className="msg warnm center"><TriangleAlert size={18} className="vm" /> Pembayaran Anda sudah kami terima, tetapi nomor tidak menghasilkan OTP.{o.note ? <><br /><small>{o.note}</small></> : null}<br />Admin akan mengembalikan dana <b>{rp(o.total || o.price)}</b> secara penuh. Hubungi bantuan dengan kode <b>{o.ref}</b> untuk mempercepat.</div>}
    {st === 'review' && <div className="msg warnm center"><TriangleAlert size={18} className="vm" /> Pesanan sedang diperiksa admin untuk memastikan hasilnya. Pembayaran Anda aman: bila gagal, dana dikembalikan penuh. Hubungi bantuan dengan kode <b>{o.ref}</b> bila perlu.</div>}
    {st === 'refunded' && <div className="msg e center"><Ban size={18} className="vm" /> Pesanan tidak dapat diselesaikan dan dana sudah dikembalikan.{o.note ? <><br /><small>{o.note}</small></> : null}</div>}
    {st === 'expired' && <div className="msg e center">QRIS kedaluwarsa. Buat pesanan baru bila masih ingin membeli.</div>}
    {st === 'cancelled' && <div className="msg e center"><Ban size={18} className="vm" /> Pesanan dibatalkan. Jangan bayar QRIS ini lagi.</div>}
    <button className="btn full ghost" disabled={busy} onClick={onClose}>Tutup</button></Modal>);
}
