import { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronDown } from 'lucide-react';
// Port CustomSelect OpenWA: dropdown kustom (keyboard: panah, Home/End, Enter/Spasi, Esc, ketik-untuk-cari). options = [{ value, label }]
export default function CustomSelect({ value, onChange, options, ariaLabel, id }) {
  const [open, setOpen] = useState(false), [fi, setFi] = useState(-1);
  const box = useRef(null), list = useRef(null), trig = useRef(null), buf = useRef(''), timer = useRef();
  const sel = options.find((o) => String(o.value) === String(value)), label = sel ? sel.label : '';
  const close = useCallback(() => { setOpen(false); setFi(-1); trig.current && trig.current.focus(); }, []);
  const toggle = useCallback(() => setOpen((p) => { if (!p) { const i = options.findIndex((o) => String(o.value) === String(value)); setFi(i >= 0 ? i : 0); } return !p; }), [options, value]);
  const pick = useCallback((v) => { onChange(v); close(); }, [onChange, close]);
  const key = (e) => {
    if (!open) { if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') { e.preventDefault(); toggle(); } return; }
    const n = options.length;
    if (e.key === 'Escape') { e.preventDefault(); close(); } else if (e.key === 'ArrowDown') { e.preventDefault(); setFi((p) => (p < n - 1 ? p + 1 : 0)); } else if (e.key === 'ArrowUp') { e.preventDefault(); setFi((p) => (p > 0 ? p - 1 : n - 1)); }
    else if (e.key === 'Home') { e.preventDefault(); setFi(0); } else if (e.key === 'End') { e.preventDefault(); setFi(n - 1); }
    else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (fi >= 0 && fi < n) pick(options[fi].value); } else if (e.key === 'Tab') close();
    else if (e.key.length === 1) { buf.current += e.key.toLowerCase(); clearTimeout(timer.current); timer.current = setTimeout(() => { buf.current = ''; }, 500); const m = options.findIndex((o) => String(o.label).toLowerCase().startsWith(buf.current)); if (m >= 0) setFi(m); }
  };
  useEffect(() => { if (!open) return undefined; const h = (e) => { if (box.current && !box.current.contains(e.target)) close(); }; document.addEventListener('mousedown', h); return () => document.removeEventListener('mousedown', h); }, [open, close]);
  useEffect(() => { if (open && fi >= 0 && list.current) { const it = list.current.querySelectorAll('.custom-select-option')[fi]; it && it.focus(); } }, [open, fi]);
  useEffect(() => () => clearTimeout(timer.current), []);
  return (<div className="custom-select" ref={box} onKeyDown={key}>
    <button ref={trig} id={id} type="button" className="custom-select-trigger" onClick={toggle} aria-haspopup="listbox" aria-expanded={open} aria-label={ariaLabel}><span className="custom-select-label">{label}</span><ChevronDown size={16} className={'custom-select-chevron' + (open ? ' open' : '')} /></button>
    {open && <div className="custom-select-dropdown" ref={list} role="listbox" aria-label={ariaLabel}>{options.map((o, i) => <button key={o.value} type="button" role="option" tabIndex={-1} aria-selected={String(o.value) === String(value)} className={'custom-select-option' + (String(o.value) === String(value) ? ' selected' : '') + (i === fi ? ' focused' : '')} onClick={() => pick(o.value)} onMouseEnter={() => setFi(i)}>{o.label}</button>)}</div>}
  </div>);
}
