import { useEffect } from 'react';
import { useRouter } from 'next/router';
// Penghalang ringan di halaman PUBLIK (beranda, status, panduan, ketentuan, bantuan): klik kanan, tahan-untuk-salin, seleksi teks, seret gambar,
// dan pintasan F12 / Ctrl+U / Ctrl+Shift+I,J,C / Ctrl+S dinonaktifkan. TIDAK dipasang di halaman akun (dashboard, pesanan, profil, login) karena pembeli
// harus bisa menyalin password panel, TRX ID, dan kode OTP. Ini hanya penghalang awam: keamanan sebenarnya ada di server (semua validasi dilakukan di backend).
const PUBLIC = new Set(['/', '/status', '/cara-order', '/terms', '/bantuan']);
const okTarget = (t) => !!(t && t.closest && t.closest('input,textarea,select,[contenteditable="true"],[data-copy]'));
export default function Deterrent() {
  const { pathname } = useRouter();
  useEffect(() => {
    if (!PUBLIC.has(pathname)) return undefined;
    document.body.classList.add('nocopy');
    const stop = (e) => { if (!okTarget(e.target)) e.preventDefault(); };
    const key = (e) => {
      const k = String(e.key || '').toLowerCase(), c = e.ctrlKey || e.metaKey;
      if (k === 'f12' || (c && ['u', 's'].includes(k)) || (c && e.shiftKey && ['i', 'j', 'c'].includes(k)) || (e.metaKey && e.altKey && ['i', 'j', 'u'].includes(k))) { if (!okTarget(e.target)) e.preventDefault(); }
    };
    const evs = ['contextmenu', 'copy', 'cut', 'dragstart', 'selectstart'];
    evs.forEach((n) => document.addEventListener(n, stop)); document.addEventListener('keydown', key);
    return () => { document.body.classList.remove('nocopy'); evs.forEach((n) => document.removeEventListener(n, stop)); document.removeEventListener('keydown', key); };
  }, [pathname]);
  return null;
}
