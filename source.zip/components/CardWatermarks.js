import { useEffect } from 'react';
// Memberi watermark ikon pada SEMUA kartu di semua halaman: memakai ikon pertama di kartu (biasanya ikon judul), atau kepingan salju bila tak ada.
// Berbasis DOM + MutationObserver supaya kartu yang muncul belakangan (data dimuat, ganti tab) otomatis ikut. Kartu yang sudah punya
// .wmw (dibuat lewat <Wm/>) dilewati. Atribut data-wm tidak disentuh React, jadi aman terhadap render ulang.
const FLAKE = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M4.2 7l15.6 10M4.2 17L19.8 7"/><path d="m9.5 4 2.5 2 2.5-2M9.5 20l2.5-2 2.5 2M3 9.8l3.2.4-.6-3.2M21 14.2l-3.2-.4.6 3.2M3 14.2l3.2-.4-.6 3.2M21 9.8l-3.2.4.6-3.2"/></svg>';
const SKIP = 'button,a,input,select,textarea,label,.chip,.btn,.stt,.badge,.pchip,.spin,.tabs,.wmw,.loading,.sk';
function decorate(card, n) {
  card.setAttribute('data-wm', '1');
  if (card.querySelector(':scope > .wmw')) return;
  let src = card.querySelector('.ch svg, .ico svg');
  if (!src) src = Array.from(card.querySelectorAll('svg')).find((s) => !s.closest(SKIP) && !s.classList.contains('wm'));
  const wrap = document.createElement('span'); wrap.className = 'wmw'; wrap.setAttribute('aria-hidden', 'true'); wrap.style.setProperty('--ic', `var(--c${1 + (n % 8)})`);
  if (src) { const c = src.cloneNode(true); c.removeAttribute('class'); c.removeAttribute('width'); c.removeAttribute('height'); c.removeAttribute('style'); c.setAttribute('stroke-width', '1.6'); wrap.appendChild(c); } else wrap.innerHTML = FLAKE;
  card.insertBefore(wrap, card.firstChild);
}
export default function CardWatermarks() {
  useEffect(() => {
    let raf = 0, n = document.querySelectorAll('[data-wm]').length;
    const run = () => { raf = 0; document.querySelectorAll('.card:not([data-wm])').forEach((c) => { if (!c.closest('.sheet,.modal')) decorate(c, n++); }); };
    const sched = () => { if (!raf) raf = requestAnimationFrame(run); };
    run(); const mo = new MutationObserver(sched); mo.observe(document.body, { childList: true, subtree: true });
    return () => { mo.disconnect(); if (raf) cancelAnimationFrame(raf); };
  }, []);
  return null;
}
