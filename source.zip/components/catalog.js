// Katalog paket untuk render di SERVER (SSG/ISR). Hanya dipanggil dari getStaticProps (kode ini tidak ikut ke bundel browser).
// Mengambil dari API publik aplikasi sendiri lewat loopback (memakai cache & perlindungan yang sama); gagal/kosong -> [] (halaman tetap tampil, lalu diisi ulang saat revalidate).
export async function fetchPackages() {
  try {
    const r = await fetch(`http://127.0.0.1:${process.env.PORT || 3000}/api/packages`, { headers: { 'User-Agent': 'SnowyStore-SSR/1.0', Accept: 'application/json' }, signal: AbortSignal.timeout(4000) });
    if (!r.ok) return [];
    const j = await r.json();
    return (Array.isArray(j) ? j : []).filter((p) => p && p.key && p.name && Number(p.price) > 0 && Number(p.memory) > 0 && Number(p.disk) > 0).map((p) => ({ key: String(p.key), name: String(p.name), memory: Number(p.memory), disk: Number(p.disk), cpu: Number(p.cpu) || 0, price: Number(p.price) }));
  } catch { return []; }
}
