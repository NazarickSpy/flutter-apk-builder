import React from 'react';
// Error tampilan tidak lagi jadi layar putih: tampilkan pesan + tombol muat ulang. Error chunk (setelah update/deploy) -> muat ulang otomatis sekali.
export default class ErrorBoundary extends React.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(err) { return { err }; }
  componentDidCatch(err, info) {
    console.error('[ui]', err, info && info.componentStack);
    try { document.body.style.overflow = ''; } catch {}
    const m = String((err && err.message) || err);
    if (/ChunkLoad|Loading chunk|Loading CSS chunk|dynamically imported|Failed to fetch dynamically/i.test(m)) {
      try { if (!sessionStorage.getItem('snowy:reloaded')) { sessionStorage.setItem('snowy:reloaded', '1'); location.reload(); } } catch {}
    }
  }
  render() {
    if (!this.state.err) return this.props.children;
    const m = String((this.state.err && this.state.err.message) || this.state.err).slice(0, 300);
    return (<div className="wrap"><div className="card center"><h3>Halaman gagal ditampilkan</h3>
      <p className="mut">Terjadi kesalahan pada tampilan. Coba muat ulang. Bila berulang, kirim pesan di bawah ini ke admin.</p>
      <pre className="errtx">{m}</pre>
      <button className="btn full" onClick={() => { try { sessionStorage.removeItem('snowy:reloaded'); } catch {} location.reload(); }}>Muat ulang</button>
      <a className="btn full ghost" href="/dashboard">Ke Dashboard</a></div></div>);
  }
}
