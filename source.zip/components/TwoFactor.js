import { useEffect, useState } from 'react';
import { ShieldCheck, Smartphone, Copy, Check, Download } from 'lucide-react';
import { api } from './api';
import { toast } from './Toast';
// Kartu Verifikasi 2 Langkah (TOTP): aktifkan lewat QR, simpan kode pemulihan, matikan dengan password + kode.
export default function TwoFactor() {
  const [st, setSt] = useState(null), [setup, setSetup] = useState(null), [code, setCode] = useState(''), [pw, setPw] = useState(''), [rec, setRec] = useState(null), [off, setOff] = useState(false), [busy, setBusy] = useState(false), [err, setErr] = useState('');
  const load = () => api('/2fa').then(setSt).catch(() => setSt({ enabled: false, recovery_left: 0 }));
  useEffect(() => { load(); }, []);
  const run = (fn) => async () => { setBusy(true); setErr(''); try { await fn(); } catch (e) { setErr(e.message); } setBusy(false); };
  const copyRec = () => { navigator.clipboard?.writeText(rec.join('\n')).then(() => toast('Kode pemulihan disalin')).catch(() => {}); };
  const dl = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([`Kode pemulihan SnowyStore\n\n${rec.join('\n')}\n\nSetiap kode hanya bisa dipakai sekali.`], { type: 'text/plain' })); a.download = 'snowystore-kode-pemulihan.txt'; a.click(); URL.revokeObjectURL(a.href); };
  return (<div className="card"><div className="ch"><span className="ico"><Smartphone size={22} /></span><b style={{ flex: 1 }}>Verifikasi 2 Langkah</b>{st && <span className={st.enabled ? 'okb' : 'pchip'}>{st.enabled ? 'Aktif' : 'Nonaktif'}</span>}</div>
    {!st ? <div className="sk l2" /> : rec ? <>
      <p className="mut" style={{ marginTop: 0 }}>2FA aktif. Simpan kode pemulihan ini di tempat aman. Tiap kode hanya berlaku sekali dan tidak akan ditampilkan lagi.</p>
      <div className="rec">{rec.map((c) => <code key={c}>{c}</code>)}</div>
      <div className="two"><button className="btn ghost" onClick={copyRec}><Copy size={18} />Salin</button><button className="btn ghost" onClick={dl}><Download size={18} />Unduh</button></div>
      <button className="btn full" style={{ marginTop: 10 }} onClick={() => { setRec(null); load(); }}><Check size={18} />Sudah saya simpan</button>
    </> : st.enabled ? <>
      <p className="mut" style={{ marginTop: 0 }}>Login memerlukan kode dari aplikasi autentikator. Sisa kode pemulihan: <b>{st.recovery_left}</b>.</p>
      {!off ? <button className="btn ghost full dangertxt" onClick={() => setOff(true)}>Matikan 2FA</button> : <>
        <label>Password</label><input type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} />
        <label>Kode autentikator / pemulihan</label><input value={code} onChange={(e) => setCode(e.target.value)} autoComplete="one-time-code" />
        {err && <div className="msg e">{err}</div>}
        <div className="two" style={{ marginTop: 14 }}><button className="btn ghost" onClick={() => { setOff(false); setErr(''); }}>Batal</button><button className="btn ghost dangertxt" disabled={busy || !pw || !code} onClick={run(async () => { await api('/2fa/disable', 'POST', { password: pw, code }); setOff(false); setPw(''); setCode(''); toast('2FA dimatikan'); load(); })}>Matikan</button></div></>}
    </> : setup ? <>
      <p className="mut" style={{ marginTop: 0 }}>1. Pindai QR dengan Google Authenticator, Authy, atau sejenisnya. 2. Masukkan 6 digit kode yang muncul.</p>
      <div className="qr2"><img src={setup.qr} alt="QR 2FA" width="180" height="180" /><div><small className="cap">ATAU KUNCI MANUAL</small><div className="mono val" style={{ wordBreak: 'break-all' }}>{setup.secret}</div></div></div>
      <label>Kode 6 digit</label><input inputMode="numeric" maxLength={7} value={code} onChange={(e) => setCode(e.target.value)} autoComplete="one-time-code" />
      {err && <div className="msg e">{err}</div>}
      <div className="two" style={{ marginTop: 14 }}><button className="btn ghost" onClick={() => { setSetup(null); setCode(''); setErr(''); }}>Batal</button><button className="btn" disabled={busy || code.replace(/\s/g, '').length < 6} onClick={run(async () => { const x = await api('/2fa/enable', 'POST', { code }); setRec(x.recovery); setSetup(null); setCode(''); })}><ShieldCheck size={18} />Aktifkan</button></div>
    </> : <>
      <p className="mut" style={{ marginTop: 0 }}>Tambahkan lapisan keamanan: selain password, login butuh kode 6 digit dari ponsel Anda. Akun tetap aman walau password bocor.</p>
      {err && <div className="msg e">{err}</div>}
      <button className="btn full" disabled={busy} onClick={run(async () => setSetup(await api('/2fa/setup', 'POST', {})))}><ShieldCheck size={18} />Aktifkan 2FA</button></>}
  </div>);
}
