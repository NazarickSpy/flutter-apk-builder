// Watermark ikon besar di pojok kartu (deklaratif). Induknya wajib punya class "wmk" (position:relative; isolation:isolate).
// n = 1..8 memilih warna ikon (--c1..--c8); tanpa n = warna aksen.
export default function Wm({ i: I, n }) {
  return <span className="wmw" aria-hidden="true" style={n ? { '--ic': `var(--c${n})` } : undefined}><I size={110} strokeWidth={1.6} /></span>;
}
