import Head from 'next/head';
// Data terstruktur JSON-LD. Blok bertipe application/ld+json adalah data (bukan skrip), jadi tidak diblokir CSP script-src 'self'.
export default function JsonLd({ id, data }) {
  return <Head><script key={id} id={id} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, '\\u003c') }} /></Head>;
}
