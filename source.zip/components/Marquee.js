import { useMemo } from 'react';
// Teks berjalan mulus & tanpa putus (loop seamless): satu "paruh" diulang sampai cukup lebar, lalu digandakan dan digeser -50%.
// Kecepatan konstan (~55px/dtk) berapa pun panjang teksnya; jeda saat disorot/ditekan. prefers-reduced-motion = teks statis (lihat CSS).
export default function Marquee({ text }) {
  const { reps, dur } = useMemo(() => { const w = Math.max(1, text.length) * 8.6 + 48, reps = Math.max(1, Math.ceil(1600 / w)); return { reps, dur: Math.max(14, Math.round((w * reps) / 55)) }; }, [text]);
  const half = Array.from({ length: reps }, (_, i) => <span className="mq-item" key={i}>{text}<i className="mq-dot" aria-hidden="true">✦</i></span>);
  return (<div className="mq" role="marquee" aria-label={text}><div className="mq-track" style={{ '--mqd': dur + 's' }}><span className="mq-half">{half}</span><span className="mq-half" aria-hidden="true">{half}</span></div></div>);
}
