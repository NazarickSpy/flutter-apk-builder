import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/router';
import { Search, ArrowUp, CornerDownLeft } from 'lucide-react';
// Alat bantu global: pencarian cepat (Ctrl/⌘+K) dan tombol kembali ke atas. Ringan: hanya event pasif, tanpa polling.
const ITEMS = [['Beranda', '/'], ['Dashboard', '/dashboard'], ['Riwayat Pesanan', '/orders'], ['Notifikasi', '/notifikasi'], ['Beli Panel (Paket Hosting)', '/dashboard#paket'], ['Aplikasi Premium', '/premium'], ['Nomor Virtual (OTP)', '/nokos'], ['Klaim Garansi', '/garansi'], ['Status Sistem', '/status'], ['Cara Order', '/cara-order'], ['Bantuan & FAQ', '/bantuan'], ['Syarat & Ketentuan', '/terms'], ['Profil & Keamanan', '/profile?tab=sec'], ['Aktivitas Login', '/profile?tab=act'], ['Login', '/login'], ['Daftar Akun', '/register']];
export default function QuickTools() {
  const r = useRouter(), [open, setOpen] = useState(false), [q, setQ] = useState(''), [i, setI] = useState(0), [top, setTop] = useState(false), inp = useRef(null);
  useEffect(() => {
    const k = (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setOpen((o) => !o); setQ(''); setI(0); } else if (e.key === 'Escape') setOpen(false); };
    const sc = () => setTop(window.scrollY > 600);
    window.addEventListener('keydown', k); window.addEventListener('scroll', sc, { passive: true }); sc();
    return () => { window.removeEventListener('keydown', k); window.removeEventListener('scroll', sc); };
  }, []);
  useEffect(() => { if (open) setTimeout(() => inp.current && inp.current.focus(), 30); }, [open]);
  const list = ITEMS.filter(([l]) => l.toLowerCase().includes(q.toLowerCase().trim())).slice(0, 8);
  const go = (h) => { setOpen(false); r.push(h); };
  const key = (e) => { if (e.key === 'ArrowDown') { e.preventDefault(); setI((x) => Math.min(x + 1, list.length - 1)); } else if (e.key === 'ArrowUp') { e.preventDefault(); setI((x) => Math.max(x - 1, 0)); } else if (e.key === 'Enter' && list[i]) go(list[i][1]); };
  return (<>
    {top && !open && <button type="button" className="totop" aria-label="Kembali ke atas" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}><ArrowUp size={20} /></button>}
    {open && <div className="qk-bg" onMouseDown={() => setOpen(false)}><div className="qk" role="dialog" aria-modal="true" aria-label="Pencarian cepat" onMouseDown={(e) => e.stopPropagation()}>
      <div className="qk-in"><Search size={18} /><input ref={inp} value={q} onChange={(e) => { setQ(e.target.value); setI(0); }} onKeyDown={key} placeholder="Cari halaman…" aria-label="Cari halaman" /><kbd>Esc</kbd></div>
      <div className="qk-l" role="listbox">{list.length === 0 && <p className="mut" style={{ padding: 16, margin: 0 }}>Tidak ada hasil.</p>}{list.map(([l, h], n) => <button type="button" role="option" aria-selected={n === i} key={h} className={n === i ? 'on' : ''} onMouseEnter={() => setI(n)} onClick={() => go(h)}>{l}{n === i && <CornerDownLeft size={15} />}</button>)}</div>
    </div></div>}
  </>);
}
