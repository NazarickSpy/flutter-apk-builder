import Link from 'next/link';
export default function Brand({ sub, light, href = '/' }) {
  return <Link href={href} className={'brand' + (light ? ' light' : '')}><img src="/img/logo-icon.webp?v=4" alt="" width="38" height="38" className="lgimg" /><span>SnowyStore{sub ? <small className="brandsub">{sub}</small> : null}</span></Link>;
}
