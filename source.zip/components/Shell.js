import Link from 'next/link';
import { useState } from 'react';
import { Eye, EyeOff, Zap, ShieldCheck, ReceiptText } from 'lucide-react';
import Brand from './Brand';
export { default as Brand } from './Brand';
export function Field({ icon: Icon, label, type = 'text', ...p }) {
  const [s, setS] = useState(false); const pw = type === 'password', id = p.id || 'f-' + String(label).toLowerCase().replace(/[^a-z0-9]+/g, '-');
  return (<><label htmlFor={id}>{label}</label><div className="fld"><Icon size={20} className="fi" /><input id={id} {...p} type={pw && s ? 'text' : type} />
    {pw && <button type="button" className="eye" onClick={() => setS(!s)} aria-label={s ? 'Sembunyikan sandi' : 'Lihat sandi'}>{s ? <EyeOff size={20} /> : <Eye size={20} />}</button>}</div></>);
}
// Halaman login/daftar: HP = logo di tengah + kartu bertab (Masuk | Daftar); desktop (>=900px) = panel brand biru di kiri + form di kanan
export default function Shell({ tab = 'login', children }) {
  return (<div className="authpage">
    <aside className="authside"><Brand light /><img src="/img/logo-full.webp?v=4" alt="" width="220" height="220" className="sidelogo" />
      <div className="asd"><h2>Aplikasi Premium, Nomor OTP &amp; Hosting dalam Satu Akun</h2>
        <ul><li><Zap size={20} />Pembayaran QRIS, pesanan diproses otomatis setelah terverifikasi</li><li><ShieldCheck size={20} />Notifikasi login perangkat baru &amp; riwayat aktivitas akun</li><li><ReceiptText size={20} />Riwayat pesanan dan data akun tersimpan di dashboard</li></ul></div>
      <small>Butuh bantuan? Buka <Link href="/bantuan">Pusat Bantuan</Link></small></aside>
    <main className="authmain" id="konten">
      <div className="hd"><Brand /><span className="grow" /><Link href="/" className="lnk mut nv">← Beranda</Link></div>
      <div className="authlogo"><span className="lgbox"><img src="/img/logo-icon.webp?v=4" alt="" width="52" height="52" /></span><b style={{ fontSize: '1.0625rem' }}>SnowyStore</b><small className="mut">Portal member · server panel, premium &amp; OTP</small></div>
      <div className="authcard">
        <div className="segmented" role="tablist" aria-label="Masuk atau daftar"><Link href="/login" role="tab" aria-selected={tab === 'login'} className={tab === 'login' ? 'on' : ''}>Masuk</Link><Link href="/register" role="tab" aria-selected={tab === 'register'} className={tab === 'register' ? 'on' : ''}>Daftar</Link></div>
        {children}</div>
      <p className="center foot"><Link href="/terms" className="lnk">Syarat &amp; Ketentuan</Link></p>
      <p className="mut center fine2">© 2026 SnowyStore Platform. Seluruh hak cipta dilindungi.</p>
      <p className="mut center fine2"><Link href="/status">Status</Link> - <Link href="/cara-order">Panduan</Link> - <Link href="/bantuan">Bantuan</Link></p></main></div>);
}
