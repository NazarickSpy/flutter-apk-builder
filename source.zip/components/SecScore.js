import { useEffect, useState } from 'react';
import { ShieldCheck, CircleCheck, Circle } from 'lucide-react';
import { api } from './api';
// Skor keamanan akun: ringkasan langkah perlindungan yang sudah/belum aktif
export default function SecScore({ me }) {
  const [on, setOn] = useState(null);
  useEffect(() => { api('/2fa').then((x) => setOn(!!x.enabled)).catch(() => setOn(false)); }, []);
  const items = [['Email terdaftar & permanen', true], ['Nomor WhatsApp terisi', !!(me.whatsapp && me.whatsapp.length > 8)], ['Verifikasi 2 langkah (2FA) aktif', on === true]];
  const n = items.filter((x) => x[1]).length, pct = Math.round((n / items.length) * 100);
  return (<div className="card"><div className="ch"><span className="ico"><ShieldCheck size={22} /></span><b style={{ flex: 1 }}>Skor Keamanan</b><span className={n === items.length ? 'okb' : 'pchip'}>{pct}%</span></div>
    <div className="score" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}><i style={{ width: pct + '%' }} /></div>
    {items.map(([t, ok]) => <div key={t} className={'chk ' + (ok ? 'ok' : 'no')}>{ok ? <CircleCheck size={18} /> : <Circle size={18} />}<span>{t}</span></div>)}</div>);
}
