// Pesan standar bila server tidak memberi penjelasan: selalu jelas apa yang terjadi dan apa yang harus dilakukan pengguna
const FRIENDLY = { 400: 'Data yang dimasukkan belum sesuai. Periksa kembali isian Anda.', 401: 'Sesi Anda berakhir. Silakan masuk lagi.', 403: 'Anda tidak memiliki akses untuk tindakan ini.', 404: 'Data tidak ditemukan.', 409: 'Permintaan ini bentrok dengan data yang sudah ada. Muat ulang halaman lalu coba lagi.', 429: 'Terlalu banyak percobaan. Tunggu beberapa saat lalu coba lagi.', 500: 'Terjadi gangguan di server kami. Coba lagi sebentar lagi.', 502: 'Layanan pembayaran sedang bermasalah. Coba lagi sebentar lagi.', 503: 'Layanan sedang sibuk. Coba lagi sebentar lagi.' };
// Idempotency-Key untuk pembuatan pesanan: isi yang sama dalam 2 menit (klik ganda / retry) memakai key yang sama, jadi server tidak membuat invoice ganda
const IDEM = /^\/(orders|premium\/orders|nokos\/orders)$/, idemKeys = new Map();
const idemDone = (path, body) => idemKeys.delete(path + JSON.stringify(body || {})); // respons sudah diterima: pesanan berikutnya memakai key baru
const idemKey = (path, body) => { const h = path + JSON.stringify(body || {}), e = idemKeys.get(h), now = Date.now(); if (e && now - e.t < 120000) return e.k; const k = (crypto.randomUUID ? crypto.randomUUID() : String(now) + Math.random().toString(36).slice(2)).replace(/[^A-Za-z0-9_-]/g, '').padEnd(16, '0'); idemKeys.set(h, { k, t: now }); if (idemKeys.size > 50) idemKeys.delete(idemKeys.keys().next().value); return k; };
export class ApiError extends Error { constructor(m, status) { super(m); this.status = status; } }
// fetch dengan timeout (tidak ada lagi "Memuat…" selamanya) + pesan error yang jelas. status 0 = gagal koneksi/timeout.
export async function api(path, method = 'GET', body, opt = {}) {
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), opt.timeout || 20000);
  try {
    const r = await fetch('/api' + path, { method, credentials: 'same-origin', signal: ctl.signal, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'snowy', ...(method === 'POST' && IDEM.test(path) ? { 'Idempotency-Key': idemKey(path, body) } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (method === 'POST' && IDEM.test(path)) idemDone(path, body);
    if (!r.ok) throw new ApiError((j.error || FRIENDLY[r.status] || 'Terjadi kesalahan. Coba lagi.') + (j.ref && r.status >= 500 ? ` (Ref: ${j.ref})` : ''), r.status);
    return j;
  } catch (e) {
    if (e instanceof ApiError) throw e;
    throw new ApiError(e.name === 'AbortError' ? 'Server lambat merespons. Coba lagi.' : 'Koneksi bermasalah. Periksa internet lalu coba lagi.', 0);
  } finally { clearTimeout(t); }
}
export const rp = (n) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');
export const fdate = (d) => (d ? new Date(d).toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');
export const fday = (d) => (d ? new Date(d).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' }) : '—');
export const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
export const STATE = { unpaid: 'Menunggu Bayar', processing: 'Diproses', active: 'Aktif', failed: 'Perlu Bantuan', expired: 'Kedaluwarsa', cancelled: 'Dibatalkan' };
// Penjelasan singkat tiap status: pengguna selalu tahu apa artinya dan apa langkah berikutnya
export const HINT = { unpaid: 'Scan QRIS lalu bayar sesuai nominal sebelum waktu habis. Status berubah otomatis setelah pembayaran terverifikasi.', processing: 'Pembayaran diterima, server sedang dibuat. Biasanya selesai dalam 1-2 menit dan halaman ini diperbarui otomatis.', failed: 'Pembayaran sudah diterima tetapi server belum jadi. Tekan Detail, atau hubungi bantuan dan sebutkan TRX ID Anda.', expired: 'Waktu pembayaran habis. Jangan bayar QRIS ini lagi; buat pesanan baru bila masih ingin membeli.' };
export const PRMHINT = { awaiting_payment: 'Scan QRIS dan bayar sebelum waktu habis.', processing: 'Pembayaran diterima, pesanan sedang diproses.', pending_provider: 'Pesanan sedang disiapkan penyedia. Biasanya hanya butuh beberapa menit.', review: 'Pesanan sedang diperiksa admin. Pembayaran Anda aman.', refund_needed: 'Pesanan gagal diproses. Dana Anda dikembalikan penuh oleh admin.', refunded: 'Dana sudah dikembalikan.', expired: 'Waktu pembayaran habis. Buat pesanan baru bila masih ingin membeli.' };
export const CLAIM = { pending: 'Menunggu review', processing: 'Sedang diproses', done: 'Selesai', rejected: 'Ditolak', failed: 'Gagal diproses' };
export async function copyText(v) { try { await navigator.clipboard.writeText(v); return true; } catch { return false; } }
export const PRM = { awaiting_payment: 'Menunggu pembayaran', processing: 'Diproses', pending_provider: 'Menunggu penyedia', done: 'Selesai', refund_needed: 'Menunggu pengembalian dana', refunded: 'Dana dikembalikan', review: 'Diperiksa admin', expired: 'Kedaluwarsa', cancelled: 'Dibatalkan' };
export const NOK = { awaiting_payment: 'Menunggu pembayaran', processing: 'Diproses', waiting_otp: 'Menunggu OTP', done: 'OTP diterima', refund_needed: 'Menunggu pengembalian dana', refunded: 'Dana dikembalikan', review: 'Diperiksa admin', expired: 'Kedaluwarsa', cancelled: 'Dibatalkan' };
export const NOKHINT = { awaiting_payment: 'Scan QRIS dan bayar sebelum waktu habis. Nomor baru diberikan setelah pembayaran terverifikasi.', processing: 'Pembayaran diterima, nomor sedang dipesan.', waiting_otp: 'Pakai nomor ini di aplikasi tujuan, lalu kode OTP muncul di sini otomatis.', done: 'Kode OTP sudah diterima dan tersimpan di akun Anda.', review: 'Pesanan sedang diperiksa admin. Pembayaran Anda aman.', refund_needed: 'Nomor tidak menghasilkan OTP. Dana Anda dikembalikan penuh oleh admin.', refunded: 'Dana sudah dikembalikan.', expired: 'Waktu pembayaran habis. Buat pesanan baru bila masih ingin membeli.' };
export const nokClass = (s) => (s === 'done' ? 'active' : ['refunded', 'expired', 'cancelled'].includes(s) ? 'expired' : ['review', 'refund_needed'].includes(s) ? 'failed' : 'unpaid');
export const prmClass = (s) => (s === 'done' ? 'active' : ['refunded', 'expired', 'cancelled'].includes(s) ? 'expired' : ['review', 'refund_needed'].includes(s) ? 'failed' : 'unpaid');

// Waktu relatif ("baru saja", "5 menit lalu") untuk notifikasi & aktivitas
export function ago(iso, now = Date.now()) {
  const t = Date.parse(iso); if (Number.isNaN(t)) return '';
  const s = Math.max(0, Math.floor((now - t) / 1000));
  if (s < 45) return 'baru saja'; const m = Math.floor(s / 60); if (m < 60) return `${m || 1} menit lalu`;
  const h = Math.floor(m / 60); if (h < 24) return `${h} jam lalu`; const d = Math.floor(h / 24); if (d < 7) return `${d} hari lalu`;
  return new Date(t).toLocaleDateString('id-ID', { day: '2-digit', month: 'short' });
}
// 7700 -> "7,7rb", 1200000 -> "1,2jt"
export function compact(n) {
  const v = Number(n); if (!Number.isFinite(v)) return '—';
  if (v >= 1e6) return (v / 1e6).toFixed(1).replace('.', ',').replace(',0', '') + 'jt';
  if (v >= 1e3) return (v / 1e3).toFixed(1).replace('.', ',').replace(',0', '') + 'rb';
  return String(Math.round(v));
}
// 960000 dtk -> "11H 3J", 7200 -> "2J 0M"
export function upfmt(s) { const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60); return d ? `${d}H ${h}J` : h ? `${h}J ${m}M` : `${m}M`; }
