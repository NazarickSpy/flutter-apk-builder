import { useMemo } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, BarChart, Bar, Legend } from 'recharts';
import { BarChart3 } from 'lucide-react';
// Port DashboardCharts OpenWA (area + donat + batang), sumber data: GET /api/live (agregat 24 jam, tanpa data pribadi).
const COL = { panel: '#3b82f6', premium: '#a855f7', nokos: '#f59e0b' }, LBL = { panel: 'Server Panel', premium: 'Aplikasi Premium', nokos: 'Nomor Virtual' };
const tick = { fontSize: 12, fill: 'var(--text-secondary)' };
const tip = { contentStyle: { background: 'var(--bg-white)', border: '1px solid var(--border)', borderRadius: 10, color: 'var(--text-primary)', fontSize: 13 }, itemStyle: { color: 'var(--text-primary)' }, labelStyle: { color: 'var(--text-secondary)' } };
export default function OrderCharts({ live }) {
  const series = useMemo(() => { const h = (live && live.hourly) || [], now = new Date(); return h.map((n, i) => { const t = new Date(now.getTime() - (23 - i) * 3600e3); return { label: String(t.getHours()).padStart(2, '0') + ':00', pesanan: n }; }); }, [live]);
  const by = useMemo(() => Object.entries((live && live.by) || {}).map(([k, v]) => ({ key: k, name: LBL[k] || k, value: v })).sort((a, b) => b.value - a.value), [live]);
  const has = series.some((p) => p.pesanan > 0);
  return (<section className="dashboard-charts" aria-label="Grafik pesanan">
    <div className="charts-header"><div className="charts-title"><BarChart3 size={18} /><h2>Analitik Pesanan</h2></div><div className="period-toggle" role="group" aria-label="Periode"><button type="button" className="period-tab active" aria-pressed="true">24 jam</button></div></div>
    {!live ? <div className="charts-empty">Memuat…</div> : !has ? <div className="charts-empty">Belum ada pesanan dalam 24 jam terakhir.</div> :
      <div className="charts-grid">
        <div className="chart-card chart-wide"><h3>Pesanan per jam</h3>
          <ResponsiveContainer width="100%" height={260}><AreaChart data={series} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
            <defs><linearGradient id="gOrd" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" style={{ stopColor: 'var(--primary)' }} stopOpacity={0.4} /><stop offset="95%" style={{ stopColor: 'var(--primary)' }} stopOpacity={0} /></linearGradient></defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="label" tick={tick} interval={3} /><YAxis allowDecimals={false} tick={tick} /><Tooltip {...tip} />
            <Area type="monotone" dataKey="pesanan" name="Pesanan" stroke="var(--primary)" fill="url(#gOrd)" strokeWidth={2} /></AreaChart></ResponsiveContainer></div>
        <div className="chart-card"><h3>Berdasarkan layanan</h3>
          <ResponsiveContainer width="100%" height={260}><PieChart><Pie data={by} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2} stroke="var(--bg-white)">{by.map((e) => <Cell key={e.key} fill={COL[e.key] || '#64748b'} />)}</Pie><Tooltip {...tip} /><Legend wrapperStyle={{ color: 'var(--text-secondary)', fontSize: 13 }} /></PieChart></ResponsiveContainer></div>
        <div className="chart-card"><h3>Layanan terlaris</h3>
          <ResponsiveContainer width="100%" height={260}><BarChart data={by} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} /><XAxis type="number" allowDecimals={false} tick={tick} /><YAxis type="category" dataKey="name" width={120} tick={tick} /><Tooltip {...tip} cursor={{ fill: 'var(--primary-soft)' }} />
            <Bar dataKey="value" name="Pesanan" fill="var(--primary)" radius={[0, 4, 4, 0]} /></BarChart></ResponsiveContainer></div>
      </div>}
  </section>);
}
