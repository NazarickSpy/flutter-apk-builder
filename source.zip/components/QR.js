import { useState } from 'react';
import { Download, RefreshCw } from 'lucide-react';
// QRIS ditampilkan utuh (tidak di-crop/ditimpa), lebar >= 320px agar mudah discan. Gambar disajikan same-origin lewat /api/qr/...
// Tidak ada URL gateway yang tampil ke pengguna. Jika gambar gagal dimuat: tombol muat ulang.
export default function QR({ src, name = 'qris' }) {
  const [n, setN] = useState(0), [bad, setBad] = useState(false);
  const url = n ? `${src}${src.includes('?') ? '&' : '?'}r=${n}` : src;
  return (<div className="qrwrap">
    {!bad ? <><div className="qrbox"><img className="qrimg" src={url} alt="QRIS pembayaran" width="360" height="360" onError={() => setBad(true)} /></div>
        <a className="btn ghost sm dl" href={url} download={`${name}.png`}><Download size={16} />Simpan QR</a></>
      : <div className="msg e center" style={{ margin: 0, width: '100%' }}>QR gagal dimuat. Periksa koneksi lalu coba lagi.<button className="btn ghost full" onClick={() => { setBad(false); setN(n + 1); }}><RefreshCw size={16} />Muat ulang QR</button></div>}
  </div>);
}
