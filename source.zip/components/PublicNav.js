import Link from 'next/link';
import { useRouter } from 'next/router';
import { useEffect, useRef, useState } from 'react';
import { Menu, X, Home, Layers, Package, HelpCircle, BookOpen, Activity, MessageSquare, FileText, ShieldCheck, Gem, Newspaper, Info, Headset, LogIn, UserPlus, ChevronRight } from 'lucide-react';
import Brand from './Brand';
// Navbar publik: desktop = tautan di bar; HP = drawer bergrup (Utama / Informasi / Akun) seperti referensi
const GROUPS = (home) => [
  ['Utama', [[home ? '#top' : '/', 'Beranda', Home], [home ? '#layanan' : '/#layanan', 'Layanan', Layers], [home ? '#paket' : '/#paket', 'Paket Hosting', Package], [home ? '#faq' : '/#faq', 'FAQ', HelpCircle]]],
  ['Informasi', [['/cara-order', 'Cara Order', BookOpen], ['/produk', 'Katalog & Harga', Gem], ['/panduan', 'Panduan & Artikel', Newspaper], ['/garansi', 'Klaim Garansi', ShieldCheck], ['/status', 'Status Sistem', Activity], ['/bantuan', 'Bantuan', MessageSquare], ['/tentang', 'Tentang Kami', Info], ['/kontak', 'Kontak', Headset], ['/terms', 'Syarat & Ketentuan', FileText]]],
  ['Akun', [['/login', 'Masuk', LogIn], ['/register', 'Daftar Akun', UserPlus]]]];
const BAR = (home) => [['/cara-order', 'Cara Order'], [home ? '#layanan' : '/#layanan', 'Layanan'], [home ? '#paket' : '/#paket', 'Paket'], ['/panduan', 'Panduan'], ['/garansi', 'Garansi'], ['/bantuan', 'Bantuan']];
const A = ({ h, children, ...p }) => (h[0] === '#' ? <a href={h} {...p}>{children}</a> : <Link href={h} {...p}>{children}</Link>);
export default function PublicNav({ home, sub }) {
  const r = useRouter(), [open, setOpen] = useState(false), btn = useRef(null), first = useRef(null);
  useEffect(() => { const c = () => setOpen(false); r.events.on('routeChangeStart', c); return () => r.events.off('routeChangeStart', c); }, [r.events]);
  useEffect(() => {
    if (!open) return undefined; const prev = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const k = (e) => { if (e.key === 'Escape') { setOpen(false); btn.current && btn.current.focus(); } }, rs = () => { if (window.innerWidth >= 1000) setOpen(false); };
    window.addEventListener('keydown', k); window.addEventListener('resize', rs); first.current && first.current.focus();
    return () => { document.body.style.overflow = prev; window.removeEventListener('keydown', k); window.removeEventListener('resize', rs); };
  }, [open]);
  return (<>
    <a href="#konten" className="skip">Lewati ke konten</a>
    <header className="navbar" id="top"><div className="nb"><Brand sub={sub} /><nav className="nbl" aria-label="Navigasi">{BAR(home).map(([h, l]) => <A key={h} h={h} className={r.pathname === h ? 'on' : ''}>{l}</A>)}</nav>
      <Link href="/login" className="btn sm">Masuk</Link>
      <button ref={btn} className="ib mobonly" aria-label="Buka menu" aria-expanded={open} onClick={() => setOpen(true)}><Menu size={26} /></button></div></header>
    {open && <><div className="sidebar-ov" onClick={() => setOpen(false)} style={{ display: 'block' }} />
      <aside className="pdrawer" aria-label="Menu"><div className="sb-head"><Brand /><button className="ib" onClick={() => setOpen(false)} aria-label="Tutup menu"><X size={22} /></button></div>
        <nav className="sb-nav">{GROUPS(home).map(([g, items], gi) => <div key={g} style={{ display: 'contents' }}><div className="sb-grp">{g}</div>{items.map(([h, l, I], ii) => <A key={l} h={h} style={{ '--ic': `var(--c${((gi * 5 + ii) % 8) + 1})` }} ref={gi === 0 && ii === 0 ? first : null} className="nav-item" onClick={() => setOpen(false)}><I size={19} /><span>{l}</span><ChevronRight size={16} style={{ marginLeft: 'auto', opacity: .4 }} /></A>)}</div>)}</nav></aside></>}
  </>);
}
