import Link from 'next/link';
import { Mail, MessageCircle, MapPin } from 'lucide-react';
import { CONTACT } from './site';
// Identitas & kontak usaha yang terlihat di HTML (tanpa JavaScript), dibaca dari .env saat build (CONTACT_WA, CONTACT_EMAIL, CONTACT_ADDRESS).
export default function FooterContact() {
  return (<div className="fcontact">
    {CONTACT.email ? <a href={`mailto:${CONTACT.email}`}><Mail size={15} />{CONTACT.email}</a> : null}
    {CONTACT.wa ? <a href={`https://wa.me/${CONTACT.wa}`} target="_blank" rel="noopener noreferrer"><MessageCircle size={15} />WhatsApp +{CONTACT.wa}</a> : null}
    {CONTACT.address ? <span><MapPin size={15} />{CONTACT.address}</span> : null}
    <Link href="/kontak">Halaman Kontak</Link>
  </div>);
}
