import { TriangleAlert } from 'lucide-react';
import Modal from './Modal';
export default function Confirm({ title, text, yes = 'Ya', no = 'Batal', danger = true, busy, onNo, onYes }) {
  return (<Modal onClose={onNo} label={title} locked={busy}>
    <div className="top" style={{ alignItems: 'flex-start' }}><div className={'warn' + (danger ? '' : ' info')}><TriangleAlert size={24} /></div><div><b>{title}</b><br /><small className="mut">{text}</small></div></div>
    <div className="two"><button className="btn ghost" disabled={busy} onClick={onNo}>{no}</button><button className={'btn ' + (danger ? 'red' : '')} disabled={busy} onClick={onYes}>{busy ? 'Memproses…' : yes}</button></div></Modal>);
}
