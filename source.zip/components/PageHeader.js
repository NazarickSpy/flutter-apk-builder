// Header halaman (OpenWA PageHeader): judul + badge di kiri, aksi di kanan, deskripsi di bawah. HP: judul, deskripsi, lalu aksi.
export default function PageHeader({ title, sub, badge, actions, icon: I }) {
  return (<header className="page-header"><div className="ph-t">{I ? <span className="ph-i"><I size={22} /></span> : null}<h1>{title}</h1>{badge}</div>{actions ? <div className="ph-a">{actions}</div> : null}{sub ? <p className="ph-s">{sub}</p> : null}</header>);
}
