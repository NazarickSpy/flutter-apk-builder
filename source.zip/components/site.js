// Konstanta situs (aman untuk klien). Nilai dibaca saat build dari .env lewat next.config.js (env).
export const SITE_URL = String(process.env.SITE_URL || 'https://snowystore.my.id').replace(/\/+$/, '');
export const SITE_NAME = 'SnowyStore';
export const CONTACT = { wa: String(process.env.CONTACT_WA || '').replace(/\D/g, ''), email: process.env.CONTACT_EMAIL || '', address: process.env.CONTACT_ADDRESS || '' };
export const abs = (p) => SITE_URL + (p === '/' ? '/' : p);
export const SERVICES = [['Aplikasi Premium', 'Akun aplikasi premium dengan pembayaran QRIS dan pemrosesan otomatis.'], ['Nomor Virtual (OTP)', 'Nomor sementara untuk menerima kode OTP verifikasi aplikasi.'], ['Hosting Server Panel Pterodactyl', 'Server panel dengan RAM 1 GB sampai 10 GB untuk bot, aplikasi, dan game.']];
export const orgSchema = () => ({
  '@context': 'https://schema.org', '@type': 'OnlineStore', '@id': SITE_URL + '/#organization', name: SITE_NAME, alternateName: 'Snowy Store', url: SITE_URL + '/',
  logo: { '@type': 'ImageObject', url: SITE_URL + '/img/logo-icon.png', width: 1254, height: 1254 }, image: SITE_URL + '/img/SnowyStore.webp',
  description: 'Toko digital untuk aplikasi premium, nomor virtual OTP, dan hosting server panel Pterodactyl. Pembayaran QRIS dan pemrosesan otomatis.', slogan: 'Toko Digital All-in-One',
  areaServed: 'ID', availableLanguage: 'id',
  ...(CONTACT.email ? { email: CONTACT.email } : {}), ...(CONTACT.wa ? { telephone: '+' + CONTACT.wa } : {}),
  ...(CONTACT.address ? { address: { '@type': 'PostalAddress', streetAddress: CONTACT.address, addressCountry: 'ID' } } : {}),
  ...(CONTACT.wa || CONTACT.email ? { contactPoint: [{ '@type': 'ContactPoint', contactType: 'customer support', areaServed: 'ID', availableLanguage: ['id'], url: SITE_URL + '/kontak', ...(CONTACT.wa ? { telephone: '+' + CONTACT.wa } : {}), ...(CONTACT.email ? { email: CONTACT.email } : {}) }] } : {}),
  hasOfferCatalog: { '@type': 'OfferCatalog', name: 'Layanan SnowyStore', itemListElement: SERVICES.map(([name, description]) => ({ '@type': 'Offer', itemOffered: { '@type': 'Service', name, description, provider: { '@id': SITE_URL + '/#organization' } } })) }
});
export const siteSchema = () => ({ '@context': 'https://schema.org', '@type': 'WebSite', '@id': SITE_URL + '/#website', url: SITE_URL + '/', name: SITE_NAME, inLanguage: 'id-ID', publisher: { '@id': SITE_URL + '/#organization' } });
export const faqSchema = (faq) => ({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) });
export const crumbSchema = (items) => ({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: items.map(([name, path], i) => ({ '@type': 'ListItem', position: i + 1, name, item: abs(path) })) });
export const productSchema = (list) => ({ '@context': 'https://schema.org', '@type': 'ItemList', name: 'Paket Server Panel Pterodactyl SnowyStore', itemListElement: list.map((p, i) => ({ '@type': 'ListItem', position: i + 1, item: {
  '@type': 'Product', name: `Server Panel Pterodactyl ${p.name}`, sku: p.key, category: 'Hosting Server Panel', brand: { '@type': 'Brand', name: SITE_NAME },
  description: `Server panel Pterodactyl dengan RAM ${p.memory / 1024} GB dan disk ${p.disk / 1024} GB${p.cpu ? `, CPU ${p.cpu}%` : ''}. Pembayaran QRIS, server dibuat otomatis.`, image: SITE_URL + '/img/SnowyStore.webp',
  offers: { '@type': 'Offer', priceCurrency: 'IDR', price: String(p.price), url: SITE_URL + '/produk', seller: { '@id': SITE_URL + '/#organization' } } } })) });
