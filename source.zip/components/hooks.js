import { useEffect, useRef, useState } from 'react';
// Polling yang hemat: berhenti saat tab tersembunyi, langsung segar saat tab kembali terlihat. fn boleh async; kesalahan ditangani pemanggil.
export function usePoll(fn, ms, deps = []) {
  const ref = useRef(fn); ref.current = fn;
  useEffect(() => {
    let dead = false, t = null;
    const loop = async () => { if (dead) return; if (!document.hidden) { try { await ref.current(); } catch {} } if (!dead) t = setTimeout(loop, ms); };
    const vis = () => { if (!document.hidden) { clearTimeout(t); loop(); } };
    loop(); document.addEventListener('visibilitychange', vis);
    return () => { dead = true; clearTimeout(t); document.removeEventListener('visibilitychange', vis); };
  }, [ms, ...deps]); // eslint-disable-line react-hooks/exhaustive-deps
}
export function useOnline() {
  const [on, setOn] = useState(true);
  useEffect(() => { setOn(navigator.onLine !== false); const a = () => setOn(true), b = () => setOn(false); window.addEventListener('online', a); window.addEventListener('offline', b); return () => { window.removeEventListener('online', a); window.removeEventListener('offline', b); }; }, []);
  return on;
}
const reduced = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
// Angka yang "menghitung" ke nilai baru (rAF, 700ms, easing). Tanpa animasi bila gerak dikurangi.
export function useCountUp(target, ms = 700) {
  const [v, setV] = useState(() => (Number.isFinite(target) ? target : 0)), from = useRef(0), raf = useRef(0);
  useEffect(() => {
    if (!Number.isFinite(target)) return undefined;
    if (reduced()) { setV(target); return undefined; }
    const a = from.current, t0 = performance.now();
    const step = (t) => { const p = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - p, 3); const x = a + (target - a) * e; from.current = x; setV(x); if (p < 1) raf.current = requestAnimationFrame(step); };
    raf.current = requestAnimationFrame(step); return () => cancelAnimationFrame(raf.current);
  }, [target, ms]);
  return Math.round(v);
}
// Muncul halus saat di-scroll: elemen di bawah layar disembunyikan dulu lalu dimunculkan sekali (IntersectionObserver). Elemen yang sudah terlihat tidak disentuh.
let rvIO = null;
const rvObserver = () => rvIO || (rvIO = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('rv'); e.target.classList.remove('rv-pre'); rvIO.unobserve(e.target); } }), { rootMargin: '0px 0px -6% 0px', threshold: 0.01 }));
// Reveal saat scroll: satu observer global yang tidak pernah diputus, jadi elemen yang sudah ditandai tidak mungkin "tertinggal" tersembunyi saat efek dijalankan ulang
export function useReveal(dep) {
  useEffect(() => {
    if (typeof IntersectionObserver === 'undefined' || reduced()) return;
    const io = rvObserver();
    [...document.querySelectorAll('[data-rv]')].filter((el) => !el.dataset.rvDone && el.getBoundingClientRect().top > window.innerHeight * 0.92).forEach((el, i) => { el.dataset.rvDone = '1'; el.style.setProperty('--i', String(i % 4)); el.classList.add('rv-pre'); io.observe(el); });
  }, [dep]);
}
