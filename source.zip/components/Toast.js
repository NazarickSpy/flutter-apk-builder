import { useEffect, useState, useCallback, useRef } from 'react';
import { CircleCheck, CircleX, TriangleAlert, Info, X } from 'lucide-react';
// Toast ringan tanpa context: panggil toast('success', 'Judul', 'pesan') dari mana saja. Durasi 4 dtk (error 6 dtk), kunci `key` mencegah toast ganda.
const EV = 'snowy:toast';
export function toast(type, title, message = '', opt = {}) { if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(EV, { detail: { type, title, message, ...opt } })); }
const ICON = { success: CircleCheck, error: CircleX, warning: TriangleAlert, info: Info };
export default function Toasts() {
  const [list, setList] = useState([]), id = useRef(0), timers = useRef({});
  const close = useCallback((i) => { setList((l) => l.map((t) => (t.i === i ? { ...t, out: true } : t))); setTimeout(() => setList((l) => l.filter((t) => t.i !== i)), 200); }, []);
  useEffect(() => {
    const on = (e) => { const d = e.detail || {}; setList((l) => { if (d.key && l.some((t) => t.key === d.key && !t.out)) return l; const i = ++id.current; timers.current[i] = setTimeout(() => close(i), d.ms || (d.type === 'error' ? 6000 : 4000)); return [...l.slice(-3), { i, ...d }]; }); };
    window.addEventListener(EV, on); const tm = timers.current; return () => { window.removeEventListener(EV, on); Object.values(tm).forEach(clearTimeout); };
  }, [close]);
  return (<div className="toasts" aria-live="polite" aria-atomic="false">{list.map((t) => { const I = ICON[t.type] || Info; return (<div key={t.i} className={`toast t-${t.type || 'info'}${t.out ? ' out' : ''}`} role={t.type === 'error' ? 'alert' : 'status'}>
    <I size={20} className="ti" /><div className="tc"><div className="tt">{t.title}</div>{t.message ? <div className="tm">{t.message}</div> : null}</div>
    <button className="tx2" onClick={() => close(t.i)} aria-label="Tutup notifikasi"><X size={14} /></button></div>); })}</div>);
}
