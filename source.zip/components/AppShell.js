import Link from 'next/link';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useEffect, useRef, useState } from 'react';
import { Menu, X, ChevronDown, ChevronLeft, LayoutGrid, History, Gem, Smartphone, ShieldCheck, Activity, BookOpen, MessageSquare, FileText, UserCog, LogOut, Bell, CirclePlus, LifeBuoy, ChevronRight, Lock, ReceiptText } from 'lucide-react';
import { api } from './api';
import { useOnline } from './hooks';
import Brand_ from './Brand';
import Notifs, { useNotifs } from './Notifications';
import Confirm from './Confirm';
import PageHeader from './PageHeader';

const NAV = [
  ['Utama', [['/dashboard', 'Dashboard', LayoutGrid, 'dashboard'], ['/orders', 'Riwayat Pesanan', History, 'orders'], ['/notifikasi', 'Notifikasi', Bell, 'notifikasi']]],
  ['Layanan', [['/dashboard#paket', 'Beli Panel', CirclePlus], ['/premium', 'Aplikasi Premium', Gem, 'premium'], ['/nokos', 'Nomor Virtual (OTP)', Smartphone, 'nokos'], ['/garansi', 'Klaim Garansi', ShieldCheck, 'garansi']]],
  ['Informasi', [['/status', 'Status Sistem', Activity, 'status'], ['/cara-order', 'Cara Order', BookOpen], ['/bantuan', 'Bantuan & FAQ', MessageSquare], ['/terms', 'Syarat & Ketentuan', FileText]]],
  ['Akun', [['/profile', 'Profil & Keamanan', UserCog, 'profile']]]];
const IC = { '/dashboard': 1, '/orders': 2, '/notifikasi': 4, '/dashboard#paket': 3, '/premium': 2, '/nokos': 3, '/garansi': 4, '/status': 7, '/cara-order': 1, '/bantuan': 5, '/terms': 6, '/profile': 1, '/admin': 8 };
const icv = (h) => ({ '--ic': `var(--c${IC[h] || 1})` });
const TITLE = { dashboard: 'Dashboard', orders: 'Riwayat Pesanan', notifikasi: 'Notifikasi', premium: 'Aplikasi Premium', nokos: 'Nomor Virtual', garansi: 'Klaim Garansi', profile: 'Profil & Keamanan', admin: 'Panel Admin' };
const getMini = () => { try { return localStorage.getItem('snowy:mini') === '1'; } catch { return false; } };

export default function AppShell({ me, active, title, bare, head, children }) {
  const r = useRouter(), online = useOnline(), { unread } = useNotifs(false);
  const [open, setOpen] = useState(false), [mini, setMini] = useState(getMini), [bell, setBell] = useState(false), [um, setUm] = useState(false), [cf, setCf] = useState(false), [busy, setBusy] = useState(false);
  const menuBtn = useRef(null), first = useRef(null);
  const admin = me.role === 'admin', ini = me.username[0];
  useEffect(() => { const h = () => setCf(true); window.addEventListener('snowy:logout', h); return () => window.removeEventListener('snowy:logout', h); }, []);
  useEffect(() => { const c = () => { setOpen(false); setBell(false); setUm(false); }; r.events.on('routeChangeStart', c); return () => r.events.off('routeChangeStart', c); }, [r.events]);
  useEffect(() => { // drawer mobile: kunci scroll, Esc menutup, fokus masuk & kembali, otomatis tutup saat layar melebar
    if (!open) return undefined; const prev = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const k = (e) => { if (e.key === 'Escape') { setOpen(false); menuBtn.current && menuBtn.current.focus(); } }, rs = () => { if (window.innerWidth >= 1024) setOpen(false); };
    window.addEventListener('keydown', k); window.addEventListener('resize', rs); first.current && first.current.focus();
    return () => { document.body.style.overflow = prev; window.removeEventListener('keydown', k); window.removeEventListener('resize', rs); };
  }, [open]);
  useEffect(() => { if (!um) return undefined; const k = (e) => { if (e.key === 'Escape') setUm(false); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [um]);
  const toggleMini = () => { const v = !mini; setMini(v); try { localStorage.setItem('snowy:mini', v ? '1' : '0'); } catch {} };
  const out = async () => { setBusy(true); try { await api('/logout', 'POST'); } catch {} r.push('/login'); };
  return (<div className="app">
    <Head><meta name="robots" content="noindex,nofollow" /></Head>
    <a href="#konten" className="skip">Lewati ke konten</a>
    <aside id="sidebar" className={'sidebar' + (open ? ' open' : '') + (mini ? ' mini' : '')} aria-label="Menu utama">
      <div className="sb-head"><Brand_ sub="CLIENT PORTAL" /><button className="ib sb-close" onClick={() => setOpen(false)} aria-label="Tutup menu"><X size={22} /></button></div>
      <button className="collapse-toggle" onClick={toggleMini} aria-label={mini ? 'Lebarkan sidebar' : 'Ciutkan sidebar'}><ChevronLeft size={16} /></button>
      <nav className="sb-nav" aria-label="Navigasi">
        {NAV.map(([g, items], gi) => <div key={g} style={{ display: 'contents' }}><div className="sb-grp">{g}</div>{items.map(([h, l, I, k], ii) => <Link key={l} href={h} style={icv(h)} ref={gi === 0 && ii === 0 ? first : null} title={mini ? l : undefined} aria-current={k && k === active ? 'page' : undefined} className={'nav-item' + (k && k === active ? ' on' : '')}><I size={19} /><span>{l}</span>{k === 'notifikasi' && unread > 0 ? <em className="nb2" style={{ fontStyle: 'normal' }}>{unread > 9 ? '9+' : unread}</em> : null}</Link>)}</div>)}
        {admin && <><div className="sb-grp">Admin</div><Link href="/admin" style={icv('/admin')} className={'nav-item' + (active === 'admin' ? ' on' : '')} title={mini ? 'Panel Admin' : undefined}><Lock size={19} /><span>Panel Admin</span></Link></>}
      </nav>
      <div className="sb-foot">
        <Link href="/bantuan" className="sb-help" title="Pusat Bantuan"><span className="ico"><LifeBuoy size={19} /></span><div><b>Butuh bantuan?</b><small className="mut">Pusat Bantuan & FAQ</small></div><ChevronRight size={18} /></Link>
        <button className="logout-btn" onClick={() => setCf(true)} title="Keluar"><LogOut size={18} /><span>Keluar</span></button>
      </div>
    </aside>
    {open && <div className="sidebar-ov" onClick={() => setOpen(false)} />}
    <div className={'main' + (mini ? ' mini' : '')}>
      <header className="topbar">
        <button ref={menuBtn} className="ib menu-btn" onClick={() => setOpen(true)} aria-label="Buka menu" aria-controls="sidebar" aria-expanded={open}><Menu size={24} /></button>
        <Brand_ /><span className="top-title">{title || TITLE[active] || ''}</span><span className="grow" />
        <div className="top-act">
          <Notifs open={bell} setOpen={(v) => { setBell(v); if (v) setUm(false); }} />
          <button className="chipu" onClick={() => { setUm(!um); setBell(false); }} aria-haspopup="menu" aria-expanded={um} aria-label="Menu akun"><span className="avr"><span className="av xs">{ini}</span><i className={'st' + (online ? '' : ' off')} /></span><b>{me.username}</b><ChevronDown size={16} className="chev" /></button>
          {um && <><div className="pop-ov" onClick={() => setUm(false)} /><div className="pop menu" role="menu">
            <div className="um-h"><span className="avr"><span className="av">{ini}</span><i className={'st' + (online ? '' : ' off')} /></span><div style={{ minWidth: 0 }}><b>{me.username}</b><span className={'um-st' + (online ? '' : ' off')}><i />{online ? 'Online' : 'Offline'}</span></div><span className="badge" style={{ marginLeft: 'auto' }}>{me.role.toUpperCase()}</span></div>
            <Link role="menuitem" href="/profile" className="um-i"><UserCog size={19} /><div><b>Profil</b><small className="mut">Ubah informasi pribadi</small></div></Link>
            <Link role="menuitem" href="/profile?tab=sec" className="um-i"><ShieldCheck size={19} /><div><b>Keamanan</b><small className="mut">Password & aktivitas login</small></div></Link>
            <Link role="menuitem" href="/notifikasi" className="um-i"><Bell size={19} /><div><b>Notifikasi</b><small className="mut">{unread ? `${unread} belum dibaca` : 'Semua sudah dibaca'}</small></div></Link>
            <Link role="menuitem" href="/orders" className="um-i"><ReceiptText size={19} /><div><b>Riwayat Pesanan</b><small className="mut">Panel, premium, nomor OTP</small></div></Link>
            {admin && <Link role="menuitem" href="/admin" className="um-i"><Lock size={19} /><div><b>Panel Admin</b><small className="mut">Kelola user & pesanan</small></div></Link>}
            <div className="um-sep" /><button role="menuitem" className="um-i out" onClick={() => { setUm(false); setCf(true); }}><LogOut size={19} /><div><b>Keluar</b></div></button></div></>}
        </div>
      </header>
      <main id="konten" tabIndex={-1} style={{ outline: 'none' }}>{bare ? children : <div className="wrap pg-in">{head ? <PageHeader {...head} /> : null}{children}</div>}</main>
    </div>
    {cf && <Confirm title="Konfirmasi Keluar" text="Apakah Anda yakin ingin keluar dari sesi portal member?" yes="Ya, Keluar" busy={busy} onNo={() => setCf(false)} onYes={out} />}
  </div>);
}
