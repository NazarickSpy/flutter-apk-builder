import { useCallback, useEffect, useRef, useState } from 'react';
import { CircleCheck, LoaderCircle, Ban, Copy, Check, Eye, EyeOff, TriangleAlert, Clock } from 'lucide-react';
import { api, rp, fmt, copyText, PRM, prmClass } from './api';
import Modal from './Modal';
import QR from './QR';
const SECRETISH = /pass|pwd|sandi|pin|token|kunci|secret/i;
const pretty = (l) => l.replace(/\[(\d+)\]/g, ' $1 ').replace(/[._-]+/g, ' ').trim().replace(/^./, (c) => c.toUpperCase());
function Row({ label, value }) {
  const secret = SECRETISH.test(label), [show, setShow] = useState(!secret), [ok, setOk] = useState(false);
  return (<div className="ib2"><div style={{ minWidth: 0 }}><small className="cap">{pretty(label)}</small><div className="mono val" style={{ fontSize: 13.5 }}>{show ? value : '••••••••••'}</div></div>
    <div style={{ display: 'flex', gap: 6 }}>{secret && <button className="sqbtn sm" onClick={() => setShow(!show)} aria-label="Lihat">{show ? <EyeOff size={17} /> : <Eye size={17} />}</button>}
      <button className="sqbtn sm" aria-label="Salin" onClick={async () => { if (await copyText(value)) { setOk(true); setTimeout(() => setOk(false), 1500); } }}>{ok ? <Check size={17} /> : <Copy size={17} />}</button></div></div>);
}
const ACTIVE = ['awaiting_payment', 'processing', 'pending_provider'];
// Pembayaran QRIS + status pesanan Premium sampai selesai. Data akun hanya terlihat oleh pemilik dan TERSIMPAN permanen (bisa dilihat lagi dari Riwayat).
export default function PremiumDetail({ id, initial, onClose, onChange }) {
  const [o, setO] = useState(initial || null), [err, setErr] = useState(''), [left, setLeft] = useState(0), [ask, setAsk] = useState(false), [busy, setBusy] = useState(false), [cp, setCp] = useState(false);
  const alive = useRef(true), timer = useRef(null), last = useRef(initial ? initial.status : null), cb = useRef(onChange); cb.current = onChange;
  const poll = useCallback(async () => {
    clearTimeout(timer.current); let next = 3500;
    try { const d = await api(`/premium/orders/${id}`); if (!alive.current) return; setErr(''); setO(d); if (last.current !== d.status && cb.current) cb.current(); last.current = d.status; if (!ACTIVE.includes(d.status)) return; }
    catch (e) { if (!alive.current) return; setErr(e.message); if (e.status === 401 || e.status === 404) return; next = 7000; }
    if (typeof document !== 'undefined' && document.hidden) next = Math.max(next, 15000); // tab tidak terlihat: kurangi beban
    timer.current = setTimeout(poll, next);
  }, [id]);
  useEffect(() => { alive.current = true; if (initial && ACTIVE.includes(initial.status)) timer.current = setTimeout(poll, 2500); else if (!initial) poll(); return () => { alive.current = false; clearTimeout(timer.current); }; }, [poll]); // eslint-disable-line
  useEffect(() => {
    if (!o || !o.expires_at || o.status !== 'awaiting_payment') return undefined;
    const tick = () => setLeft(Math.max(0, Math.floor((new Date(o.expires_at) - Date.now()) / 1000))); tick(); const c = setInterval(tick, 1000); return () => clearInterval(c);
  }, [o && o.expires_at, o && o.status]); // eslint-disable-line
  const cancel = async () => { setBusy(true); try { await api(`/premium/orders/${id}/cancel`, 'POST'); setErr(''); } catch (e) { setErr(e.message); } setAsk(false); await poll(); setBusy(false); };
  const copyAll = async () => { if (o && o.result && (await copyText(o.result.map(([l, v]) => `${pretty(l)}: ${v}`).join('\n')))) { setCp(true); setTimeout(() => setCp(false), 1500); } };
  const st = o && o.status;
  return (<Modal onClose={onClose} label="Detail pesanan" locked={busy}>
    <h3 className="center">{st === 'awaiting_payment' ? 'Pembayaran Pesanan' : 'Detail Pesanan'}</h3>
    {o && <p className="mut center meta">{o.product_name}{o.qty > 1 ? ` ×${o.qty}` : ''}<br /><span className="mono">{o.ref}</span> - <span className={'stt ' + prmClass(st)}>{PRM[st]}</span></p>}
    {err && <div className="msg e">{err} <button className="linkbtn" onClick={() => { setErr(''); poll(); }}>Coba lagi</button></div>}
    {!o && !err && <div className="center loading"><LoaderCircle size={18} className="spin" /> Memuat…</div>}
    {st === 'awaiting_payment' && <>
      {o.qr_image ? <QR src={o.qr_image} name={o.ref} /> : <div className="center loading"><LoaderCircle size={18} className="spin" /> Menyiapkan QRIS…</div>}
      <div className="big">{rp(o.total || o.price)}</div>
      <p className="mut center small">Bayar <b>sesuai nominal persis</b> (sudah termasuk biaya layanan).<br />{left > 0 ? <><Clock size={13} className="vm" /> Berlaku <b className="mono">{fmt(left)}</b> - pembayaran terdeteksi otomatis</> : 'Waktu habis, memeriksa pembayaran terakhir…'}</p>
      {o.buyer_input && <small className="mut center" style={{ display: 'block' }}>Dikirim ke: {o.buyer_input}</small>}
      {!ask ? <button className="btn full ghost dangertxt" onClick={() => setAsk(true)}><Ban size={16} />Batalkan pesanan</button>
        : <div className="askrow"><span>Batalkan pesanan ini?</span><div className="two"><button className="btn ghost" disabled={busy} onClick={() => setAsk(false)}>Tidak</button><button className="btn red" disabled={busy} onClick={cancel}>{busy ? 'Membatalkan…' : 'Ya, Batalkan'}</button></div></div>}</>}
    {['processing', 'pending_provider'].includes(st) && <div className="msg warnm center"><LoaderCircle size={18} className="spin vm" /> Pembayaran diterima. Pesanan sedang diproses, hasil muncul otomatis di sini.</div>}
    {st === 'done' && <><div className="msg s center"><CircleCheck size={18} className="vm" /> Pesanan selesai. Data akun di bawah ini tersimpan permanen di akun Anda.</div>
      {o.result_error ? <div className="msg e">Data akun tidak dapat dibaca saat ini. Hubungi bantuan dengan kode pesanan di atas.</div> : o.result && o.result.length > 0
        ? <><div className="cred" style={{ marginTop: 10 }}>{o.result.map(([l, v], i) => <Row key={i} label={l} value={v} />)}</div><button className="btn ghost full" onClick={copyAll}>{cp ? <><Check size={16} />Tersalin</> : <><Copy size={16} />Salin semua</>}</button></>
        : <div className="msg warnm">{o.note || 'Pesanan ditandai selesai oleh admin.'} Jika data akun belum Anda terima, hubungi bantuan dengan kode pesanan di atas.</div>}
      <small className="mut" style={{ display: 'block', marginTop: 8 }}>Hanya Anda yang bisa melihat data ini. Segera ganti password akun bila memungkinkan.</small></>}
    {st === 'refund_needed' && <div className="msg warnm center"><TriangleAlert size={18} className="vm" /> Pembayaranmu sudah kami terima, tetapi pesanan tidak bisa diproses penyedia.{o.note ? <><br /><small>{o.note}</small></> : null}<br />Admin akan mengembalikan dana <b>{rp(o.total || o.price)}</b> secara penuh. Hubungi bantuan dengan kode <b>{o.ref}</b> untuk mempercepat.</div>}
    {st === 'review' && <div className="msg warnm center"><TriangleAlert size={18} className="vm" /> Pesanan sedang diperiksa admin untuk memastikan hasilnya. Pembayaranmu aman: bila gagal, dana dikembalikan penuh. Hubungi bantuan dengan kode <b>{o.ref}</b> bila perlu.</div>}
    {st === 'refunded' && <div className="msg e center"><Ban size={18} className="vm" /> Pesanan tidak dapat diselesaikan dan dana sudah dikembalikan.{o.note ? <><br /><small>{o.note}</small></> : null}</div>}
    {st === 'expired' && <div className="msg e center">QRIS kedaluwarsa. Buat pesanan baru bila masih ingin membeli.</div>}
    {st === 'cancelled' && <div className="msg e center"><Ban size={18} className="vm" /> Pesanan dibatalkan. Jangan bayar QRIS ini lagi.</div>}
    <button className="btn full ghost" disabled={busy} onClick={onClose}>Tutup</button></Modal>);
}
